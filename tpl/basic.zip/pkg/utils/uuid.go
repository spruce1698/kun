/**
 * @Author: spruce
 * @Date: 2024-04-22 16:12
 * @Desc: uuid
 */

package utils

import "github.com/google/uuid"

// 生成UUID
func GenUUid() string {
	return uuid.NewString()
}
