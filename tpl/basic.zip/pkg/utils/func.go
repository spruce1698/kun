/**
* @Author: spruce
 * @Date: 2024-03-28 11:19
 * @Desc: 常用函数
*/

package utils

import (
	"math/rand"
	"regexp"
	"sort"
	"unicode"
	"unicode/utf8"
)

// 判断是否有中文
func HasChinese(str string) bool {
	for _, r := range str {
		if unicode.Is(unicode.Han, r) || (regexp.MustCompile("[\u3002\uff1b\uff0c\uff1a\u201c\u201d\uff08\uff09\u3001\uff1f\u300a\u300b]").MatchString(string(r))) {
			return true
		}
	}
	return false
}

// 计算中文及字母字符串长度，例如：“你好hello” = 7
func TextLen(str string) int {
	return utf8.RuneCountInString(str)
}

// 截取含中文的字符串,start 0开始,长度
func TextIntercept(str string, start, length int64) string {
	strLen := TextLen(str)
	end := length + 1
	if end > int64(strLen) {
		end = int64(strLen)
	}
	str = string([]rune(str)[start:end])
	return str
}

// 按字典顺序排序
func DictSort(res []string) string {
	str := ""
	sort.Strings(res)
	if len(res) > 0 {
		for _, v := range res {
			str += v
		}
	}
	return str
}

// 随机顺序排序
func ShuffleSort(res []string) []string {
	rand.Shuffle(len(res), func(i, j int) {
		res[i], res[j] = res[j], res[i]
	})
	return res
}

// 身份证号星号掩码
func IdCodeMask(idCode string) string {
	idCodeLen := len(idCode)
	if idCodeLen > 2 {
		mask := ""
		for i := 0; i < (idCodeLen - 2); i++ {
			mask = mask + "*"
		}
		return idCode[:1] + mask + idCode[idCodeLen-1:]
	}
	return ""
}

// 手机号中间4位替换为*号
func MobileMask(mobile string) string {
	mobileLen := len(mobile)
	if mobileLen > 6 {
		mask := ""
		for i := 0; i < (mobileLen - 6); i++ {
			mask = mask + "*"
		}
		return mobile[:3] + mask + mobile[mobileLen-4:]
	}
	return ""
}

// 实名最后一位为证实,前面为*
func RealNameMask(realName string) string {
	newRealName := []rune(realName)
	realNameLen := len(newRealName)
	if realNameLen >= 2 {
		mask := ""
		for i := 0; i < (realNameLen - 1); i++ {
			mask = mask + "*"
		}
		return mask + string(newRealName[realNameLen-1:])
	}
	return ""
}
