/**
 * @Author:
 * @Date: 2024-03-28 16:02
 * @Desc: 网络相关函数 测试
 */

package utils

import (
	"context"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/pkg/errors"
	"golang.org/x/sync/errgroup"
)

func TestClientIP(t *testing.T) {
	// t.Log(ClientIP("192.168.0.1"))
}

func TestExternalIP(t *testing.T) {
	t.Log(ExternalIP())
}

func TestIPv42Int64(t *testing.T) {
	t.Log(IPv42Int64("192.168.0.1"))
}

func TestLocalIP(t *testing.T) {
	t.Log(LocalIP())
}

func TestWaitGroup(t *testing.T) {
	// 开箱即用，只需要声明即可
	var wg sync.WaitGroup

	wg.Add(2)
	go func() {
		defer wg.Done()
		fmt.Print("task 1")
	}()
	go func() {
		defer wg.Done()
		fmt.Print("task 2")
	}()
	wg.Wait()

	fmt.Print("finish")
}

// 使用 errgroup 库的 Wait()方法判断是否有 goroutine 返回错误信息。
func Test_Errgroup1(t *testing.T) {
	eg := errgroup.Group{}
	eg.Go(func() error {
		fmt.Println("go1")
		return nil
	})
	eg.Go(func() error {
		fmt.Println("go2")
		err := errors.New("go2 err")
		return err
	})
	err := eg.Wait()
	if err != nil {
		fmt.Println("err =", err)
	}
}

// 附加 cancel 功能
func Test_Errgroup2(t *testing.T) {
	eg, ctx := errgroup.WithContext(context.Background())
	eg.Go(func() error {
		time.Sleep(1 * time.Second)
		select {
		case <-ctx.Done():
			fmt.Println("go1 cancel, err = ", ctx.Err())
		default:
			fmt.Println("go1 run")
		}
		return nil
	})
	eg.Go(func() error {
		err := errors.New("go2 err")
		return err
	})
	err := eg.Wait()
	if err != nil {
		fmt.Println("err =", err)
	}
}

// 限制并发数量
func Test_Errgroup3(t *testing.T) {
	eg := errgroup.Group{}
	eg.SetLimit(2)
	eg.TryGo(func() error {
		fmt.Println("go1 run")
		return nil
	})
	eg.TryGo(func() error {
		err := errors.New("go2 err")
		return err
	})
	eg.TryGo(func() error {
		fmt.Println("go3 run")
		return nil
	})
	err := eg.Wait()
	if err != nil {
		fmt.Println("err =", err)
	}
}
func Test_AvailablePort(t *testing.T) {
	t.Log(AvailablePort())
	t.Log(LocalIP())
}
