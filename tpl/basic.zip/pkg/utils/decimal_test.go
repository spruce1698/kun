/**
 * @Author: spruce
 * @Date: 2024-03-28 21:14
 * @Desc: decimal 测试
 */

package utils

import (
	"fmt"
	"testing"
)

func TestCent2Yuan(t *testing.T) {
	a := 1889
	fmt.Println(a)
	b := Cent2Yuan(int64(a))
	fmt.Println(b)
	c := float64(a) / 100
	fmt.Println(c)
}

func TestYuan2Cent(t *testing.T) {
	a := 18.4
	fmt.Println(a)
	b := Yuan2Cent(a)
	fmt.Println(b)
	c := int64(a * 100)
	fmt.Println(c)
}

func TestYuanStr2Cent(t *testing.T) {
	a := "18.4"
	fmt.Println(a)
	b, _ := YuanStr2Cent(a)
	fmt.Println(b)
}
