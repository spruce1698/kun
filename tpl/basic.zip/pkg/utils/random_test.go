/**
 * @Author: Administrator
 * @Date: 2021/9/9 17:09
 * @Desc: 随机字符串测试
 */

package utils

import (
	"fmt"
	"testing"
)

func TestGenStr(t *testing.T) {
	for i := 0; i < 10; i++ {
		id := GenStr(2, 4)
		fmt.Println(id)
	}
}

func Test_GenNumeric(t *testing.T) {
	for i := 0; i < 1000; i++ {
		id := GenNumeric(10, 1000)
		fmt.Println(id)
	}
}
