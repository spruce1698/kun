/**
* @Author: spruce
 * @Date: 2024-03-28 12:49
 * @Desc: 常用函数 测试
*/

package utils

import (
	"fmt"
	"regexp"
	"strings"
	"testing"
)

func TestTextLen(t *testing.T) {
	text := "夏季新品男装多色TT恤夏季新品男装多色色恤"
	got := TextLen(text)
	t.Log(got)
}

func TestTextIntercept(t *testing.T) {
	text := "夏季新品男装多色TT恤夏季新品男装多色色恤"
	got := TextIntercept(text, 2, 21)
	t.Log(got)
}

func TestCaseCamelLower(t *testing.T) {
	fmt.Println(CaseCamelLower(Replace("limits/frontEnd", "/", "_")))
}

func Replace(origin, search, replace string, count ...int) string {
	n := -1
	if len(count) > 0 {
		n = count[0]
	}
	return strings.Replace(origin, search, replace, n)
}
func CaseCamelLower(s string) string {
	if s == "" {
		return s
	}
	if r := rune(s[0]); r >= 'A' && r <= 'Z' {
		s = strings.ToLower(string(r)) + s[1:]
	}
	return toCamelInitCase(s, false)
}

var numberSequence = regexp.MustCompile(`([a-zA-Z]{0,1})(\d+)([a-zA-Z]{0,1})`)

func addWordBoundariesToNumbers(s string) string {
	r := numberSequence.ReplaceAllFunc([]byte(s), func(bytes []byte) []byte {
		var result []byte
		match := numberSequence.FindSubmatch(bytes)
		if len(match[1]) > 0 {
			result = append(result, match[1]...)
			result = append(result, []byte(" ")...)
		}
		result = append(result, match[2]...)
		if len(match[3]) > 0 {
			result = append(result, []byte(" ")...)
			result = append(result, match[3]...)
		}
		return result
	})
	return string(r)
}
func toCamelInitCase(s string, initCase bool) string {
	s = addWordBoundariesToNumbers(s)
	s = strings.Trim(s, " ")
	n := ""
	capNext := initCase
	for _, v := range s {
		if v >= 'A' && v <= 'Z' {
			n += string(v)
		}
		if v >= '0' && v <= '9' {
			n += string(v)
		}
		if v >= 'a' && v <= 'z' {
			if capNext {
				n += strings.ToUpper(string(v))
			} else {
				n += string(v)
			}
		}
		if v == '_' || v == ' ' || v == '-' || v == '.' {
			capNext = true
		} else {
			capNext = false
		}
	}
	return n
}

func Test_IdCodeMask(t *testing.T) {
	fmt.Println(IdCodeMask("232"))
}

func Test_MobileMask(t *testing.T) {
	fmt.Println(MobileMask("8613666666666"))
}
