/**
 * @Author: spruce
 * @Date: 2024-03-28 15:20
 * @Desc: 版本比较 测试
 */

package utils

import (
	"fmt"
	"testing"
)

func Test_Less(t *testing.T) {
	ok, err := Less("1.8", "1.5.0.0")
	fmt.Print(ok, err)
}

func Test_Greater(t *testing.T) {
	ok, err := Greater("1.8", "1.5.0.0")
	fmt.Print(ok, err)
}

func Test_Equal(t *testing.T) {
	ok, err := Equal("1.8", "1.8.0.1")
	fmt.Print(ok, err)
}

func Test_InRange(t *testing.T) {
	ok, err := InRange(">= 1.0, < 1.9", "1.8.0.1")
	fmt.Print(ok, err)
}

func Test_Sort(t *testing.T) {
	aa := Sort([]string{"1.1", "0.7.1", "1.4-release", "1.4-beta", "1.4", "2"})
	fmt.Print(aa)
}
