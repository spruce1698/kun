/**
 * @Author:
 * @Date: 2024-03-28 10:00
 * @Desc: encrypt rsa 测试
 */

package encrypt

import (
	"fmt"
	"testing"
)

var Pubkey = `-----BEGIN 公钥-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAk+89V7vpOj1rG6bTAKYM
56qmFLwNCBVDJ3MltVVtxVUUByqc5b6u909MmmrLBqS//PWC6zc3wZzU1+ayh8xb
UAEZuA3EjlPHIaFIVIz04RaW10+1xnby/RQE23tDqsv9a2jv/axjE/27b62nzvCW
eItu1kNQ3MGdcuqKjke+LKhQ7nWPRCOd/ffVqSuRvG0YfUEkOz/6UpsPr6vrI331
hWRB4DlYy8qFUmDsyvvExe4NjZWblXCqkEXRRAhi2SQRCl3teGuIHtDUxCskRIDi
aMD+Qt2Yp+Vvbz6hUiqIWSIH1BoHJer/JOq2/O6X3cmuppU4AdVNgy8Bq236iXvr
MQIDAQAB
-----END 公钥-----
`

var Pirvatekey = `-----BEGIN 私钥-----
MIIEpAIBAAKCAQEAk+89V7vpOj1rG6bTAKYM56qmFLwNCBVDJ3MltVVtxVUUByqc
5b6u909MmmrLBqS//PWC6zc3wZzU1+ayh8xbUAEZuA3EjlPHIaFIVIz04RaW10+1
xnby/RQE23tDqsv9a2jv/axjE/27b62nzvCWeItu1kNQ3MGdcuqKjke+LKhQ7nWP
RCOd/ffVqSuRvG0YfUEkOz/6UpsPr6vrI331hWRB4DlYy8qFUmDsyvvExe4NjZWb
lXCqkEXRRAhi2SQRCl3teGuIHtDUxCskRIDiaMD+Qt2Yp+Vvbz6hUiqIWSIH1BoH
Jer/JOq2/O6X3cmuppU4AdVNgy8Bq236iXvrMQIDAQABAoIBAQCCbxZvHMfvCeg+
YUD5+W63dMcq0QPMdLLZPbWpxMEclH8sMm5UQ2SRueGY5UBNg0WkC/R64BzRIS6p
jkcrZQu95rp+heUgeM3C4SmdIwtmyzwEa8uiSY7Fhbkiq/Rly6aN5eB0kmJpZfa1
6S9kTszdTFNVp9TMUAo7IIE6IheT1x0WcX7aOWVqp9MDXBHV5T0Tvt8vFrPTldFg
IuK45t3tr83tDcx53uC8cL5Ui8leWQjPh4BgdhJ3/MGTDWg+LW2vlAb4x+aLcDJM
CH6Rcb1b8hs9iLTDkdVw9KirYQH5mbACXZyDEaqj1I2KamJIU2qDuTnKxNoc96HY
2XMuSndhAoGBAMPwJuPuZqioJfNyS99x++ZTcVVwGRAbEvTvh6jPSGA0k3cYKgWR
NnssMkHBzZa0p3/NmSwWc7LiL8whEFUDAp2ntvfPVJ19Xvm71gNUyCQ/hojqIAXy
tsNT1gBUTCMtFZmAkUsjqdM/hUnJMM9zH+w4lt5QM2y/YkCThoI65BVbAoGBAMFI
GsIbnJDNhVap7HfWcYmGOlWgEEEchG6Uq6Lbai9T8c7xMSFc6DQiNMmQUAlgDaMV
b6izPK4KGQaXMFt5h7hekZgkbxCKBd9xsLM72bWhM/nd/HkZdHQqrNAPFhY6/S8C
IjRnRfdhsjBIA8K73yiUCsQlHAauGfPzdHET8ktjAoGAQdxeZi1DapuirhMUN9Zr
kr8nkE1uz0AafiRpmC+cp2Hk05pWvapTAtIXTo0jWu38g3QLcYtWdqGa6WWPxNOP
NIkkcmXJjmqO2yjtRg9gevazdSAlhXpRPpTWkSPEt+o2oXNa40PomK54UhYDhyeu
akuXQsD4mCw4jXZJN0suUZMCgYAgzpBcKjulCH19fFI69RdIdJQqPIUFyEViT7Hi
bsPTTLham+3u78oqLzQukmRDcx5ddCIDzIicMfKVf8whertivAqSfHytnf/pMW8A
vUPy5G3iF5/nHj76CNRUbHsfQtv+wqnzoyPpHZgVQeQBhcoXJSm+qV3cdGjLU6OM
HgqeaQKBgQCnmL5SX7GSAeB0rSNugPp2GezAQj0H4OCc8kNrHK8RUvXIU9B2zKA2
z/QUKFb1gIGcKxYr+LqQ25/+TGvINjuf6P3fVkHL0U8jOG0IqpPJXO3Vl9B8ewWL
cFQVB/nQfmaMa4ChK0QEUe+Mqi++MwgYbRHx1lIOXEfUJO+PXrMekw==
-----END 私钥-----
`

func Test_SetPublicKey(t *testing.T) {
	if err := RSA.SetPublicKey(Pubkey); err != nil {
		t.Error(err)
	}
}

func Test_SetPrivateKey(t *testing.T) {
	if err := RSA.SetPrivateKey(Pirvatekey); err != nil {
		t.Error(err)
	}
}

// 公钥加密私钥解密
func Test_PubEncryptPriDecrypt(t *testing.T) {
	if err := RSA.SetPublicKey(Pubkey); err != nil {
		t.Error(err)
	}
	if err := RSA.SetPrivateKey(Pirvatekey); err != nil {
		t.Error(err)
	}
	pubenctypt, err := RSA.PubKeyEncrypt(`hello world`)
	if err != nil {
		t.Error(err)
	}
	t.Log(pubenctypt)
	pridecrypt, err := RSA.PriKeyDecrypt(pubenctypt)
	if err != nil {
		t.Error(err)
	}
	t.Log(pridecrypt)
	if pridecrypt != `hello world` {
		t.Error(`不符合预期`)
	}
}

// 公钥解密私钥加密
func Test_PriEncryptPubDecrypt(t *testing.T) {
	if err := RSA.SetPublicKey(Pubkey); err != nil {
		t.Error(err)
	}
	if err := RSA.SetPrivateKey(Pirvatekey); err != nil {
		t.Error(err)
	}
	priEnctypt, err := RSA.PriKeyEncrypt(`hello world`)
	if err != nil {
		t.Error(err)
	}
	t.Log(priEnctypt)
	pubDecrypt, err := RSA.PubKeyDecrypt(priEnctypt)
	if err != nil {
		t.Error(err)
	}
	t.Log(pubDecrypt)
	if pubDecrypt != `hello world` {
		t.Error(`不符合预期`)
	}
}

// https://oktools.net/aes
// https://www.mklab.cn/utils/tripledes

func Test_AES(t *testing.T) {
	plainText := "abcd🤣efgh测试ij🤣OkLMNP1QW"
	encryptKey := "11111111111111111111111111111111"

	fmt.Println("===================================CBC=================================")

	data3, err := AESEncrypt(plainText, encryptKey)
	t.Log(data3, err)
	data4, err := AESDecrypt(data3, encryptKey)
	t.Log(data4, err)

	fmt.Println("====================================ECB================================")

	data7, err := AESEncryptECB(plainText, encryptKey)
	t.Log(data7, err)
	data8, err := AESDecryptECB(data7, encryptKey)
	t.Log(data8, err)

	fmt.Println("====================================CFB=================================")

	data11, err := AESEncryptCFB(plainText, encryptKey)
	t.Log(data11, err)
	data12, err := AESDecryptCFB(data11, encryptKey)
	t.Log(data12, err)

	fmt.Println("====================================CTR===================================")

	data13, err := AESEncryptCTR(plainText, encryptKey)
	t.Log(data13, err)
	data14, err := AESDecryptCTR(data13, encryptKey)
	t.Log(data14, err)

	fmt.Println("====================================OFB===================================")

	data15, err := AESEncryptOFB(plainText, encryptKey)
	t.Log(data15, err)
	data16, err := AESDecryptOFB(data15, encryptKey)
	t.Log(data16, err)
}

func Test_DES(t *testing.T) {
	plainText := "abcdefgh测试iV🤣jkLMNOPQW"
	encryptKey := "22222222"

	fmt.Println("===================================CBC=================================")

	data3, err := DESEncrypt(plainText, encryptKey)
	t.Log(data3, err)
	data4, err := DESDecrypt(data3, encryptKey)
	t.Log(data4, err)

	fmt.Println("====================================ECB================================")

	data7, err := DESEncryptECB(plainText, encryptKey)
	t.Log(data7, err)
	data8, err := DESDecryptECB(data7, encryptKey)
	t.Log(data8, err)

	fmt.Println("====================================CFB=================================")

	data11, err := DESEncryptCFB(plainText, encryptKey)
	t.Log(data11, err)
	data12, err := DESDecryptCFB(data11, encryptKey)
	t.Log(data12, err)

	fmt.Println("====================================CTR===================================")

	data13, err := DESEncryptCTR(plainText, encryptKey)
	t.Log(data13, err)
	data14, err := DESDecryptCTR(data13, encryptKey)
	t.Log(data14, err)

	fmt.Println("====================================OFB===================================")

	data15, err := DESEncryptOFB(plainText, encryptKey)
	t.Log(data15, err)
	data16, err := DESDecryptOFB(data15, encryptKey)
	t.Log(data16, err)
}

func Test_3DES(t *testing.T) {
	plainText := "abcdefgh测试ijkLMNOPQW"
	encryptKey := "123456789012345678901234"

	fmt.Println("===================================CBC=================================")

	data3, err := DES3Encrypt(plainText, encryptKey)
	t.Log(data3, err)
	data4, err := DES3Decrypt(data3, encryptKey)
	t.Log(data4, err)

	fmt.Println("====================================ECB================================")

	data7, err := DES3EncryptECB(plainText, encryptKey)
	t.Log(data7, err)
	data8, err := DES3DecryptECB(data7, encryptKey)
	t.Log(data8, err)

	fmt.Println("====================================CFB=================================")

	data11, err := DES3EncryptCFB(plainText, encryptKey)
	t.Log(data11, err)
	data12, err := DES3DecryptCFB(data11, encryptKey)
	t.Log(data12, err)

	fmt.Println("====================================CTR===================================")

	data13, err := DES3EncryptCTR(plainText, encryptKey)
	t.Log(data13, err)
	data14, err := DES3DecryptCTR(data13, encryptKey)
	t.Log(data14, err)

	fmt.Println("====================================OFB===================================")

	data15, err := DES3EncryptOFB(plainText, encryptKey)
	t.Log(data15, err)
	data16, err := DES3DecryptOFB(data15, encryptKey)
	t.Log(data16, err)
}

func Test_PBKDF2(t *testing.T) {
	signStr := PBKDF2("apidata/api/gk/score/special", "secret", 1e3, 4)
	t.Log(signStr)
}

func Test_MD5(t *testing.T) {
	t.Log(MD5("bb0a6b83b1f97378faf13b4e7b82a8f3"))
	t.Log(MD5to16("a"))
}

func Test_Sha256(t *testing.T) {
	t.Log(Sha256("123456", "abcdefIS9I9FZkJjTXJzPbw$0#&ux7RydUREDU"))
}
