package xconfig

import (
	"fmt"
	"os"
	"sync"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

const (
	EnvDebug   = "debug"
	EnvTest    = "test"
	EnvStaging = "staging"
	EnvRelease = "release"
)

var (
	once     sync.Once
	instance *Cnf = nil
)

type (
	Cnf struct {
		Env     string
		version string

		Server struct {
			Name         string
			Port         int64
			ReadTimeout  int64
			WriteTimeout int64
		}

		Log struct {
			Level    string
			FilePath string
			Stdout   bool
		}

		Mysql struct {
			LogLevel string
			Source   []string
		}

		Redis struct {
			Source   []string
			Password string
			Cluster  bool
		}

		Token struct {
			Secret        string
			RefreshSecret string
			Expire        int64
			Refresh       int64

			QueryKey   string
			CacheKey   string
			MultiLogin bool
		}
	}
)

func New(path string) *Cnf {
	if instance == nil {
		once.Do(func() {
			confPath := os.Getenv("CONF")
			if confPath == "" {
				confPath = path
			}
			v := viper.New()
			// 设置配置文件信息
			v.SetConfigFile(confPath) // 设置文件的类型

			// 读取配置文件
			if e := v.ReadInConfig(); e != nil {
				panic(fmt.Errorf("Fatal error config file: %s \n", e))
			}
			go v.WatchConfig()

			instance = &Cnf{}
			if e := v.Unmarshal(instance); e != nil {
				panic(fmt.Errorf("Fatal error config to Conf: %s \n", e))
			}
			// file 改变时载入
			v.OnConfigChange(func(event fsnotify.Event) {
				if e := v.Unmarshal(instance); e != nil {
					panic(fmt.Errorf("Fatal error config file changed: %s \n", e))
				}
			})
		})
	}
	return instance
}
