/**
* @Author: spruce
 * @Date: 2024-03-28 10:34
 * @Desc: jwt 签名,验签
*/

package token

import (
	"context"
	"encoding/json"
	"net/http"
	"regexp"
	"strconv"
	"sync"
	"time"

	"basic/pkg/encrypt"
	"basic/pkg/utils"
	"basic/pkg/xconfig"
	"basic/pkg/xlog"
	"basic/pkg/xredis"

	v5 "github.com/golang-jwt/jwt/v5"
)

const (
	ErrorMissingSecret uint32 = 1 << iota
	ErrorExpiredToken
	ErrorAuthorizeElsewhere
	ErrorEmptyAuthHeader
	ErrorMissingIatField
	ErrorMissingExpField
	ErrorInvalidPublicKey
	ErrorInvalidPrivateKey
	ErrorNoPublicKeyFile
	ErrorNoPrivateKeyFile
	ErrorInvalidSigningAlgorithm
	ErrorEmptyToken
	ErrorFailedTokenCreation
	ErrorInvalidToken
	ErrorTokenEmpty // 无效的token

	DefaultSecret        = "aa4faYss2adf32aa3sdfC1Ba1As2A2fd" // 32位
	DefaultRefreshSecret = "2C9u5nEM8w4GWVrcSQ6ZxhXftOvDHFkL" // 32位
	DefaultQuery         = "Authorization"
	DefaultCache         = "token:disuse:"

	TokenTypeAccess  = "somebody"
	TokenTypeRefresh = "refresh"
)

var (
	once     sync.Once
	instance *Jwt = nil

	ErrInvalidSigningAlgorithm = newError("invalid signing algorithm", ErrorInvalidSigningAlgorithm)
	ErrInvalidToken            = newError("token is invalid", ErrorInvalidToken)
	ErrEmptyToken              = newError("token is empty", ErrorEmptyToken)
	ErrMissingIatField         = newError("missing iat field", ErrorMissingIatField)
	ErrMissingExpField         = newError("missing exp field", ErrorMissingExpField)
	ErrExpiredToken            = newError("token is expired", ErrorExpiredToken)
)

type (
	Jwt struct {
		Cache         *xredis.Client // 缓存
		ExpireTime    time.Duration  // 过期时间,单位:s
		RefreshTime   time.Duration  // 刷新时间戳,单位:s
		Secret        string         // 加密密钥
		RefreshSecret string         // 刷新密钥
		QueryKey      string         // Token查找key
		CacheKey      string         // Token废弃缓存key
	}

	JwtToken struct {
		AccessToken     string // 访问token
		AccessExpireAt  int64  // 访问token过期时间戳
		RefreshToken    string // 刷新token
		RefreshExpireAt int64  // 刷新token过期时间戳
	}

	Payload struct {
		// TODO 可根据需要自行添加字段
		OrganizeId          int64 `json:"organizeId"`
		AccountId           int64 `json:"accountId"`
		GroupId             int64 `json:"groupId"`
		v5.RegisteredClaims       // 内嵌标准的声明
	}
)

// 创建
func NewJwt(cnf *xconfig.Cnf, log *xlog.Logger) *Jwt {
	if instance == nil {
		once.Do(
			func() {
				redis := xredis.New(cnf, log)
				if redis == nil {
					panic("token 需要redis的支持,请检查redis的配置")
				}
				instance = &Jwt{
					ExpireTime:    2 * time.Hour,
					RefreshTime:   24 * 7 * time.Hour,
					Secret:        DefaultSecret,
					RefreshSecret: DefaultRefreshSecret,
					QueryKey:      DefaultQuery,
					CacheKey:      DefaultCache,
					Cache:         redis,
				}

				if cnf.Token.QueryKey != "" {
					instance.QueryKey = cnf.Token.QueryKey
				}
				if len(cnf.Token.Secret) > 0 {
					instance.Secret = cnf.Token.Secret
				}
				if len(cnf.Token.RefreshSecret) > 0 {
					instance.RefreshSecret = cnf.Token.RefreshSecret
				}
				if cnf.Token.Expire > 0 {
					instance.ExpireTime = time.Duration(cnf.Token.Expire) * time.Second
				}
				if cnf.Token.Refresh > 0 {
					instance.RefreshTime = time.Duration(cnf.Token.Refresh) * time.Second
				}
			})
	}
	return instance
}

// 生成 token AccessToken和RefreshToken
func (j *Jwt) Gen(payload *Payload) (*JwtToken, error) {
	cTime := time.Now()

	id := utils.GenStr(0, 16)
	audience := utils.GenStr(1, 32)
	subject := encrypt.Sha256(strconv.FormatInt(payload.AccountId, 10), id+j.Secret)

	payload.RegisteredClaims = v5.RegisteredClaims{
		IssuedAt:  v5.NewNumericDate(cTime),                       // 颁发时间
		NotBefore: v5.NewNumericDate(cTime.Add(-1 * time.Second)), // 生效时间
		ExpiresAt: v5.NewNumericDate(cTime.Add(j.ExpireTime)),     // 过期时间
		Issuer:    TokenTypeAccess,                                // 签发人
		Subject:   subject,                                        // 主题 加密用户id
		ID:        id,                                             // id
		Audience:  []string{audience},                             // 受众
	}
	accessExpireAt := payload.RegisteredClaims.ExpiresAt.Unix()
	accessToken, err := v5.NewWithClaims(v5.SigningMethodHS384, payload).SignedString([]byte(j.Secret))
	if err != nil {
		return nil, err
	}

	// 刷新主题
	refreshId := utils.GenStr(0, 16)
	refSubjectStr, _ := json.Marshal(&struct {
		Subject   string
		ID        string
		Audience  string
		AccountId int64
	}{
		Subject:   subject,
		ID:        id,
		Audience:  audience,
		AccountId: payload.AccountId,
	})
	refSubject, _ := encrypt.AESEncrypt(string(refSubjectStr), encrypt.MD5(refreshId+j.RefreshSecret))
	payload.RegisteredClaims = v5.RegisteredClaims{
		IssuedAt:  v5.NewNumericDate(cTime),                              // 颁发时间
		NotBefore: v5.NewNumericDate(cTime.Add(-1 * time.Second)),        // 生效时间
		ExpiresAt: v5.NewNumericDate(cTime.Add(j.RefreshTime)),           // 过期时间
		Issuer:    TokenTypeRefresh,                                      // 签发人
		Subject:   encrypt.Sha256(refSubject, refreshId+j.RefreshSecret), // 主题,accessToken加密后的字符
		ID:        refreshId,                                             // id
		Audience:  []string{refSubject, encrypt.MD5(accessToken)},        // 受众
	}
	refreshExpireAt := payload.RegisteredClaims.ExpiresAt.Unix()
	refreshToken, err := v5.NewWithClaims(v5.SigningMethodHS384, payload).SignedString([]byte(j.RefreshSecret))
	if err != nil {
		return nil, err
	}

	return &JwtToken{
		AccessToken:     accessToken,     // 访问token
		AccessExpireAt:  accessExpireAt,  // 访问token过期时间戳
		RefreshToken:    refreshToken,    // 刷新token
		RefreshExpireAt: refreshExpireAt, // 刷新token过期时间戳
	}, nil
}

// 刷新token AccessToken和RefreshToken
func (j *Jwt) Refresh(tokenStr string) (*JwtToken, error) {
	claims, err := j.Parse(tokenStr, TokenTypeRefresh)
	if err != nil {
		return nil, err
	}
	if claims.Issuer != TokenTypeRefresh {
		return nil, ErrInvalidToken
	}

	if time.Now().Unix()-claims.IssuedAt.Unix() > 180 { // 新生成的token 3min内刷新不变
		return j.Gen(claims)
	}

	// 解析原的token
	accessJson, _ := encrypt.AESDecrypt(claims.Audience[0], encrypt.MD5(claims.ID+j.RefreshSecret))
	oldClaims := &struct {
		Subject   string
		ID        string
		Audience  string
		AccountId int64
	}{}
	if json.Unmarshal([]byte(accessJson), oldClaims) != nil {
		return nil, ErrInvalidToken
	}
	if oldClaims.AccountId != claims.AccountId {
		return nil, ErrInvalidToken
	}

	claims.NotBefore = v5.NewNumericDate(claims.IssuedAt.Time.Add(-1 * time.Second))
	claims.ExpiresAt = v5.NewNumericDate(claims.IssuedAt.Time.Add(j.ExpireTime))
	claims.Issuer = TokenTypeAccess
	claims.Subject = oldClaims.Subject
	claims.ID = oldClaims.ID
	claims.Audience = []string{oldClaims.Audience}

	accessToken, err := v5.NewWithClaims(v5.SigningMethodHS384, claims).SignedString([]byte(j.Secret))
	if err != nil {
		return nil, err
	}
	expireTime := claims.ExpiresAt.Time.Unix()
	refreshExpireTime := v5.NewNumericDate(claims.IssuedAt.Time.Add(j.RefreshTime)).Unix()

	return &JwtToken{
		AccessToken:     accessToken,       // 访问token
		AccessExpireAt:  expireTime,        // 访问token过期时间戳
		RefreshToken:    tokenStr,          // 刷新token
		RefreshExpireAt: refreshExpireTime, // 刷新token过期时间戳
	}, nil
}

// 查找
func (j *Jwt) Find(r *http.Request) string {
	// 从HEADER中获取TOKEN
	tokenStr := r.Header.Get(j.QueryKey)
	if tokenStr != "" {
		return tokenStr
	}
	// 从QUERY中获取TOKEN
	tokenStr = r.URL.Query().Get(j.QueryKey)
	if tokenStr != "" {
		return tokenStr
	}
	// 从PARAM中获取TOKEN
	tokenStr = r.Form.Get(j.QueryKey)
	if tokenStr != "" {
		return tokenStr
	}
	// 从COOKIE中获取TOKEN
	cookie, _ := r.Cookie(j.QueryKey)
	if cookie != nil {
		tokenStr = cookie.String()
		if tokenStr != "" {
			return tokenStr
		}
	}
	return ""
}

// 解析
func (j *Jwt) Parse(tokenStr string, optType ...string) (*Payload, error) {
	cTime := time.Now()
	tokenStr = regexp.MustCompile(`(?i)Bearer `).ReplaceAllString(tokenStr, "")
	if tokenStr == "" {
		return nil, ErrEmptyToken
	}
	// tokenStr 在黑名单
	hasBlacklist, _ := j.Cache.Exists(context.Background(), j.CacheKey+encrypt.MD5(tokenStr)).Result()
	if hasBlacklist > 0 {
		return nil, ErrInvalidToken
	}

	// 解析 token
	payload := &Payload{}
	if len(optType) > 0 && optType[0] == TokenTypeRefresh {
		claim, err := v5.ParseWithClaims(tokenStr, payload, func(token *v5.Token) (any, error) {
			return []byte(j.RefreshSecret), nil
		})
		if err != nil || !claim.Valid {
			return nil, ErrInvalidToken
		}
		// 判断token类型是否错误  防止 AccountId或Subject被篡改
		if payload.Issuer != TokenTypeRefresh ||
			len(payload.Audience) <= 0 ||
			payload.Audience[0] == "" ||
			payload.Subject == "" ||
			payload.Subject != encrypt.Sha256(payload.Audience[0], payload.ID+j.RefreshSecret) {
			return nil, ErrInvalidToken
		}
	} else {
		claim, err := v5.ParseWithClaims(tokenStr, payload, func(token *v5.Token) (any, error) {
			return []byte(j.Secret), nil
		})
		// 对token对象中的Claim进行类型断言
		if err != nil || !claim.Valid { // 校验token
			return nil, ErrInvalidToken
		}

		// 判断token类型是否错误  防止 AccountId或Subject被篡改
		if payload.Issuer != TokenTypeAccess ||
			payload.Subject == "" ||
			payload.Subject != encrypt.Sha256(strconv.FormatInt(payload.AccountId, 10), payload.ID+j.Secret) {
			return nil, ErrInvalidToken
		}
	}

	// 是否还未生效 生效时间大于过期时间
	if payload.NotBefore.After(cTime) {
		return nil, ErrInvalidToken
	}
	// 是否过期 过期时间小于当前时间
	if payload.ExpiresAt.Before(cTime) {
		return nil, ErrExpiredToken
	}

	// id在黑名单
	hasBlacklist, _ = j.Cache.Exists(context.Background(), j.CacheKey+encrypt.MD5(strconv.FormatInt(payload.AccountId, 10))).Result()
	if hasBlacklist > 0 {
		return nil, ErrInvalidToken
	}

	return payload, nil
}

// 废弃 的值可以是accountId;也可以是整个key  expiration 为过期时间
func (j *Jwt) Disuse(value string, expiration int64) error {
	cacheKey := j.CacheKey + encrypt.MD5(value)
	_, err := j.Cache.SetNX(context.Background(), cacheKey, 1, time.Duration(expiration)*time.Second).Result()
	return err
}

// 取消 废弃
func (j *Jwt) CancelDisuse(value string) error {
	cacheKey := j.CacheKey + encrypt.MD5(value)
	_, err := j.Cache.Del(context.Background(), cacheKey).Result()
	return err
}
