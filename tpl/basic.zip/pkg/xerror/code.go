/**
 * @Author:
 * @Date: 2024-03-28 15:06
 * @Desc: response 错误编码
 */

package xerror

// 定义错误码
const (
	Success      int = 0   // 成功
	Unauthorized int = 401 // 未授权
	NotFoundPath int = 404 // 地址不存在
	Unknown      int = 500 // 未知错误,服务不可用

	AuthError      int = 20100 // 授权信息错误
	AuthTimeOut    int = 20101 // 授权信息超时
	AuthRefreshErr int = 20102 // 刷新token失败

	PermitError int = 20110 // 权限错误

	ParamError int = 30000 // 请求参数错误

	BusinessError int = 50000 // 业务处理失败

)

var CodeMap = map[int]string{
	Success:      "成功",
	Unauthorized: "未知授权信息",
	NotFoundPath: "地址不存在",
	Unknown:      "未知错误,服务不可用",

	AuthError:      "授权信息错误",
	AuthTimeOut:    "授权信息超时",
	AuthRefreshErr: "刷新token失败",

	PermitError: "权限错误",

	ParamError: "请求参数错误",

	BusinessError: "服务器错误",
}
