/**
 * @Author: spruce
 * @Date: 2024-04-07 15:34
 * @Desc: TODO
 */

package server

import (
	"os"
	"os/signal"
	"syscall"

	"basic/pkg/xlog"
)

type Engine interface {
	Start() error
	Stop()
}

type Svr struct {
	logger *xlog.Logger
	eng    Engine
}

func New(log *xlog.Logger, eng Engine) *Svr {
	return &Svr{
		logger: log,
		eng:    eng,
	}
}

// Start server
func (s *Svr) Start() error {
	if err := s.eng.Start(); err != nil {
		s.logger.Error("server start error", xlog.Error(err))
		return err
	}
	return nil
}

// Await signal for exit server
func (s *Svr) AwaitSignal() {
	sigCh := make(chan os.Signal, 1)
	signal.Reset(syscall.SIGKILL, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)
	signal.Notify(sigCh, syscall.SIGKILL, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)
	sig := <-sigCh
	s.logger.Warn("receive a signal", xlog.String("signal", sig.String()))
	s.eng.Stop()
	os.Exit(0)
}
