/**
 * @Author:
 * @Date: 2022-04-29 15:06
 * @Desc: 统一输出
 */

package xhttp

import (
	"errors"
	"net/http"

	"basic/pkg/xerror"

	"github.com/gin-gonic/gin"
)

type (
	Response struct {
		Code    int    `json:"code"`    // 错误码,非0为错误
		Message string `json:"message"` // 错误消息
	}
	RespData struct {
		Response
		Data any `json:"data"` // 响应数据
	}
	RespList struct {
		Response
		Total    int64 `json:"total"`    // 总条数
		Items    any   `json:"items"`    // 数据列表
		Page     int64 `json:"page"`     // 当前页
		PageSize int64 `json:"pageSize"` // 每页数据
	}
	RespMore struct {
		Response
		Total    int64 `json:"total"`    // 总条数
		Items    any   `json:"items"`    // 数据列表
		Page     int64 `json:"page"`     // 当前页
		PageSize int64 `json:"pageSize"` // 每页数据
		HasMore  bool  `json:"hasMore"`  // 是否还有 true 还有下一页
	}
)

// 请求繁忙
func TooRequest(ctx *gin.Context) {
	r := &Response{
		Code:    http.StatusServiceUnavailable,
		Message: "Too many request.",
	}
	ctx.JSON(http.StatusServiceUnavailable, r)
}

// 未知授权
func AuthFail(ctx *gin.Context, code ...int) {
	r := &RespData{
		Data: "",
	}
	r.Code = xerror.Unauthorized
	if len(code) > 0 {
		r.Code = code[0]
	}
	r.Message = xerror.CodeMap[r.Code]
	ctx.JSON(http.StatusUnauthorized, r)
}

// 未找到路由
func WithNotFoundPath(ctx *gin.Context) {
	r := &RespData{
		Data: "",
	}
	r.Code = xerror.NotFoundPath
	r.Message = xerror.CodeMap[xerror.NotFoundPath]

	ctx.JSON(http.StatusNotFound, r)
}

// 业务错误
func BusFail(ctx *gin.Context, err error) {
	r := &RespData{
		Data: "",
	}
	r.Code = xerror.BusinessError
	r.Message = err.Error()

	var e xerror.Error
	if ok := errors.As(err, &e); ok {
		r.Code = e.Code()
		r.Message = e.Error()
	}

	ctx.JSON(http.StatusOK, r)
}

// 业务code
func BusCode(ctx *gin.Context, code int, message string, data ...any) {
	r := &RespData{
		Data: "",
	}
	if len(data) > 0 {
		r.Data = data[0]
	}
	r.Code = code
	r.Message = message

	if r.Message == "" {
		r.Message = xerror.CodeMap[code]
	}

	ctx.JSON(http.StatusOK, r)
}

// 返回数据
func Data(ctx *gin.Context, message string, data any) {
	r := &RespData{
		Data: data,
	}
	r.Code = xerror.Success
	r.Message = message

	if r.Message == "" {
		r.Message = xerror.CodeMap[xerror.Success]
	}

	ctx.JSON(http.StatusOK, r)
}

// 返回分页列表
func List(ctx *gin.Context, message string, total, page, pageSize int64, items any) {
	r := &RespList{
		Total:    total,
		Items:    items,
		Page:     page,
		PageSize: pageSize,
	}
	r.Code = xerror.Success
	r.Message = message

	if r.Message == "" {
		r.Message = xerror.CodeMap[xerror.Success]
	}

	ctx.JSON(http.StatusOK, r)
}

// 返回更多列表
func More(ctx *gin.Context, message string, total, page, pageSize int64, hasMore bool, items any) {
	r := &RespMore{
		Total:    total,
		Items:    items,
		Page:     page,
		PageSize: pageSize,
		HasMore:  hasMore,
	}
	r.Code = xerror.Success
	r.Message = message

	if r.Message == "" {
		r.Message = xerror.CodeMap[xerror.Success]
	}

	ctx.JSON(http.StatusOK, r)
}
