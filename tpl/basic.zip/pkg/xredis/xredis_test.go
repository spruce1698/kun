/**
 * @Author: spruce
 * @Date: 2024-03-28 13:45
 * @Desc: redis test
 */

package xredis

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"
	"time"

	"basic/pkg/xconfig"
)

var cnf = &xconfig.Cnf{
	Redis: struct {
		Source   []string
		Password string
		Cluster  bool
	}{
		Source:   []string{"127.0.0.1:6379"},
		Password: "1cVeQ26GhlUSsRmx",
		Cluster:  false,
	},
}

func Test_Redis(t *testing.T) {
	result, _ := New(cnf, nil).Set(context.Background(), "asdf", 1, 0).Result()
	fmt.Println(result)
}

func Test_Redis1(t *testing.T) {

	userCache := Student{"uuid": "steadfastness", "refreshTime": time.Now().Unix() + 500000}

	aa, err := New(cnf, nil).HMSet(context.TODO(), "cacheKey", userCache, time.Duration(1000000)*time.Second).Result()
	fmt.Println(aa)
	fmt.Println(err)

	ab, err := New(cnf, nil).HSet(context.TODO(), "cacheKey1", "key", "value", "key1", "value1").Result()
	fmt.Println(ab)
	fmt.Println(err)
}

type Student map[string]any

func (s Student) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func (s Student) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, &s)
}
