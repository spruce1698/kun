/**
 * @Author:
 * @Date: 2024-03-28 13:45
 * @Desc: redis
 */

package xredis

import (
	"context"
	"fmt"
	"sync"
	"time"

	"basic/pkg/xconfig"
	"basic/pkg/xlog"

	"github.com/redis/go-redis/v9"
)

var (
	once     sync.Once
	instance *Client = nil
)

const Nil = redis.Nil

type Client struct {
	redis.UniversalClient
}

func New(cnf *xconfig.Cnf, log *xlog.Logger) *Client {
	if instance == nil {
		once.Do(func() {

			if len(cnf.Redis.Source) == 0 {
				panic("redis 配置错误")
			}

			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			if cnf.Redis.Cluster {
				client := redis.NewClusterClient(&redis.ClusterOptions{
					Addrs:    cnf.Redis.Source,
					Password: cnf.Redis.Password,
					PoolSize: 100,
				})
				instance = &Client{client}
			} else {
				client := redis.NewClient(&redis.Options{
					Addr:     cnf.Redis.Source[0],
					Password: cnf.Redis.Password, // no password set
					PoolSize: 100,                // 连接池大小
				})
				instance = &Client{client}
			}
			_, err := instance.Ping(ctx).Result()
			if err != nil {
				msg2Log(log, fmt.Sprintf("ping redis[%v]失败, error: %v \n", cnf.Redis.Source[0], err.Error()))
				return
			}
		})
	}
	return instance
}

func msg2Log(log *xlog.Logger, msg string) {
	if log != nil {
		log.Fatal(msg)
	} else {
		panic(msg)
	}
}
