/**
 * @Author:
 * @Date: 2024-03-28 14:31
 * @Desc: 自定义日志选项
 */

package xlog

import (
	"io"
	"os"
	"path/filepath"

	"go.uber.org/zap/zapcore"
	"gopkg.in/natefinch/lumberjack.v2"
)

// custom setup config
type Option func(*option)

type option struct {
	level          zapcore.Level
	fileHook       io.Writer
	timeLayout     string
	disableConsole bool
}

func newOption(opts ...Option) *option {
	opt := &option{
		level:          zapcore.DebugLevel,
		timeLayout:     "2006-01-02 15:04:05",
		disableConsole: false,
	}
	for _, o := range opts {
		o(opt)
	}
	return opt
}

// only greater than 'level' will output
func withDebugLevel() Option {
	return func(opt *option) {
		opt.level = zapcore.DebugLevel
	}
}

// only greater than 'level' will output
func withInfoLevel() Option {
	return func(opt *option) {
		opt.level = zapcore.InfoLevel
	}
}

// only greater than 'level' will output
func withWarnLevel() Option {
	return func(opt *option) {
		opt.level = zapcore.WarnLevel
	}
}

// only greater than 'level' will output
func withErrorLevel() Option {
	return func(opt *option) {
		opt.level = zapcore.ErrorLevel
	}
}

// Write a log to some file
func withFilePath(filePath string) Option {
	dir := filepath.Dir(filePath)
	if err := os.MkdirAll(dir, 0766); err != nil {
		panic(err)
	}
	return func(opt *option) {
		opt.fileHook = &lumberjack.Logger{ // concurrent-safety
			Filename:   filePath, // 文件路径
			MaxSize:    128,      // 单个文件最大尺寸，默认单位 M，超过则切割
			MaxBackups: 100,      // 最多保留 100 个备份
			MaxAge:     30,       // 最大时间，默认单位 day
			LocalTime:  true,     // 使用本地时间
			Compress:   true,     // 是否压缩 disabled by default
		}
	}
}

// Write a log to os.Stdout or os.Stderr
func withDisableConsole() Option {
	return func(opt *option) {
		opt.disableConsole = true
	}
}
