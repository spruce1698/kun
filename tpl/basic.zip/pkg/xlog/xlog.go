/**
 * @Author:
 * @Date: 2024-03-28 13:45
 * @Desc: logger
 */

package xlog

import (
	"os"
	"strings"

	"basic/pkg/xconfig"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

type Logger = zap.Logger

func New(cnf *xconfig.Cnf) *Logger {
	zapCoreSet := zapCores(cnf.Log.Level, cnf.Log.FilePath, cnf.Log.Stdout)
	logger := zap.New(
		zapcore.NewTee(zapCoreSet...),
		zap.AddCaller(), // 显示打日志点的文件名和行数
		zap.AddStacktrace(zap.ErrorLevel),
		zap.AddCallerSkip(0), // 避免zap始终将包装器(wrapper)代码报告为调用方。
	)
	zap.ReplaceGlobals(logger) // 替换zap包中全局的logger实例，后续在其他包中只需使用zap.L()调用即可

	// 异步写入
	_ = logger.Sync()

	return logger
}
func zapCores(level, filePath string, stdout bool) []zapcore.Core {
	opSet := make([]Option, 0)
	if !stdout {
		opSet = append(opSet, withDisableConsole())
	}

	switch strings.ToLower(level) {
	case "debug":
		opSet = append(opSet, withDebugLevel())
	case "info":
		opSet = append(opSet, withInfoLevel())
	case "warn":
		opSet = append(opSet, withWarnLevel())
	case "error":
		opSet = append(opSet, withErrorLevel())
	}

	if filePath != "" {
		opSet = append(opSet, withFilePath(filePath))
	}
	opt := newOption(opSet...)
	// similar to zap.NewProductionEncoderConfig()
	encoderConfig := zapcore.EncoderConfig{
		TimeKey:        "time",
		LevelKey:       "level",
		NameKey:        "logger", // used by logger.Named(key); optional; useless
		CallerKey:      "caller",
		MessageKey:     "msg",
		StacktraceKey:  "trace", // use by zap.AddStacktrace; optional; useless
		LineEnding:     zapcore.DefaultLineEnding,
		EncodeLevel:    zapcore.LowercaseLevelEncoder, // 小写编码器
		EncodeTime:     zapcore.TimeEncoderOfLayout(opt.timeLayout),
		EncodeDuration: zapcore.SecondsDurationEncoder,
		EncodeCaller:   zapcore.ShortCallerEncoder, // 包名:文件名
	}

	// 创建具体的 zapCore.Core
	var cores []zapcore.Core
	if !opt.disableConsole {
		encoderConfig.EncodeLevel = zapcore.LowercaseColorLevelEncoder
		encoderConfig.EncodeCaller = zapcore.FullCallerEncoder     // 全路径编码器
		consoleEncoder := zapcore.NewConsoleEncoder(encoderConfig) // 控制台格式
		cores = append(cores, zapcore.NewCore(consoleEncoder, zapcore.AddSync(os.Stdout), opt.level))
	}

	if opt.fileHook != nil {
		jsonEncoder := zapcore.NewJSONEncoder(encoderConfig) // json格式
		cores = append(cores, zapcore.NewCore(jsonEncoder, zapcore.AddSync(opt.fileHook), opt.level))
	}
	return cores
}

func String(key string, val string) zap.Field {
	return zap.Field{Key: key, Type: zapcore.StringType, String: val}
}
func Int(key string, val int) zap.Field {
	return zap.Int64(key, int64(val))
}
func Any(key string, val any) zap.Field {
	return zap.Any(key, val)
}
func L() *zap.Logger {
	return zap.L()
}
func Error(err error) zap.Field {
	return zap.NamedError("error", err)
}
