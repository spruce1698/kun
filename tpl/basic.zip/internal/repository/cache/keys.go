package cache

// CacheKey 缓存键同一管理
const (
	DemoInfoKey = "demo:%d"

	// cas
	CasServiceKey      = "casService:%d:%s"
	CasUserKey         = "casUser:%d"
	CasTicketKey       = "casTicket:%d"
	CasCasTicketIOUKey = "casTicketIOU"
	// oauth
	OauthServiceKey = "oauthService:%d"
	OauthUserKey    = "oauthUser:%d"
	OauthCodeKey    = "oauthCode"
	OauthTokenKey   = "oauthToken"
)
