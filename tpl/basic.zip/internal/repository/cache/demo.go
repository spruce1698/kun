/**
 * @Author: spruce
 * @Date: 2024-03-28 21:36
 * @Desc: demo cache
 */

package cache

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"basic/pkg/xredis"

	"github.com/pkg/errors"
)

var _ DemoRepo = (*defaultDemoRepo)(nil)

type (
	DemoRepo interface {
		// 添加缓存
		Set(ctx context.Context, id int64, data *Demo, expiration int64) (err error)
		Get(ctx context.Context, id int64) (data *Demo, err error)
	}
	//  Demo缓存数据
	Demo struct {
		Id    int64
		Name  string // 名称
		Test4 int32  // 测试4
	}

	defaultDemoRepo struct {
		infoKey string // 缓存key
		common  *xredis.Client
	}
)

func NewDemoRepo(c *xredis.Client) DemoRepo {
	return &defaultDemoRepo{
		infoKey: "demo:%d",
		common:  c,
	}
}

func (r *defaultDemoRepo) Set(ctx context.Context, id int64, data *Demo, expiration int64) (err error) {
	key := fmt.Sprintf(r.infoKey, id)
	value, valueErr := json.Marshal(data)
	if valueErr != nil {
		return valueErr
	}
	err = r.common.Set(ctx, key, string(value), time.Duration(expiration)*time.Second).Err()
	if err != nil {
		return err
	}
	return nil
}

func (r *defaultDemoRepo) Get(ctx context.Context, id int64) (data *Demo, err error) {
	key := fmt.Sprintf(r.infoKey, id)
	info := r.common.Get(ctx, key).Val()
	if len(info) == 0 {
		return nil, errors.New("获取demo缓存错误")
	}
	err = json.Unmarshal([]byte(info), &data)
	if err != nil {
		return nil, err
	}
	return data, nil
}
