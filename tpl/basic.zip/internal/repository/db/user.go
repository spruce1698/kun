package db

//go:generate mockgen -source=./user.go -destination=../../../test/mocks/repository/db/user.go  -package mock_db_repo -aux_files db=./user_gen.go

var _ UserRepo = (*customUser)(nil)

type (
	UserRepo interface {
		userRepo
	}

	customUser struct {
		*defaultUser
	}
)

func NewUserRepo(c *Conn) UserRepo {
	return &customUser{
		defaultUser: newUserRepo(c),
	}
}
