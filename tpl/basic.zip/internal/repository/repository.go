/**
 * @Author: spruce
 * @Date: 2024-04-10 13:57
 * @Desc: 存储wire配置
 */

package repository

import (
	"basic/internal/repository/db"

	"github.com/google/wire"
)

// 存储层   // TODO 需要手动增加 后执行 wire
var InjectSet = wire.NewSet(
	db.NewUserRepo,
)
