/**
 * @Author: spruce
 * @Date: 2024-04-10 13:57
 * @Desc: 存储wire配置
 */

package repository

import (
	"basic/internal/repository/db"

	"github.com/google/wire"
)

// ====================== TODO 需要手动配置  存储层 修改后重新wire ======================

// 存储层
var WireSet = wire.NewSet(
	db.NewUserRepo,
)
