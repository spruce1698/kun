package mysql

//go:generate mockgen -source=./user.go -destination=../../../test/mocks/repository/mysql/user.go  -package mock_repo_mysql -aux_files mysql=./user_gen.go

var _ UserRepo = (*customUser)(nil)

type (
	UserRepo interface {
		userRepo
	}

	customUser struct {
		*defaultUser
	}
)

func NewUserRepo(c *Conn) UserRepo {
	return &customUser{
		defaultUser: newUserRepo(c),
	}
}
