package mysql

import (
	"context"
	"fmt"
	"strings"

	"basic/pkg/xdb"

	"gorm.io/gorm"
)

//go:generate mockgen -source=./mysql.go -destination=../../../test/mocks/repository/mysql/mysql.go  -package mock_repo_mysql

const (
	ctxDbKey              = "DbKey"
	defaultPageSize int64 = 20
)

var (
	ErrNotFound = gorm.ErrRecordNotFound
)

type (
	Conn struct {
		conn *xdb.Client
	}

	SearchPage struct {
		OrderField string `json:"orderField"` // 排序字段
		OrderType  int64  `json:"orderType"`  // 排序类型
		Page       int64  `json:"page"`       // 当前页
		PageSize   int64  `json:"pageSize"`   // 每页条数
	}
)

func NewConn(cli *xdb.Client) *Conn {
	return &Conn{
		conn: cli,
	}
}

func (r *Conn) WithContext(ctx context.Context) *xdb.Client {
	v := ctx.Value(ctxDbKey)
	if v != nil {
		if tx, ok := v.(*xdb.Client); ok {
			return tx
		}
	}
	return r.conn.WithContext(ctx)
}

func NewConnTx(r *Conn) ConnTx {
	return r
}

type ConnTx interface {
	ConnTx(ctx context.Context, fn func(ctx context.Context) error) error
}

func (r *Conn) ConnTx(ctx context.Context, fn func(ctx context.Context) error) error {
	return r.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		ctx = context.WithValue(ctx, ctxDbKey, tx)
		return fn(ctx)
	})
}

// 获取 排序字段(manager专用)
func (r *Conn) HandleRank(orderField string, orderType int64, defaultOrder string) (orderStr string) {
	orderStr = defaultOrder
	if orderField != "" &&
		strings.Count(orderField, ".``") < 0 &&
		strings.Index(orderField, ".") != len(orderField) {
		orderStr = orderField
	}
	if orderType > 0 {
		orderStr = fmt.Sprintf(" %s  DESC", orderStr)
	} else {
		orderStr = fmt.Sprintf(" %s  ASC", orderStr)
	}
	return orderStr
}

func (r *Conn) HandlePage(page, pageSize int64) (offset, limit int) {
	if pageSize <= 0 {
		pageSize = defaultPageSize
	}
	limit = int(pageSize)
	offset = int((page - 1) * pageSize)
	if offset <= 0 {
		offset = 0
	}
	return
}
