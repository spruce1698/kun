package controller

import (
	"fmt"

	"basic/internal/global"
	"basic/internal/logic"
	"basic/pkg/xerror"
	"basic/pkg/xhttp"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/copier"
)

type (
	DemoCtl struct {
		demoLogic logic.DemoLogic
	}

	loginReq struct {
		Phone string `json:"phone" binding:"required"`
		Code  string `json:"code" binding:"required"`
	}

	account struct {
		Nickname string `json:"nickname"` // 昵称
		Avatar   string `json:"avatar"`   // 头像图片路径
	}

	authResp struct {
		Account         *account `json:"account,omitempty"`
		AccessToken     string   `json:"accessToken,omitempty"`     // 访问token
		AccessExpireAt  int64    `json:"accessExpireAt,omitempty"`  // 访问token过期时间戳
		RefreshToken    string   `json:"refreshToken,omitempty"`    // 刷新token
		RefreshExpireAt int64    `json:"refreshExpireAt,omitempty"` // 刷新token过期时间戳
	}

	getOne struct {
		Id  int64  `form:"id"  binding:"gte=1,lte=130"`
		Min string `form:"min" binding:"required,minNow"`
		Max string `form:"max" binding:"required,maxNow"`
	}
)

func NewDemoCtl(demoLogic logic.DemoLogic) *DemoCtl {
	return &DemoCtl{
		demoLogic: demoLogic,
	}
}

// @Summary GetOne
// @Description 获取一个demo
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "demoID"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /api/demo/one [get]
func (c *DemoCtl) GetOne(ctx *gin.Context) {
	fmt.Println(ctx.ClientIP())
	req := &getOne{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}

	info, err := c.demoLogic.GetOne(req.Id)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println(info)
	xhttp.Data(ctx, "GetDemo成功", info)
}

// 短信登录
func (c *DemoCtl) Login(ctx *gin.Context) {
	req := &loginReq{}
	if err := ctx.ShouldBindJSON(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}

	accountBase, token, err := c.demoLogic.Login(req.Phone, req.Code)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	accountData := &account{}
	_ = copier.Copy(accountData, accountBase)

	result := &authResp{
		Account:         accountData,
		AccessToken:     token.AccessToken,
		AccessExpireAt:  token.AccessExpireAt,
		RefreshToken:    token.RefreshToken,
		RefreshExpireAt: token.RefreshExpireAt,
	}
	xhttp.Data(ctx, "登录成功", result)
}

func (c *DemoCtl) RefreshToken(ctx *gin.Context) {
	token := ctx.Value(global.CtxAuthToken)
	if token != nil && token.(string) != "" {
		result := c.demoLogic.RefreshToken(token.(string))
		if result == nil {
			xhttp.AuthFail(ctx, xerror.AuthRefreshErr)
			return
		}
		xhttp.Data(ctx, "刷新Token成功", result)
		return
	}
	xhttp.AuthFail(ctx)
}
