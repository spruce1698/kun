package controller

import (
	"basic/internal/service"
	"basic/pkg/xerror"
	"basic/pkg/xhttp"

	"github.com/gin-gonic/gin"
)

type (
	UserCtl struct {
		userSvc service.UserSvc
	}
)

func NewUserCtl(userSvc service.UserSvc) *UserCtl {
	return &UserCtl{
		userSvc: userSvc,
	}
}

// @Summary GetUserById
// @Description 获取一个 User
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "userID"
// @Success 200 {string} string "{"code":0,"message":"GetUser成功","data":{"id":1,"username":"name","email":"name@email.com"}}"
// @Failure 500 {string} string "{"code":50000,"message":"GetUserById失败","data":""}"
// @Router /api/user [get]
func (c *UserCtl) GetUserById(ctx *gin.Context) {
	var params struct {
		Id int64 `form:"id" binding:"required"`
	}
	if err := ctx.ShouldBind(&params); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err.Error())
		return
	}

	data, err := c.userSvc.GetUserById(params.Id)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "GetUser成功", data)
}
