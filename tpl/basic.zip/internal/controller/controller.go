/**
 * @Author: spruce
 * @Date: 2024-04-10 20:45
 * @Desc: 控制器层 wire配置
 */

package controller

import (
	"github.com/google/wire"
)

// ====================== TODO 需要手动配置  http 控制器层 修改后重新wire ======================

// 控制器列表
type ServerCtl struct {
	UserCtl *UserCtl
}

// 控制层
var WireServerSet = wire.NewSet(
	NewUserCtl,
)
