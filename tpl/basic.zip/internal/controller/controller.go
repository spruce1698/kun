/**
 * @Author: spruce
 * @Date: 2024-04-10 20:45
 * @Desc: 控制器配置 按需配置 wire
 */

package controller

import (
	"github.com/google/wire"
)

// 控制器列表  // TODO 需要手动增加 后执行 wire
type CtlSet struct {
	UserCtl *UserCtl
}

// 控制层  // TODO 需要手动增加 后执行 wire
var InjectSet = wire.NewSet(
	NewUserCtl,
)
