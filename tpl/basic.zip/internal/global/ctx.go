/**
* @Author: spruce
 * @Date: 2024-03-28 16:45
 * @Desc: ctx key 值
*/

package global

const (
	CtxAuthToken     string = "Auth.Token"
	CtxAuthAccountId string = "Auth.AccountId" // int64
)
