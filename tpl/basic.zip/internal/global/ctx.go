/**
* @Author: spruce
 * @Date: 2024-03-28 16:45
 * @Desc: ctx key 值
*/

package global

const (
	CtxAuthToken      string = "Auth.Token"
	CtxAuthOrganizeId string = "Auth.OrganizeId"
	CtxAuthAccountId  string = "Auth.AccountId"
	CtxAuthGroupId    string = "Auth.GroupId"
	CtxAuthFormat     string = "%d-%d-%d" // mgr auth 格式化字符串 orgId-accountId-groupId
)
