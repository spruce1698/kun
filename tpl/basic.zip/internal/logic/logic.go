/**
 * @Author: albert
 * @Date: 2024-07-02
 * @Desc: Base logic
 */

package logic

import (
	"basic/internal/repository/mysql"
	"basic/pkg/xconfig"
	"basic/pkg/xlog"
)

type Logic struct {
	cnf    *xconfig.Cnf
	logger *xlog.Logger

	tx mysql.ConnTx
}

func BaseLogic(cnf *xconfig.Cnf, log *xlog.Logger, tx mysql.ConnTx) *Logic {
	return &Logic{
		cnf:    cnf,
		logger: log,
		tx:     tx,
	}
}
