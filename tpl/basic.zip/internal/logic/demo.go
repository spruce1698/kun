package logic

import (
	"context"
	"fmt"

	"basic/internal/repository/cache"
	"basic/internal/repository/mysql"
	"basic/pkg/token"
	"basic/pkg/xerror"

	"github.com/jinzhu/copier"
	"github.com/pkg/errors"
)

var _ DemoLogic = (*demoLogic)(nil)

type (
	DemoLogic interface {
		GetOne(id int64) (result *Demo, err error)

		Login(phone, code string) (accountData *Account, jwtToken *JwtToken, err error)

		RefreshToken(tokenStr string) (jwtToken *JwtToken)
	}

	demoLogic struct {
		*Logic
		demoMysql mysql.DemoRepo
		demoCache cache.DemoRepo
	}

	JwtToken struct {
		AccessToken     string `json:"accessToken"`     // 访问token
		AccessExpireAt  int64  `json:"accessExpireAt"`  // 访问token过期时间戳
		RefreshToken    string `json:"refreshToken"`    // 刷新token
		RefreshExpireAt int64  `json:"refreshExpireAt"` // 刷新token过期时间戳
	}

	Account struct {
		Id         int64   `json:"id"`         // 账号id
		OrganizeId int64   `json:"organizeId"` // 组织机构id
		GroupId    *int64  `json:"groupId"`    // 帐号分组id
		Nickname   *string `json:"nickname"`   // 昵称
	}

	Demo struct {
		Id    int64  `json:"id"`
		Name  string `json:"name"`
		Test4 int32  `json:"test4"`
	}
)

func NewDemoLogic(logic *Logic, demoMysql mysql.DemoRepo, demoCache cache.DemoRepo) DemoLogic {
	return &demoLogic{
		Logic:     logic,
		demoMysql: demoMysql,
		demoCache: demoCache,
	}
}

func (l *demoLogic) GetOne(id int64) (result *Demo, err error) {
	ctx := context.Background()
	if id > 0 {
		result = &Demo{}
		demo, cacheErr := l.demoCache.Get(ctx, id)
		if cacheErr != nil {
			l.logger.Info(fmt.Sprintf("GetOne 失败:err %v \n", cacheErr))
			demo1, dbErr := l.demoMysql.FindOne(ctx, id)
			if dbErr != nil {
				if errors.Is(dbErr, mysql.ErrNotFound) {
					return nil, xerror.NewError(xerror.BusinessError, "没有相关记录", dbErr)
				}
				return result, xerror.NewError(xerror.BusinessError, "GetDb失败", dbErr)
			}
			_ = l.demoCache.Set(ctx, id, &cache.Demo{
				Id:    demo1.Id,
				Name:  demo1.Name,
				Test4: demo1.Test4,
			}, 0)
			_ = copier.Copy(result, demo1)
			return result, nil
		} else {
			_ = copier.Copy(result, demo)
			return result, nil
		}
	}
	return result, xerror.NewError(xerror.BusinessError, "GetOne 失败", nil)
}

// 短信登录
func (l *demoLogic) Login(phone, code string) (account *Account, jwtToken *JwtToken, err error) {
	// 1.判断账号是否在黑名单

	// 2.验证短信验证码缓存

	// 2.删除短信验证码缓存

	// 3.判断手机号是否存在,成功返回token
	nickname := "昵称啊"
	account = &Account{
		Id:         100,
		OrganizeId: 20,
		Nickname:   &nickname,
	}

	jwtToken = l.accountToken(account.OrganizeId, account.Id)

	return account, jwtToken, nil
}

// 账号token
func (l *demoLogic) accountToken(organizeId, accountId int64) *JwtToken {
	tokenObj, err := token.NewJwt(l.cnf, l.logger).Gen(&token.Payload{OrganizeId: organizeId, AccountId: accountId})
	if err != nil {
		return nil
	}
	result := &JwtToken{
		AccessToken:     tokenObj.AccessToken,
		AccessExpireAt:  tokenObj.AccessExpireAt,
		RefreshToken:    tokenObj.RefreshToken,
		RefreshExpireAt: tokenObj.RefreshExpireAt,
	}
	return result
}

// 刷新token
func (l *demoLogic) RefreshToken(tokenStr string) (jwtToken *JwtToken) {
	tokenObj, err := token.NewJwt(l.cnf, l.logger).Refresh(tokenStr)
	if err != nil {
		return nil
	}
	result := &JwtToken{
		AccessToken:     tokenObj.AccessToken,
		AccessExpireAt:  tokenObj.AccessExpireAt,
		RefreshToken:    tokenObj.RefreshToken,
		RefreshExpireAt: tokenObj.RefreshExpireAt,
	}
	return result
}
