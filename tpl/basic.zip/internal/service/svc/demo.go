package svc

import (
	"context"
	"fmt"

	"basic/internal/repository/cache"
	"basic/internal/repository/db"
	"basic/pkg/xerror"
	"basic/pkg/xlog"

	"github.com/jinzhu/copier"
	"github.com/pkg/errors"
)

//go:generate mockgen -source=./demo.go -destination=../../../test/mocks/service/demo.go  -package mock_service

var _ DemoSvc = (*demoSvc)(nil)

type (
	DemoSvc interface {
		FindOne(ctx context.Context, id int64) (*Demo, error)
		FindList(ctx context.Context, args *DemoListArgs) ([]*Demo, int64, error)
		Create(ctx context.Context, demo *Demo) error
		Update(ctx context.Context, id int64, upData *Demo) error
		Delete(ctx context.Context, id int64) error
		SoftDelete(ctx context.Context, id int64) error
	}
	DemoCtx struct {
		*Ctx
		DemoDb    db.DemoDb
		DemoCache cache.DemoCache
	}
	demoSvc struct {
		ctx *DemoCtx
	}

	DemoListArgs struct {
		OrderField string // 排序字段
		OrderType  int64  // 排序类型 0:升序,1:降序
		Page       int64  // 添加验证规则
		PageSize   int64  // 添加验证规则

		Id   *int64
		Name string
	}

	Demo struct {
		Id    int64
		Name  string
		Test1 float64
		Test4 int32
	}
)

func NewDemoSvc(ctx *DemoCtx) DemoSvc {
	return &demoSvc{
		ctx: ctx,
	}
}

// 查找一个
func (d *demoSvc) FindOne(ctx context.Context, id int64) (*Demo, error) {
	if id <= 2 {
		return nil, xerror.NewError(ctx, xerror.InvalidArgument, "Get Demo Detail invalid id", nil)
	}

	xlog.Info(ctx, "Get Demo Detail", "测试手工日志")

	result := &Demo{}
	demo, cacheErr := d.ctx.DemoCache.Get(ctx, id)
	if cacheErr != nil {
		xlog.Info(ctx, fmt.Sprintf("Get Demo Detail 失败:err %v", cacheErr))
		demoDb, dbErr := d.ctx.DemoDb.FindOne(ctx, id)
		if dbErr != nil {
			if errors.Is(dbErr, db.ErrNotFound) {
				return nil, xerror.NewError(ctx, xerror.BusinessError, "没有相关记录", dbErr)
			}
			return result, xerror.NewError(ctx, xerror.BusinessError, "Get Demo Detail 失败", dbErr)
		}
		_ = d.ctx.DemoCache.Set(ctx, id, &cache.Demo{
			Id:    demoDb.Id,
			Name:  demoDb.Name,
			Test4: demoDb.Test4,
		}, 0)
		_ = copier.Copy(result, demoDb)
		return result, nil
	}
	_ = copier.Copy(result, demo)
	return result, nil
}

// 查找列表
func (d *demoSvc) FindList(ctx context.Context, args *DemoListArgs) ([]*Demo, int64, error) {
	dbArgs := db.DemoSearch{
		SearchPage: db.SearchPage{
			OrderField: args.OrderField,
			OrderType:  args.OrderType,
			Page:       args.Page,
			PageSize:   args.PageSize,
		},

		Id:   args.Id,
		Name: args.Name,
	}

	list, total, listErr := d.ctx.DemoDb.FindListWithTotal(ctx, &dbArgs)
	if listErr != nil {
		if errors.Is(listErr, db.ErrNotFound) {
			return []*Demo{}, 0, nil
		}
		return nil, 0, xerror.NewError(ctx, xerror.BusinessError, "Get Demo List 失败", listErr)
	}
	result := make([]*Demo, 0, len(list))
	if len(list) > 0 {
		for _, demo := range list {
			var item Demo
			_ = copier.Copy(&item, demo)
			result = append(result, &item)
		}
	}
	return result, total, nil
}

// 创建
func (d *demoSvc) Create(ctx context.Context, demo *Demo) error {
	_, dbErr := d.ctx.DemoDb.Insert(ctx, &db.Demo{
		Name:  demo.Name,
		Test1: demo.Test1,
		Test4: demo.Test4,
	})
	if dbErr != nil {
		return xerror.NewError(ctx, xerror.BusinessError, "Create Demo 失败", dbErr)
	}
	return nil
}

// 修改(事务示例)
func (d *demoSvc) Update(ctx context.Context, id int64, upData *Demo) error {
	if id > 0 {
		// 两种事务方式
		// 方式1:
		// err := d.ctx.Conn.Tx(ctx, func(ctx context.Context) error {
		//     preOne := id - 1
		//     demo, err := d.ctx.DemoDb.FindOne(ctx, preOne)
		//     if err != nil {
		//         return err
		//     }
		//     err = d.ctx.DemoDb.Delete(ctx, []int64{preOne})
		//     if err != nil {
		//         return err
		//     }
		//     if demo.Id == 3 {
		//         return errors.New("id是3,不能修改")
		//     }
		//     _, err = d.ctx.DemoDb.UpdateColumns(ctx, id, map[string]any{"name": upData.Name, "test1": upData.Test1, "test4": upData.Test4})
		//     return err
		// })
		// 方式2:
		err := d.ctx.DemoDb.UpdateTrans(ctx, id, &db.Demo{
			Name:  upData.Name,
			Test1: upData.Test1,
			Test4: upData.Test4,
		})

		if err != nil {
			return xerror.NewError(ctx, xerror.BusinessError, "Update Demo 失败", err)
		}
		return nil
	}
	return xerror.NewError(ctx, xerror.BusinessError, "Update Demo 失败", nil)
}

// 物理删除
func (d *demoSvc) Delete(ctx context.Context, id int64) error {
	if id > 0 {
		err := d.ctx.DemoDb.Delete(ctx, []int64{id})
		if err != nil {
			return xerror.NewError(ctx, xerror.BusinessError, "Delete Demo 失败", err)
		}
	}
	return nil
}

// 逻辑删除
func (d *demoSvc) SoftDelete(ctx context.Context, id int64) error {
	if id > 0 {
		err := d.ctx.DemoDb.SoftDelete(ctx, []int64{id})
		if err != nil {
			return xerror.NewError(ctx, xerror.BusinessError, "SoftDelete Demo 失败", err)
		}
	}
	return nil
}
