package service

import (
	"context"

	"basic/internal/repository/db"
	"basic/pkg/xerror"

	"github.com/jinzhu/copier"
	"github.com/pkg/errors"
)

//go:generate mockgen -source=./user.go -destination=../../test/mocks/service/user.go  -package mock_service

var _ UserSvc = (*userSvc)(nil)

type (
	UserSvc interface {
		GetUserById(id int64) (result *User, err error)
	}
	User struct {
		Id       int64  `json:"id"`
		Username string `json:"username"`
		Email    string `json:"email"`
	}

	userSvc struct {
		*Service
		userDb db.UserRepo
	}
)

func NewUserSvc(svc *Service, userDb db.UserRepo) UserSvc {
	return &userSvc{
		Service: svc,
		userDb:  userDb,
	}
}

func (s *userSvc) GetUserById(id int64) (result *User, err error) {
	ctx := context.Background()
	if id > 0 {
		result = &User{}
		user, dbErr := s.userDb.FindOne(ctx, id)
		if dbErr != nil {
			if errors.Is(dbErr, db.ErrNotFound) {
				return nil, xerror.NewError(xerror.BusinessError, "没有相关记录", dbErr)
			}
			return result, xerror.NewError(xerror.BusinessError, "GetUserById失败", dbErr)
		}
		_ = copier.Copy(result, &user)
		return result, nil
	}
	return result, xerror.NewError(xerror.BusinessError, "GetUserById 失败", nil)
}
