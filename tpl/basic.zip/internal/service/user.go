package service

import (
	"context"

	"basic/internal/repository/mysql"
	"basic/pkg/xerror"

	"github.com/jinzhu/copier"
	"github.com/pkg/errors"
)

//go:generate mockgen -source=./user.go -destination=../../test/mocks/service/user.go  -package mock_service

var _ UserSvc = (*userSvc)(nil)

type (
	UserSvc interface {
		GetUserById(id int64) (result *User, err error)
	}
	User struct {
		Id       int64  `json:"id"`
		Username string `json:"username"`
		Email    string `json:"email"`
	}

	userSvc struct {
		*Service
		userMysql mysql.UserRepo
	}
)

func NewUserSvc(svc *Service, userMysql mysql.UserRepo) UserSvc {
	return &userSvc{
		Service:   svc,
		userMysql: userMysql,
	}
}

func (s *userSvc) GetUserById(id int64) (result *User, err error) {
	ctx := context.Background()
	if id > 0 {
		result = &User{}
		user, dbErr := s.userMysql.FindOne(ctx, id)
		if dbErr != nil {
			if errors.Is(dbErr, mysql.ErrNotFound) {
				return nil, xerror.NewError(xerror.BusinessError, "没有相关记录", dbErr)
			}
			return result, xerror.NewError(xerror.BusinessError, "GetUserById失败", dbErr)
		}
		_ = copier.Copy(result, &user)
		return result, nil
	}
	return result, xerror.NewError(xerror.BusinessError, "GetUserById 失败", nil)
}
