/**
 * @Author: spruce
 * @Date: 2024-03-14 22:26
 * @Desc: wire 服务 InjectSet
 */

package service

import (
	"basic/internal/repository/db"
	"basic/pkg/token"
	"basic/pkg/xconfig"
	"basic/pkg/xlog"

	"github.com/google/wire"
)

type Service struct {
	cnf    *xconfig.Cnf
	logger *xlog.Logger
	jwt    *token.Jwt

	tx db.ConnTx
}

func NewService(cnf *xconfig.Cnf, log *xlog.Logger, jwt *token.Jwt, tx db.ConnTx) *Service {
	return &Service{
		cnf:    cnf,
		logger: log,
		jwt:    jwt,
		tx:     tx,
	}
}

// 服务列表    // TODO 需要手动增加 后执行 wire
type SvcSet struct {
	UserSvc UserSvc
}

// 服务层   // TODO 需要手动增加 后执行 wire
var InjectSet = wire.NewSet(
	NewService,
	NewUserSvc,
)
