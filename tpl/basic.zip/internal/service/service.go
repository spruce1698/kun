/**
 * @Author: spruce
 * @Date: 2024-03-14 22:26
 * @Desc: 服务 wire 配置
 */

package service

import (
	"basic/internal/repository/mysql"
	"basic/pkg/token"
	"basic/pkg/xconfig"
	"basic/pkg/xlog"

	"github.com/google/wire"
)

type Service struct {
	cnf    *xconfig.Cnf
	logger *xlog.Logger
	jwt    *token.Jwt

	tx mysql.ConnTx
}

func NewService(cnf *xconfig.Cnf, log *xlog.Logger, jwt *token.Jwt, tx mysql.ConnTx) *Service {
	return &Service{
		cnf:    cnf,
		logger: log,
		jwt:    jwt,
		tx:     tx,
	}
}

// ====================== TODO 需要手动配置  http 服务层 修改后重新wire ======================

// 服务列表
type ServerSvc struct {
	UserSvc UserSvc
}

// 服务层
var WireServerSet = wire.NewSet(
	NewService,
	NewUserSvc,
)
