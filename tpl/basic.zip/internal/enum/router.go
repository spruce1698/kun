/**
 * @Author: spruce
 * @Date: 2024-04-10 17:30
 * @Desc: 路由 常量 枚举
 */

package enum

const (
	RouterPrefixApi = "/api"
	RouterPrefixMgr = "/mgr"
)
