/**
 * @Author: spruce
 * @Date: 2024-03-07 11:11
 * @Desc: 默认用户路由
 */

package v0

import (
	"basic/internal/controller"
	"basic/internal/enum"
	"basic/pkg/token"

	"github.com/gin-gonic/gin"
)

func User(e *gin.Engine, jwt *token.Jwt, ctl *controller.CtlSet) {
	// api user路由
	apiGroup := e.Group(enum.RouterPrefixApi)
	{
		apiGroup.GET("/user", ctl.UserCtl.GetUserById)
	}

}
