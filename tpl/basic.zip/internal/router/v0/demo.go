/**
 * @Author: spruce
 * @Date: 2024-03-28 11:11
 * @Desc: v0 路由
 */

package v0

import (
	"basic/internal/controller"
	"basic/internal/global"
	"basic/internal/middleware"
	"basic/pkg/xserver"
	"basic/pkg/xserver/http"
)

type DemoRtrCtls struct {
	DemoCtl *controller.DemoCtl
}

func DemoRtr(s *http.Server, cs *DemoRtrCtls) xserver.Engine {
	// api Demo路由
	apiGroup := s.Engine.Group(global.RouterPrefixApi)
	{
		apiGroup.GET("/demo/one", cs.DemoCtl.GetOne)
	}
	// mgr Demo路由
	mgrGroup := s.Engine.Group(global.RouterPrefixMgr)
	mgrGroupNotAuth := mgrGroup
	{
		mgrGroupNotAuth.POST("/demo/login", cs.DemoCtl.Login)
		mgrGroupNotAuth.POST("/demo/refresh/token", middleware.WireAuth(s.Cnf, s.Logger), cs.DemoCtl.RefreshToken)
	}
	mgrGroup1 := mgrGroup.Use(middleware.Auth(s.Cnf, s.Logger))
	{
		mgrGroup1.GET("/demo", cs.DemoCtl.GetOne)
	}
	return s
}
