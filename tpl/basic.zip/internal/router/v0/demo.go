/**
 * @Author: spruce
 * @Date: 2024-03-28 11:11
 * @Desc: v0 路由
 */

package v0

import (
	"basic/internal/controller"
	"basic/internal/global"
	"basic/internal/middleware"
	"basic/pkg/token"

	"github.com/gin-gonic/gin"
)

func Demo(e *gin.Engine, jwt *token.Jwt, ctx *controller.ServerCtrlCtx) {
	// api Demo路由
	apiGroup := e.Group(global.RouterPrefixApi)
	{
		apiGroup.GET("/demo/one", ctx.DemoCtrl.GetOne)
	}
	// mgr Demo路由
	mgrGroup := e.Group(global.RouterPrefixMgr)
	mgrGroupNotAuth := mgrGroup
	{
		mgrGroupNotAuth.POST("/demo/login", ctx.DemoCtrl.Login)
		mgrGroupNotAuth.POST("/demo/refresh/token", ctx.DemoCtrl.RefreshToken)
	}
	mgrGroup1 := mgrGroup.Use(middleware.Auth(jwt))
	{
		mgrGroup1.GET("/demo", ctx.DemoCtrl.GetOne)
	}
}
