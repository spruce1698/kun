package router

import (
	"basic/internal/controller"
	v0 "basic/internal/router/v0"
	"basic/pkg/token"

	"github.com/gin-gonic/gin"
)

// 定义路由注册接口
type (
	Router func(e *gin.Engine, jwt *token.Jwt, ctx *controller.ServerCtrlCtx)
)

// 路由层
func WireServerSet() []Router {
	return []Router{
		v0.Demo,
		// ==== Add Rtr before this line, don't edit this line.====
	}
}
