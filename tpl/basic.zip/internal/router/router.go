/**
 * @Author: spruce
 * @Date: 2024-03-07 11:08
 * @Desc: 默认,缺省,ping路由 wire InjectSet 路由配置
 */

package router

import (
	"net/http"

	"basic/internal/controller"
	"basic/internal/router/v0"
	"basic/pkg/token"
	"basic/pkg/xhttp"

	"github.com/gin-gonic/gin"
)

type (
	Routers func(e *gin.Engine, jwt *token.Jwt, ctl *controller.CtlSet)
)

// 缺省路由
func NotFoundHandle(ctx *gin.Context) {
	xhttp.WithNotFoundPath(ctx)
}

// ping 路由
func Ping(e *gin.Engine) {
	e.GET("/ping", func(ctx *gin.Context) {
		ctx.String(http.StatusOK, "pong")
	})
}

// 路由层   // TODO 需要手动增加 后执行 wire
func InjectSet() []Routers {
	return []Routers{
		v0.User,
	}
}
