# basic — 基础布局

## 功能
- **Gin**: https://github.com/gin-gonic/gin
- **Gorm**: https://github.com/go-gorm/gorm
- **Wire**: https://github.com/google/wire
- **Viper**: https://github.com/spf13/viper
- **Zap**: https://github.com/uber-go/zap
- **Golang-jwt**: https://github.com/golang-jwt/jwt
- **Go-redis**: https://github.com/go-redis/redis
- More...


## 目录结构

```
.
├── cmd
│   ├── server
│   │   ├── main.go
│   │   ├── wire
│   │   │   ├── wire.go
│   │   │   └── wire_gen.go
├── config
│   ├── local.yml
├── internal
│   ├── controller
│   │   │   ├── demo.go
│   ├── global
│   │   └──ctx.go
│   │   └──router.go
│   ├── logic
│   │   ├── demo.go
│   │   └── logic.go
│   ├── middleware
│   │   ├── cors.go
│   │   ├── logger.go
│   │   └── recovery.go
│   ├── repository
│   │   ├── cache
│   │   │   ├── user.go
│   │   ├── mysql
│   │   │   ├── mysql.go
│   │   │   ├── user.go
│   │   │   └── user_gen.go
│   └── router
│       ├── router.go
│   │   │   ├── v0
│   │   │   │   └──  demo.go
├── pkg
├── README.md
├── go.mod
└── go.sum

```

这是一个经典的Golang 项目的目录结构，包含以下目录：

- cmd: 应用程序的主要入口。
  - server: http服务的入口，包含主函数和依赖注入的代码。
    - main.go: 主函数，用于启动应用http服务。
    - wire: 存放依赖注入代码
      - wire.go: 使用Wire库生成的依赖注入代码。
      - wire_gen.go: 使用Wire库生成的依赖注入代码。

- config: 存放应用程序的配置文件。
  - local.yml: 本地环境的配置文件。

- internal: 存放应用程序的内部代码。
  - controller: 处理HTTP请求的控制器。
    - demo.go: 处理demo相关的HTTP请求的控制器。
  - global: 存放常量/全局变量代码。
    - ctx.go: ctx中的常量/全局变量。
    - router.go: 路由常量/全局变量。
  - logic: 存放业务逻辑代码。
    - logic.go: 业务逻辑的通用接口。
    - demo.go: demo业务逻辑的实现。
  - middleware: 存放中间件代码。
    - cors.go: 跨域资源共享中间件。
    - logger.go: 接管默认日志中间件。
    - recovery.go: 接管默认恢复中间件。
  - repository: 存储库相关代码。
    - cache: 存放缓存(redis)代码
      - demo.go: demo缓存(redis)代码。
    - mysql: 存放mysql数据库代码
      - mysql.go: mysql通用接口。
      - demo.go: demo数据访问接口的实现自定义。
      - demo_gen.go: demo数据访问接口的实现系统生成。
  - router: 存放路由代码。
    - router.go: 通用路由。
    - v0: 默认第一个/公共版本。
      - demo.go: demo相关路由。

- pkg: 存放应用程序的公共包。
- go.mod: Go模块文件。
- go.sum: Go模块的依赖版本文件。

## 要求
您需要在系统上安装以下软件：

* Golang 1.19或更高版本
* Git


### 创建组件

您可以使用以下命令为项目创建controller、logic和repository等组件：

```bash
kun create ctl user
kun create logic user
kun create repo "name:pwd@tcp(127.0.0.1:3306)/dbname" "t1,t2"
```
或
```
kun create all user
```
这些命令将分别创建以`UserCtl` 和 `UserLogic` 命名的组件，并将它们放置在正确的目录中。

### 启动项目

您可以使用以下命令快速启动项目：

```bash
kun run
```

此命令将启动您的Golang项目。

### 编译wire.go

您可以使用以下命令快速编译`wire.go`：

```bash
kun wire
```

此命令将编译您的`wire.go`文件，并生成所需的依赖项。
