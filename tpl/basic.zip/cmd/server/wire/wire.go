//go:build wireinject
// +build wireinject

package wire

import (
	"basic/internal/repository/db"
	"basic/pkg/server"
	"basic/pkg/server/http"

	"basic/internal/controller"
	"basic/internal/repository"
	"basic/internal/router"
	"basic/internal/service"

	"basic/pkg/token"
	"basic/pkg/xconfig"
	"basic/pkg/xdb"
	"basic/pkg/xlog"
	"basic/pkg/xredis"

	"github.com/google/wire"
)

// 基础层,数据库链接等
var baseSet = wire.NewSet(
	xconfig.New,
	xlog.New,
	xdb.New,
	xredis.New,

	db.NewConn,
	db.NewConnTx,
	token.New,

	repository.WireSet,
)

func CreateApp(env string) (*server.Svr, error) {
	panic(wire.Build(
		baseSet,
		service.WireServerSet,
		controller.WireServerSet,
		wire.Struct(new(controller.ServerCtl), "*"),
		router.WireServerSet,
		http.New,
		server.New,
	))
}
