//go:build wireinject
// +build wireinject

package wire

import (
	"basic/internal/controller"
	"basic/internal/logic"
	"basic/internal/repository/cache"
	"basic/internal/repository/mysql"
	"basic/internal/router/v0"

	"basic/pkg/xconfig"
	"basic/pkg/xdb"
	"basic/pkg/xlog"
	"basic/pkg/xredis"
	"basic/pkg/xserver"
	"basic/pkg/xserver/http"

	"github.com/google/wire"
)

// 依赖注入构造 Web 应用声明函数
func WireApp(env string) (*xserver.Server, error) {
	panic(wire.Build(
		// ====base,配置,日志,数据库链接等====
		xconfig.New,
		xlog.New,
		xdb.New,

		xredis.New,
		mysql.NewConn,
		mysql.NewConnTx,
		http.New,

		// ====repository-start====
		mysql.NewDemoRepo,
		cache.NewDemoRepo,
		// ====repository-end====

		// ====logic-start====
		logic.BaseLogic,

		logic.NewDemoLogic,
		// ====logic-end====

		// ====controller-start====
		controller.NewDemoCtl,
		// ====controller-end====

		// ====router-start====
		wire.Struct(new(v0.DemoRtrCtls), "*"),
		v0.DemoRtr,
		// ====router-end====

		xserver.New,
	))
}
