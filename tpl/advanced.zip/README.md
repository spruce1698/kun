# basic — 基础布局

## 功能
- **Gin**: https://github.com/gin-gonic/gin
- **Gorm**: https://github.com/go-gorm/gorm
- **Wire**: https://github.com/google/wire
- **Viper**: https://github.com/spf13/viper
- **Zap**: https://github.com/uber-go/zap
- **Golang-jwt**: https://github.com/golang-jwt/jwt
- **Go-redis**: https://github.com/go-redis/redis
- More...


## 目录结构

```
.
├──── assets                               资源目录
├──── cmd                                  项目入口目录
│      ├──── broker                        发布/订阅消息服务器(异步消息,延时消息,周期性任务订阅)
│      │        ├── wire  
│      │        │     ├── wire.go  
│      │        │     └── wire_gen.go  
│      │        └───── main.go  
│      └──── server                        http服务入口
│               ├── wire  
│               │     ├── wire.go  
│               │     └── wire_gen.go  
│               └───── main.go  
├──── config                               配置文件目录
│      └── local.yml
├──── deploy                               编译,部署目录
│      ├──── ci                            存放 CI（travis,circle,drone）的配置文件和脚本
│      │        └── docker-compose.yml  
│      ├──── docker                        存放子项目各个组件的 Dockerfile 文件
│      │        └── Dockerfile  
├──── docs                                 文档目录
│      └──── swagger                       接口文档目录
├──── internal                 
│      ├──── controller                    控制器目录
│      │        └──── serverDI.go          server的 控制器 依赖注入配置文件
│      ├──── event                         事件目录:发布/订阅消息
│      ├──── global                        业务枚举,全局变量目录
│      ├──── middleware                    中间件目录
│      ├──── repository                    存储目录
│      │        ├──── cache                缓存目录
│      │        │     ├── keys.go          缓存key管理
│      │        │     └── local.go         本地缓存
│      │        ├──── db                   mysql目录 
│      │        │      └── mysql.go        mysql数据库操作基础
│      │        └──── serverDI.go          server的 存储 依赖注入配置文件
│      ├──── router                        路由目录
│      │        ├── router.go              通用路由
│      │        └── serverDI.go            server的 路由 依赖注入配置文件
│      └──── service                       业务服务(逻辑)目录
│               ├──── svc                  业务服务(逻辑)核心目录
│               │      └── context.go      业务逻辑的context
│               ├── brokerDI.go            broker的 服务 赖注入配置文件
│               └── serverDI.go            server的 服务 依赖注入配置文件
├──── pkg                                  公共包
├──── scripts                              脚本,部署文件夹
│      └── swagger.sh                      生成swagger文档脚本
├──── test                                 单元测试文件
├── README.md
├── go.mod
└── go.sum
```

这是一个经典的Golang 项目的目录结构，包含以下目录：

- cmd: 应用程序的主要入口。
  - broker: 发布/订阅服务器的入口，包含主函数和依赖注入的代码。
    - wire: 存放依赖注入代码
      - wire.go: 使用Wire库生成的依赖注入代码。
      - wire_gen.go: 使用Wire库生成的依赖注入代码。
    - main.go: 主函数，用于启动发布/订阅服务器。
  - server: http服务的入口，包含主函数和依赖注入的代码。
    - wire: 存放依赖注入代码
      - wire.go: 使用Wire库生成的依赖注入代码。
        - wire_gen.go: 使用Wire库生成的依赖注入代码。
    - main.go: 主函数，用于启动应用http服务。

- config: 存放应用程序的配置文件。
  - local.yml: 本地环境的配置文件。

- deploy: 部署。
  - ci: ci目录。
  - docker: docker编译文件。

- docs:
  - swagger: Swaggo生成的接口文档。

- internal: 存放应用程序的内部代码。
  - controller: 处理HTTP请求的控制器。
    - demo.go: 处理demo相关的HTTP请求的控制器。
    - serverDI.go: server的控制器依赖注入文件。
  - event: 消息发布/订阅。
    - publisher.go: 消息发布器。
    - subscriber.go: 消息订阅器。
  - global: 存放常量/全局变量代码。
    - ctx.go: ctx中的常量/全局变量。
    - router.go: 路由常量/全局变量。
  - middleware: 存放中间件代码。
    - auth.go: 授权中间件。
    - cors.go: 跨域资源共享中间件。
    - otel.go: 全链路追踪器。
    - recovery.go: 接管默认恢复中间件。
    - tracing.go:  日志的追踪中间件。
  - proto: protobuf文件。
    - demo: demo的protobuf文件。
      - demo.proto: protobuf定义文件。
  - repository: 存储库相关代码。
    - cache: 缓存存储代码
      - demo.go: demo缓存访问接口的实现自定义。
      - keys.go: 缓存的keys同一管理文件。
      - local.go: 本地缓存操作文件。
    - sql: 存放sql存储层代码
      - mysql.go: mysql通用接口。
      - demo.go: demo数据访问接口的实现自定义。
      - demo_gen.go: demo数据访问接口的实现系统生成。
    - serverDI.go: server的存储依赖注入文件。
  - router: 存放路由代码。
    - v0: 默认第一个/公共版本。
      - demo.go: demo相关路由。
    - router.go: 通用路由。
    - serverDI.go: server的路由依赖注入文件。
  - service: 存放业务服务(逻辑)代码。
    - svc: 业务服务(逻辑)核心目录。
      - context.go: 业务逻辑的context。
      - demo.go: demo业务逻辑的实现。
    - brokerDI.go: broker的服务依赖注入文件。
    - serverDI.go: server的服务依赖注入文件。。
- pkg: 存放应用程序的公共包。
- scripts:  项目脚本。
  - swagger.sh: 生成swagger文档的脚本。
- test: mock代码
- go.mod: Go模块文件。
- go.sum: Go模块的依赖版本文件。

## 要求
您需要在系统上安装以下软件：

* Golang 1.19或更高版本
* Git


### 创建组件

您可以使用以下命令为项目创建controller、service和repository等组件：

```bash
kun create ctrl user
kun create svc user
kun create repo "name:pwd@tcp(127.0.0.1:3306)/dbname" [t1,t2|t1|*]
```
或
```
kun create all user
```

这些命令将分别创建以`UserCtrl` 和 `UserSvc` 命名的组件，并将它们放置在正确的目录中。

### 启动项目

您可以使用以下命令快速启动项目：

```bash
kun run
```

此命令将启动您的Golang项目。

### 编译wire.go

您可以使用以下命令快速编译`wire.go`：

```bash
kun wire
```

此命令将编译您的`wire.go`文件，并生成所需的依赖项。
