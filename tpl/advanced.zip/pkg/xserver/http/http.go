/**
 * @Author: spruce
 * @Date: 2024-03-28 14:59
 * @Desc: http Engine
 */

package http

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"

	"advanced/internal/middleware"
	"advanced/internal/router"
	"advanced/pkg/utils"
	"advanced/pkg/validator"
	"advanced/pkg/xconfig"
	"advanced/pkg/xdb"
	"advanced/pkg/xlog"
	"advanced/pkg/xredis"

	"github.com/gin-contrib/pprof"
	"github.com/gin-gonic/gin"
)

type Server struct {
	Cnf    *xconfig.Cnf
	Logger *xlog.Logger

	db    *xdb.Client
	redis *xredis.Client

	Engine *gin.Engine
	server *http.Server
}

func New(cnf *xconfig.Cnf, log *xlog.Logger, db *xdb.Client, redis *xredis.Client) (*Server, error) {

	eng := gin.New()

	if cnf.Env == xconfig.EnvStaging || cnf.Env == xconfig.EnvRelease {
		gin.SetMode(gin.ReleaseMode)
		// 禁止gin的默认输出
		gin.DefaultWriter = io.Discard
	} else {
		gin.SetMode(cnf.Env)
	}

	// 性能分析 - 正式环境不要使用！！！
	if cnf.Env == xconfig.EnvDebug {
		pprof.Register(eng)
	}

	// 接管gin框架默认的日志和捕获异常
	eng.Use(
		middleware.Logger(log),
		middleware.Recovery(cnf.Env == xconfig.EnvDebug || cnf.Env == xconfig.EnvTest, log), // 测试或开发环境
	)

	// 跨域
	eng.Use(middleware.CORS())

	// 限制
	// eng.Use(middleware.Limit(10))

	// 缺失路由
	eng.NoRoute(router.NotFoundHandle)

	// 探针路由
	router.Ping(eng)

	// Swagger 路由
	if cnf.Env == xconfig.EnvDebug || cnf.Env == xconfig.EnvTest {
		router.SwaggerRouter(eng)
	}

	return &Server{
		Cnf:    cnf,
		Logger: log,

		db:    db,
		redis: redis,

		Engine: eng,
	}, nil
}

func (s *Server) Start() error {
	// 验证器翻译
	validator.New("zh")

	readTimeout, writeTimeout := time.Duration(120), time.Duration(120)
	// 默认 2min
	if s.Cnf.Server.ReadTimeout != 0 {
		readTimeout = time.Duration(s.Cnf.Server.ReadTimeout)
	}
	if s.Cnf.Server.WriteTimeout == 0 {
		writeTimeout = time.Duration(s.Cnf.Server.WriteTimeout)
	}
	port := s.Cnf.Server.Port
	if port == 0 {
		port = utils.AvailablePort()
	}
	// 初始化HTTP/JOB服务
	svr := &http.Server{
		Addr:         fmt.Sprintf(":%d", port),
		Handler:      s.Engine,
		ReadTimeout:  readTimeout * time.Second,
		WriteTimeout: writeTimeout * time.Second,
	}

	// 启动成功
	s.Logger.Warn(fmt.Sprintf("Http server 启动 (Host: 0.0.0.0:%d  Pid:%d) \n", port, os.Getpid()))

	go func() {
		if err := svr.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			s.Logger.Warn(fmt.Sprintf("Listen: %s\n", err))
			s.Stop("")
		}
	}()

	s.server = svr
	return nil
}

func (s *Server) Stop(signal string) {

	s.Logger.Warn("Receive a signal", xlog.String("signal", signal))

	s.Logger.Warn("Http server stopping ...")

	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(5)*time.Second)
	defer cancel()

	// 优雅关闭
	// 关闭 http server
	if s.server != nil {
		if err := s.server.Shutdown(ctx); err != nil {
			s.Logger.Warn(fmt.Sprintf("http server shutdown err:%v", err))
		}
		s.Logger.Warn("Close http server")
	}
	// 关闭 db
	if s.db != nil {
		sqlDB, _ := s.db.DB()
		if sqlDB != nil {
			if err := sqlDB.Close(); err != nil {
				s.Logger.Warn(fmt.Sprintf("db shutdown err:%v", err))
			}
		}
		s.Logger.Warn("Close Db")
	}

	// 关闭 redis
	if s.redis != nil {
		if err := s.redis.Close(); err != nil {
			s.Logger.Warn(fmt.Sprintf("redis shutdown err:%v", err))
		}
		s.Logger.Warn("Close redis")
	}

	// TODO 其他关闭
	s.Logger.Warn("Http server stopped")
}
