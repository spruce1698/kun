/**
 * @Author: spruce
 * @Date: 2024-03-28 15:34
 * @Desc: x服务接口
 */

package xserver

import (
	"os"
	"os/signal"
	"syscall"
)

type Engine interface {
	Start() error
	Stop(signal string)
}

type Server struct {
	eng Engine
}

func New(eng Engine) *Server {
	return &Server{
		eng: eng,
	}
}

// Start server
func (s *Server) Start() error {
	if err := s.eng.Start(); err != nil {
		return err
	}
	return nil
}

// Await signal for exit server
func (s *Server) AwaitSignal() {
	sigCh := make(chan os.Signal, 1)
	signal.Reset(syscall.SIGKILL, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)
	signal.Notify(sigCh, syscall.SIGKILL, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)
	sig := <-sigCh
	s.eng.Stop(sig.String())
	os.Exit(0)
}
