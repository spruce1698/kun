/**
 * @Author: spruce
 * @Date: 2024-03-28 14:59
 * @Desc: pubsub broker 服务
 */

package broker

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"advanced/internal/middleware"
	"advanced/internal/pubsub"
	"advanced/internal/router"
	"advanced/pkg/utils"
	"advanced/pkg/xconfig"
	"advanced/pkg/xdb"
	"advanced/pkg/xlog"
	"advanced/pkg/xredis"
	"advanced/pkg/xserver"

	"github.com/gin-contrib/pprof"
	"github.com/gin-gonic/gin"
	"github.com/pkg/errors"
)

const (
	ChildKey = "BrokerChildKey"
	ChildVal = "BrokerChildProcess"
)

type Server struct {
	Cnf    *xconfig.Cnf
	Logger *xlog.Logger

	db    *xdb.Client
	redis *xredis.Client

	task *pubsub.Task
}

func New(cnf *xconfig.Cnf, log *xlog.Logger, db *xdb.Client, redis *xredis.Client, task *pubsub.Task) (xserver.Engine, error) {
	return &Server{
		Cnf:    cnf,
		Logger: log,
		db:     db,
		redis:  redis,

		task: task,
	}, nil
}

// 多进程实现
func (s *Server) Start() error {

	// 是否是子进程
	if isChild() {
		childProcess(s.Cnf, s.task)
		return nil
	}

	healthSvr := healthServer(s.Cnf, s.Logger)

	quitCh := make(chan struct{})
	childCh := make(chan *exec.Cmd, 1)
	// 监听退出信号
	go func(qch chan<- struct{}) {
		signals := make(chan os.Signal, 1)
		signal.Notify(signals, syscall.SIGKILL, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)
		_ = <-signals

		s.Logger.Warn("Broker server stopping ...")
		ctx, cancel := context.WithTimeout(context.Background(), time.Second*5)
		defer cancel()
		// 关闭 http server
		if healthSvr != nil {
			if err := healthSvr.Shutdown(ctx); err != nil {
				s.Logger.Warn(fmt.Sprintf("http server shutdown err:%v", err))
			}
			s.Logger.Warn("Close http server")
		}
		// 关闭 db
		if s.db != nil {
			sqlDB, _ := s.db.DB()
			if sqlDB != nil {
				if err := sqlDB.Close(); err != nil {
					s.Logger.Warn(fmt.Sprintf("db shutdown err:%v", err))
				}
				s.Logger.Warn("Close Db")
			}
		}

		// 关闭 redis
		if s.redis != nil {
			if err := s.redis.Close(); err != nil {
				s.Logger.Warn(fmt.Sprintf("redis shutdown err:%v", err))
			}
			s.Logger.Warn("Close redis")
		}

		// TODO 其他关闭

		// 关闭完成
		s.Logger.Warn("Broker server stopped")

		// 广播退出信号
		close(qch)

	}(quitCh)
	// 退出信号，转发信号给子进程
	go func(qch <-chan struct{}, cch <-chan *exec.Cmd) {
		for {
			select {
			case <-qch:
			case cmd := <-cch:
				_ = cmd.Process.Signal(syscall.SIGTERM)
			}
		}
	}(quitCh, childCh)

	childEnv := append(os.Environ(), fmt.Sprintf("%s=%s", ChildKey, ChildVal))

	for {
		cmd := exec.Cmd{
			Path:   os.Args[0],
			Args:   os.Args,
			Env:    childEnv,
			Stdin:  os.Stdin,
			Stdout: os.Stdout,
			Stderr: os.Stderr,
		}

		if err := cmd.Start(); err != nil {
			s.Logger.Warn("Broker start child process err: " + err.Error())
			// 退出
			break
		}

		childCh <- &cmd

		if err := cmd.Wait(); err != nil {
			// 子进程异常退出,父进程也退出
			s.Logger.Warn(fmt.Sprintf("Broker child process %d exit err: %s", cmd.Process.Pid, err.Error()))
			break
		}
		s.Logger.Warn(fmt.Sprintf("Broker child process %d exit", cmd.Process.Pid))

		select {
		case <-quitCh:
			s.Logger.Warn("Broker parent process exit")
			return nil
		}
	}

	return nil
}

func (s *Server) Stop(signal string) {
	s.Logger.Warn("Receive a signal", xlog.String("signal", signal))
	s.Logger.Info("Broker server stopped1")
}

func isChild() bool {
	return os.Getenv(ChildKey) == ChildVal
}

func healthServer(cnf *xconfig.Cnf, log *xlog.Logger) *http.Server {
	engine := gin.New()

	if cnf.Env == xconfig.EnvStaging || cnf.Env == xconfig.EnvRelease {
		gin.SetMode(gin.ReleaseMode)
		// 禁止gin的默认输出
		gin.DefaultWriter = io.Discard
	} else {
		gin.SetMode(cnf.Env)
	}

	// 性能分析 - 正式环境不要使用！！！
	if cnf.Env == xconfig.EnvDebug {
		pprof.Register(engine)
	}

	// 接管gin框架默认的日志和捕获异常
	engine.Use(
		middleware.Logger(log),
		middleware.Recovery(cnf.Env == xconfig.EnvDebug || cnf.Env == xconfig.EnvTest, log), // 测试或开发环境
	)

	// 探针路由
	router.Ping(engine)

	port := cnf.Broker.Port
	if port == 0 {
		port = utils.AvailablePort()
	}
	readTimeout, writeTimeout := time.Duration(120), time.Duration(120)
	// 默认 2min
	if cnf.Server.ReadTimeout != 0 {
		readTimeout = time.Duration(cnf.Server.ReadTimeout)
	}
	if cnf.Server.WriteTimeout == 0 {
		writeTimeout = time.Duration(cnf.Server.WriteTimeout)
	}

	// 初始化HTTP服务
	httpSvr := &http.Server{
		Addr:         fmt.Sprintf(":%d", port),
		Handler:      engine,
		ReadTimeout:  readTimeout * time.Second,
		WriteTimeout: writeTimeout * time.Second,
	}

	// 启动成功
	log.Warn(fmt.Sprintf("Broker Server 启动 (Host: 0.0.0.0:%d  Pid:%d) \n", port, os.Getpid()))

	go func() {
		if err := httpSvr.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Warn(fmt.Sprintf("listen: %s\n", err))
		}
	}()
	return httpSvr
}

func childProcess(cnf *xconfig.Cnf, task *pubsub.Task) {
	var wg sync.WaitGroup
	sub := pubsub.NewSub(&wg, cnf, task)

	// kafka subscriber
	sub.Kafka()
	// asynq subscriber
	sub.Asynq()
	// asynq CronPush
	sub.AsynqCron()

	wg.Wait()

}
