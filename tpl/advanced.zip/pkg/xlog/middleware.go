/**
 * @Desc: Gin 链路追踪中间件:开 span、注入 trace 到 logger、记录请求/响应
 */

package xlog

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.uber.org/zap/zapcore"
)

var bufferPool = sync.Pool{
	New: func() interface{} {
		return bytes.NewBuffer(make([]byte, 0, 10240))
	},
}

const maxLogBodySize = 4096      // 日志记录的请求/响应 body 最大字节数
const maxRequestBodySize = 65536 // 完整读取 body 上限 64KB（超过则截断记录前 4KB）

// responseWriter 包装 gin.ResponseWriter 以捕获响应内容
type responseWriter struct {
	gin.ResponseWriter
	body    *bytes.Buffer
	bodyLen int // 已写入 body 的总字节数
}

// Unwrap 暴露底层 ResponseWriter,使 http.NewResponseController 能拿到真实连接。
// 缺少该方法时 rc.SetWriteDeadline/Flush 会返回 "feature not supported",
// 导致流式接口(导出/SSE/WS)无法清除 WriteTimeout 而被中途切断。
func (w *responseWriter) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

func (w *responseWriter) Write(b []byte) (int, error) {
	// 仅记录前 maxLogBodySize 字节到日志 buffer，避免大响应体占用过多内存
	remain := maxLogBodySize - w.bodyLen
	if remain > 0 {
		if remain > len(b) {
			remain = len(b)
		}
		w.body.Write(b[:remain])
		w.bodyLen += remain
	}
	return w.ResponseWriter.Write(b)
}

// TracingWithLogger 创建一个带日志的追踪中间件
func TracingWithLogger(log *Logger, serviceName string) gin.HandlerFunc {

	return func(c *gin.Context) {
		start := time.Now()
		path := c.Request.URL.Path
		method := c.Request.Method
		contentType := c.GetHeader("Content-Type")
		var requestBody []byte

		// 获取或创建 trace
		ctx := c.Request.Context()
		spanName := fmt.Sprintf("%s %s", method, path)

		// 创建新的 span
		tracer := otel.Tracer(serviceName)
		ctx, span := tracer.Start(ctx, spanName)
		defer span.End()

		// 回写 X-Trace-Id 到响应头，便于端到端追踪调试
		if traceID := span.SpanContext().TraceID(); traceID.IsValid() {
			c.Header("X-Trace-Id", traceID.String())
		}

		if method == "POST" || method == "PUT" {
			// 处理表单数据
			switch {
			case strings.Contains(contentType, "multipart/form-data"):
				// multipart 表单可能很大(文件上传)。这里绝不调用 ParseMultipartForm:
				// 它会把整个请求体读进内存(32MB)并把超出部分落盘,仅为记日志付出这个代价,
				// 高并发上传时可被远程触发内存/磁盘耗尽,且会提前消费 body 导致 handler 无法流式读取。
				requestBody = []byte(fmt.Sprintf("[multipart/form-data, %d bytes, not parsed]", c.Request.ContentLength))
			case strings.Contains(contentType, "application/x-www-form-urlencoded"):
				if err := c.Request.ParseForm(); err == nil {
					requestBody = []byte(FilterForm(c.Request.PostForm))
				}
			case c.Request.Body != nil:
				contentLen := c.Request.ContentLength
				switch {
				case contentLen > 0 && contentLen <= maxRequestBodySize:
					// 小 body：完整读取、记录、重建供 handler 使用
					requestBody = make([]byte, contentLen)
					if _, err := io.ReadFull(c.Request.Body, requestBody); err == nil {
						c.Request.Body = io.NopCloser(bytes.NewReader(requestBody))
					} else {
						requestBody = nil
					}
				case contentLen > maxRequestBodySize:
					// 大 body（文件上传等）：不读取，仅记录元数据用于追踪
					requestBody = []byte(fmt.Sprintf("[large body, %d bytes, skipped]", contentLen))
				default:
					// chunked / 未知长度：安全读取最多 64KB，重建供 handler 使用
					buf := bufferPool.Get().(*bytes.Buffer)
					buf.Reset()
					limited := io.LimitReader(c.Request.Body, maxRequestBodySize)
					if _, err := io.Copy(buf, limited); err == nil && buf.Len() > 0 {
						data := buf.Bytes()
						requestBody = make([]byte, len(data))
						copy(requestBody, data)
						// 重建 body 供 handler 使用(必须使用 cloned requestBody, 避免 buf 被 pool 重置后产生并发竞争)
						c.Request.Body = io.NopCloser(bytes.NewReader(requestBody))
					}
					bufferPool.Put(buf)
				}
			}
		}

		// 包装 ResponseWriter
		buf := bufferPool.Get().(*bytes.Buffer)
		buf.Reset()
		defer bufferPool.Put(buf)

		w := &responseWriter{
			ResponseWriter: c.Writer,
			body:           buf,
		}
		c.Writer = w

		// 设置带追踪的 logger
		loggerWithTrace := WithTraceID(ctx, log)
		ctx = WithLogger(ctx, loggerWithTrace)
		c.Request = c.Request.WithContext(ctx)

		// 仅在日志级别允许时记录请求信息(生产环境为 Warn 级别时短路,0 内存开销)
		if log.Core().Enabled(zapcore.InfoLevel) {
			requestInfo := HTTPRequestInfo{
				Host:       c.Request.Host,
				Method:     method,
				Path:       path,
				Query:      c.Request.URL.RawQuery,
				Headers:    FilterHeaders(c.Request.Header),
				Body:       FilterContent(contentType, requestBody),
				IP:         c.ClientIP(),
				UserAgent:  c.Request.UserAgent(),
				ClientIP:   GetClientIP(c.Request),
				RemoteAddr: c.Request.RemoteAddr,
				Referer:    c.Request.Referer(),
			}
			loggerWithTrace.Info("", KVAny("content", requestInfo))
		}

		c.Next()

		// 记录响应信息与耗时
		duration := time.Since(start)
		status := c.Writer.Status()
		shouldLogResponse := (status >= 500 && log.Core().Enabled(zapcore.ErrorLevel)) ||
			(status >= 400 && status < 500 && log.Core().Enabled(zapcore.WarnLevel)) ||
			(status < 400 && log.Core().Enabled(zapcore.InfoLevel))

		var responseBody string
		if shouldLogResponse {
			responseInfo := HTTPResponseInfo{
				Method:   method,
				Path:     path,
				HttpCode: status,
				Headers:  FilterHeaders(w.Header()),
				Body:     FilterContent(w.Header().Get("Content-Type"), w.body.Bytes()),
				Duration: float64(duration.Microseconds()) / 1000.0, // 转换为毫秒
			}
			responseBody = responseInfo.Body
			if status >= 500 {
				loggerWithTrace.Error("", KVAny("content", responseInfo))
			} else if status >= 400 {
				loggerWithTrace.Warn("", KVAny("content", responseInfo))
			} else {
				loggerWithTrace.Info("", KVAny("content", responseInfo))
			}
		}

		// 记录追踪信息
		// 设置 span 属性（response body 截断避免泄露敏感数据）
		spanBody := responseBody
		if len(spanBody) == 0 && w.body != nil && w.body.Len() > 0 {
			spanBody = FilterContent(w.Header().Get("Content-Type"), w.body.Bytes())
		}
		if len(spanBody) > 512 {
			spanBody = spanBody[:512] + "...(truncated)"
		}
		span.SetAttributes(
			attribute.String("http.method", method),
			attribute.String("http.path", path),
			attribute.String("http.user_agent", c.Request.UserAgent()),
			attribute.String("http.client_ip", GetClientIP(c.Request)),
			attribute.Int("http.status_code", status),
			attribute.String("http.response_body", spanBody),
			attribute.Float64("duration", float64(duration.Microseconds())/1000.0),
		)
	}
}
