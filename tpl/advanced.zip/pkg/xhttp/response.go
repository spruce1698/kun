/**
 * @Author:
 * @Date: 2024-03-28 15:06
 * @Desc: 统一输出
 */

package xhttp

import (
	"errors"
	"net/http"

	"advanced/pkg/validator"
	"advanced/pkg/xerror"

	"github.com/gin-gonic/gin"
)

type (
	Response struct {
		Code    int    `json:"code"`    // 错误码,非0为错误
		Message string `json:"message"` // 错误消息
	}
	RespData struct {
		Response
		Data any `json:"data"` // 响应数据
	}
	RespList struct {
		Response
		Page     int64 `json:"page"`     // 当前页
		PageSize int64 `json:"pageSize"` // 每页数据
		Total    int64 `json:"total"`    // 总条数
		Items    any   `json:"items"`    // 数据列表
	}
	RespMore struct {
		Response
		Page     int64 `json:"page"`     // 当前页
		PageSize int64 `json:"pageSize"` // 每页数据
		HasMore  bool  `json:"hasMore"`  // 是否还有 true 还有下一页
		Items    any   `json:"items"`    // 数据列表
	}
)

// TooRequest 请求繁忙
func TooRequest(ctx *gin.Context) {
	r := &Response{
		Code:    http.StatusServiceUnavailable,
		Message: "Too many request.",
	}
	ctx.JSON(http.StatusServiceUnavailable, r)
}

// AuthFail 未授权。返回 HTTP 401(标准语义) + 业务 code,前端按业务 code 处理。
// 不返回 201 绕过 axios 拦截器——监控/网关按 HTTP 状态码告警,201 会被误判为成功。
func AuthFail(ctx *gin.Context, code ...int) {
	r := &RespData{
		Data: "",
	}
	r.Code = xerror.Unauthorized
	if len(code) > 0 {
		r.Code = code[0]
	}
	r.Message = xerror.CodeMap[r.Code]
	ctx.JSON(http.StatusUnauthorized, r)
}

// WithNotFoundPath 未找到路由
func WithNotFoundPath(ctx *gin.Context) {
	r := &RespData{
		Data: "",
	}
	r.Code = xerror.NotFoundPath
	r.Message = xerror.CodeMap[xerror.NotFoundPath]

	ctx.JSON(http.StatusNotFound, r)
}

// BusFail 业务错误
// 仅 xerror.Error 类型错误向客户端暴露其 message;其余错误(如 gorm/redis 原始错误)
// 可能含 SQL/表名/连接串等内部信息,统一返回通用消息,避免信息泄漏。
func BusFail(ctx *gin.Context, err error) {
	r := &RespData{
		Data: "",
	}

	var e xerror.Error
	if ok := errors.As(err, &e); ok {
		r.Code = e.Code()
		r.Message = e.Error()
	} else {
		// 非业务错误:返回通用消息,详细错误已在 service 层经 xerror.NewError 记录日志。
		r.Code = xerror.BusinessError
		r.Message = xerror.CodeMap[xerror.BusinessError]
	}

	ctx.JSON(http.StatusOK, r)
}

// BusCode 业务code
func BusCode(ctx *gin.Context, code int, err error) {
	r := &Response{
		Code: code,
	}

	var valErrs validator.Errors
	// validator.Errors 类型错误直接返回
	if ok := errors.As(err, &valErrs); ok {
		// 对 validator.Errors 类型错误则进行翻译
		valMsg := validator.Message(valErrs)
		if len(valMsg) > 0 {
			r.Message = valMsg[0]
		}
	} else { // 非validator.Errors 类型错误直接返回
		r.Message = err.Error()
	}
	// 没有错误信息根据code返回
	if r.Message == "" {
		r.Message = xerror.CodeMap[code]
	}
	ctx.JSON(http.StatusOK, r)
}

// Data 返回数据
func Data(ctx *gin.Context, message string, data any) {
	r := &RespData{
		Data: data,
	}
	r.Code = xerror.Success
	r.Message = message

	if r.Message == "" {
		r.Message = xerror.CodeMap[xerror.Success]
	}

	ctx.JSON(http.StatusOK, r)
}

// List 返回分页列表
func List(ctx *gin.Context, message string, page, pageSize, total int64, items any) {
	// 确保 list 字段返回 [] 而非 null
	if items == nil {
		items = []any{}
	}
	r := &RespList{
		Total:    total,
		Items:    items,
		Page:     page,
		PageSize: pageSize,
	}
	r.Code = xerror.Success
	r.Message = message

	if r.Message == "" {
		r.Message = xerror.CodeMap[xerror.Success]
	}

	ctx.JSON(http.StatusOK, r)
}

// More 返回更多列表
func More(ctx *gin.Context, message string, page, pageSize int64, hasMore bool, items any) {
	// 确保 list 字段返回 [] 而非 null
	if items == nil {
		items = []any{}
	}
	r := &RespMore{
		Items:    items,
		Page:     page,
		PageSize: pageSize,
		HasMore:  hasMore,
	}
	r.Code = xerror.Success
	r.Message = message

	if r.Message == "" {
		r.Message = xerror.CodeMap[xerror.Success]
	}

	ctx.JSON(http.StatusOK, r)
}

// Text 直接输出文本字符串
func Text(ctx *gin.Context, code int, message string) {
	ctx.String(code, message)
}

// Redirect 服务器重定向 temporarily  302临时跳转,301永久跳转
func Redirect(ctx *gin.Context, code int, url string) {
	ctx.Redirect(code, url)
}

// Html 根据模板输出html页面
func Html(ctx *gin.Context, code int, name string, data any) {
	ctx.HTML(code, name, data)
}
