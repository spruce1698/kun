/**
 * @Author:
 * @Date: 2024-03-28 16:50
 * @Desc: 请求
 */

package xhttp

type (
	PageArg struct {
		OrderField string `form:"orderField"`          // 排序字段
		OrderType  int    `form:"orderType"`           // 排序类型 0升序 1降序
		Page       int    `form:"page,default=1"`      // 当前页
		PageSize   int    `form:"pageSize,default=20"` // 每页条数
	}
)

func (r *PageArg) DefaultHandle() {
	if r.Page == 0 {
		r.Page = 1
	}
	if r.PageSize == 0 {
		r.PageSize = 20
	}
}
