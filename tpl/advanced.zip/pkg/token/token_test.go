/**
 * @Author: spruce
 * @Date: 2024-03-28 15:37
 * @Desc: token 测试
 */

package token

import (
	"fmt"
	"testing"

	"advanced/pkg/xconfig"
)

// func Test_Token(t *testing.T) {
// 	tokenObj := New(tokenCnf, xredis.New(tokenCnf, nil))
// 	token := tokenObj.Generate("10") // 10#1111
// 	t.Log(token)
//
// 	userId, err := tokenObj.verify(token)
// 	t.Log(err)
// 	t.Log(userId)
// }
//
// func Test_Disuse(t *testing.T) {
// 	err := New(tokenCnf, xredis.New(tokenCnf, nil)).Disuse("10")
// 	t.Log(err)
// }

var v5Cnf = &xconfig.Cnf{
	Redis: struct {
		Source   []string
		Password string
		Cluster  bool
	}{
		Source:   []string{"127.0.0.1:6379"},
		Password: "1cVeQ26GhlUSsRmx",
		Cluster:  false,
	},
	Token: struct {
		Secret        string
		RefreshSecret string
		Expire        int64
		Refresh       int64
		QueryKey      string
		CacheKey      string
		MultiLogin    bool
	}{
		Secret:        "Ux5VGo4azBHFyqDleNwj1RgS2CbLcThK",
		RefreshSecret: "BHFyqUx5VGo4azDleNwj1RgS2CbLcThK",
		Expire:        3600,
		Refresh:       604800,
	},
}

var jwt = NewJwt(v5Cnf, nil)

func Test_Gen(t *testing.T) {
	got, err := jwt.Gen(&Payload{OrganizeId: 999, AccountId: 1, GroupId: 2})
	fmt.Println(err)
	fmt.Println(got)
}

func Test_Parse(t *testing.T) {
	tt := "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJvcmdhbml6ZUlkIjo5OTksImFjY291bnRJZCI6MSwiZ3JvdXBJZCI6MiwiaXNzIjoic29tZWJvZHkiLCJzdWIiOiI3YmYyOGE2NGMxNjAxYTMwYTU2OGM3NDkxYjAwNmMwYjI1YjIxMzRiM2IwM2Y4NGJiYWRkNWNlMGQ4ZDM4MWJlIiwiYXVkIjpbInBPckNlOXljZkg2dFVrWU9Ud3NacW00eWFGYXAxZTlDIl0sImV4cCI6MTcyMDU3NzgwOCwibmJmIjoxNzIwNTc0MjA3LCJpYXQiOjE3MjA1NzQyMDgsImp0aSI6Ik1zS3JPQmZlSEFUU0ZFRnEifQ.MnE8CHwzLIo7Q0nO6S9aRdR2fxpWpq4eXPwjN0yXKtf0K0dUI5SrzhuUbNqa73gW"
	// tt := "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJvcmdhbml6ZUlkIjo5OTksImFjY291bnRJZCI6MSwiZ3JvdXBJZCI6MiwiaXNzIjoicmVmcmVzaCIsInN1YiI6ImVmZmZjZmM1ZGMxNjAxYWZlOWVjODkzNTFhOGQwNDkxNzU4YTMyOTBjZGI4Y2I3NTQ0ZDk5ZDBmNmEwYTJiNzAiLCJhdWQiOlsiSXh6SDRkUHdZS0FwUkJUd0V5Qy9JSUJwYVR1WUlEU0tmcDNtZkdlNnBLNEtYbk5rSG1mYnpLTDJJZnF0RXFEVGY2OHB5cDBJeVZ1ZmxibU45dHZsY2lxaXF6VmxVYkJtTzJodjFNQ0s1S3Jxa2svVENOVk5qa29CcEtNYUdZZTJJTFVHM0ZrOG9ucWdhOTNmQU1yR0tPMmxMbzRCQWViOUFKeTRFTzZqeWExaVFuT1BMSmdlejVLMVg1TWJxbFN6bXZUeXdNZVZUQjQ2eVRJQTg3ZUNNSTA1cXNHU2hSamlOd0xaQ09UcWVIND0iLCJlYzg4NzAwZDRlMGYxNzE1MmJhMDA0YTk4MmNmZTNkNSJdLCJleHAiOjE3MjExNzkwMDgsIm5iZiI6MTcyMDU3NDIwNywiaWF0IjoxNzIwNTc0MjA4LCJqdGkiOiJuN0NHS2s2MWhnM3M4UWp5In0.5rxlsWbZ7rPkMl7lXNR_RMgkyJBF6FS69miq7MDRCt67OfH3B1EtBu2fewLtJ2SR"

	got, err := jwt.Parse(tt)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(got.Subject)
	fmt.Println(got.Issuer)
	fmt.Println(got.ID)
	fmt.Println(got.NotBefore)
	fmt.Println(got.ExpiresAt)
	fmt.Println(got.Audience)
	fmt.Println(got.OrganizeId)
	fmt.Println(got.AccountId)
	fmt.Println(got.GroupId)
}

func Test_Refresh(t *testing.T) {
	tt := "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJvcmdhbml6ZUlkIjo5OTksImFjY291bnRJZCI6MSwiZ3JvdXBJZCI6MiwiaXNzIjoicmVmcmVzaCIsInN1YiI6ImVmZmZjZmM1ZGMxNjAxYWZlOWVjODkzNTFhOGQwNDkxNzU4YTMyOTBjZGI4Y2I3NTQ0ZDk5ZDBmNmEwYTJiNzAiLCJhdWQiOlsiSXh6SDRkUHdZS0FwUkJUd0V5Qy9JSUJwYVR1WUlEU0tmcDNtZkdlNnBLNEtYbk5rSG1mYnpLTDJJZnF0RXFEVGY2OHB5cDBJeVZ1ZmxibU45dHZsY2lxaXF6VmxVYkJtTzJodjFNQ0s1S3Jxa2svVENOVk5qa29CcEtNYUdZZTJJTFVHM0ZrOG9ucWdhOTNmQU1yR0tPMmxMbzRCQWViOUFKeTRFTzZqeWExaVFuT1BMSmdlejVLMVg1TWJxbFN6bXZUeXdNZVZUQjQ2eVRJQTg3ZUNNSTA1cXNHU2hSamlOd0xaQ09UcWVIND0iLCJlYzg4NzAwZDRlMGYxNzE1MmJhMDA0YTk4MmNmZTNkNSJdLCJleHAiOjE3MjExNzkwMDgsIm5iZiI6MTcyMDU3NDIwNywiaWF0IjoxNzIwNTc0MjA4LCJqdGkiOiJuN0NHS2s2MWhnM3M4UWp5In0.5rxlsWbZ7rPkMl7lXNR_RMgkyJBF6FS69miq7MDRCt67OfH3B1EtBu2fewLtJ2SR"

	got, err := jwt.Refresh(tt)
	fmt.Println(got, err)
}

func Test_Disuse(t *testing.T) {
	err := jwt.Disuse("1", 33000)
	t.Log(err)
}

func Test_CancelDisuse(t *testing.T) {
	err := jwt.CancelDisuse("1")
	t.Log(err)
}
