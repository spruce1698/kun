/**
 * @Author: spruce
 * @Date: 2024-03-28 18:26
 * @Desc: token
 */

package token

import (
	"context"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"advanced/pkg/encrypt"
	"advanced/pkg/utils"
	"advanced/pkg/xconfig"
	"advanced/pkg/xlog"
	"advanced/pkg/xredis"

	goRedis "github.com/redis/go-redis/v9"
)

const (
	Delimiter = ".#&#."

	DefaultSignExpire  = 10 * 24 * 3600                     // 单位s 默认10天
	DefaultSignEncrypt = "aa4faYss2adf3sdfC1Ba12aa3As2A2fd" // 32位
	DefaultSignQuery   = "token"
	DefaultSignCache   = "token:%s"

	FlagTokenEmpty uint32 = 1 << iota
	FlagTokenError
	FlagTokenEncryptError
	FlagTokenDecodeError
)

var (
	ErrorSignEmpty        = newError("token is empty", FlagTokenEmpty)
	ErrorSignError        = newError("token error", FlagTokenError)
	ErrorSignEncryptError = newError("token encrypt error", FlagTokenEncryptError)
	ErrorSignDecodeError  = newError("token decode error", FlagTokenDecodeError)

	onceSign     sync.Once
	instanceSign *Sign
)

type (
	Sign struct {
		Cache      *xredis.Client // 缓存
		CacheKey   string         // 缓存key
		EncryptKey string         // 加密key,32位
		QueryKey   string         // url query key
		MultiLogin bool           // 多端重复登录
		ExpireTime int64          // 过期时间 默认10天,缓存刷新时间 默认为过期时间的0.7
	}
)

func NewSign(cnf *xconfig.Cnf, log *xlog.Logger) *Sign {
	if instance == nil {
		onceSign.Do(
			func() {

				redis := xredis.New(cnf, log)
				if redis == nil {
					panic("token 需要redis的支持,请检查redis的配置")
				}

				instanceSign = &Sign{
					Cache:      redis,
					CacheKey:   DefaultSignCache,
					EncryptKey: DefaultSignEncrypt,
					QueryKey:   DefaultSignQuery,
					ExpireTime: DefaultSignExpire,
				}

				if cnf.Token.CacheKey != "" {
					instanceSign.CacheKey = cnf.Token.CacheKey
				}
				if len(cnf.Token.Secret) == 32 {
					instanceSign.EncryptKey = cnf.Token.Secret
				}
				if cnf.Token.QueryKey != "" {
					instanceSign.QueryKey = cnf.Token.QueryKey
				}
				if cnf.Token.MultiLogin {
					instanceSign.MultiLogin = cnf.Token.MultiLogin
				}
				if cnf.Token.Expire > 0 {
					instanceSign.ExpireTime = cnf.Token.Expire
				}

			},
		)
	}
	return instanceSign
}

// 生成 token
func (s *Sign) Gen(payload string) (token string) {
	if payload == "" {
		return
	}
	if s.MultiLogin {
		uuid := s.cache(payload)
		if uuid != "" {
			// 生成token
			token, _ = s.encrypt(payload, uuid)
			return
		}
	}
	// 生成token
	token, uuid := s.encrypt(payload, "")
	// 缓存token
	cacheKey := fmt.Sprintf(s.CacheKey, payload)
	refreshTime := int64(float64(s.ExpireTime) * 0.7)
	value := fmt.Sprintf("%s%s%d", uuid, Delimiter, time.Now().Unix()+refreshTime)
	_, err := s.Cache.Set(context.Background(), cacheKey, value, time.Duration(s.ExpireTime)*time.Second).Result()
	if err != nil {
		return ""
	}
	return
}

// 解析 token
func (s *Sign) Parse(r *http.Request) (payload string, err error) {
	// 获取token
	token := s.request(r)
	if token == "" {
		err = ErrorSignEmpty
		return
	}
	// 验证token
	return s.verify(token)
}

// 废弃 token
func (s *Sign) Disuse(payload string) error {
	cacheKey := fmt.Sprintf(s.CacheKey, payload)
	_, err := s.Cache.Del(context.Background(), cacheKey).Result()
	return err
}

// 通过payload获取缓存token
func (s *Sign) cache(payload string) (uuid string) {
	ctx := context.Background()
	cacheKey := fmt.Sprintf(s.CacheKey, payload)
	tokenCache := s.Cache.Get(ctx, cacheKey).Val()
	if tokenCache == "" {
		return
	}
	nowTime := time.Now().Unix()
	cacheSlice := strings.Split(tokenCache, Delimiter)
	if len(cacheSlice) == 2 {
		uuid = cacheSlice[0]
		refreshTime, _ := strconv.ParseInt(cacheSlice[1], 10, 64)
		// 需要进行缓存超时时间刷新
		if refreshTime == 0 || nowTime > refreshTime {
			refreshTime = int64(float64(s.ExpireTime) * 0.7)
			value := fmt.Sprintf("%s%s%d", uuid, Delimiter, time.Now().Unix()+refreshTime)
			_, err := s.Cache.Set(ctx, cacheKey, value, goRedis.KeepTTL).Result()
			if err != nil {
				uuid = ""
				return
			}
		}
	}
	return
}

// 请求中token
func (s *Sign) request(r *http.Request) (token string) {
	// 从HEADER中获取TOKEN
	authHeader := r.Header.Get(s.QueryKey)
	if authHeader != "" {
		partSlice := strings.SplitN(authHeader, " ", 2)
		if len(partSlice) == 2 && partSlice[0] == "Bearer" && partSlice[1] != "" {
			token = partSlice[1]
		} else if len(partSlice) == 1 && partSlice[0] != "" {
			token = partSlice[0]
		}
		return
	}
	// 从QUERY中获取TOKEN
	token = r.URL.Query().Get(s.QueryKey)
	if token != "" {
		return
	}
	// 从PARAM中获取TOKEN
	token = r.Form.Get(s.QueryKey)
	if token != "" {
		return
	}
	return
}

// 验证token
func (s *Sign) verify(token string) (payload string, err error) {
	if token == "" {
		err = ErrorSignEmpty
		return
	}
	payload, uuid := s.decrypt(token)
	if payload == "" || uuid == "" {
		err = ErrorSignError
		return
	}
	cacheUuid := s.cache(payload)
	if uuid != cacheUuid {
		err = ErrorSignError
		return
	}
	return
}

// token加密
func (s *Sign) encrypt(payload, inUuid string) (token, newUuid string) {
	newUuid = inUuid
	if newUuid == "" { // 重新生成uuid
		newUuid = encrypt.MD5(utils.GenUUid())
	}

	tokenStr := fmt.Sprintf("%s%s%s%s%d", payload, Delimiter, newUuid, Delimiter, time.Now().Nanosecond())
	// aes 编码
	token, err := encrypt.AESEncrypt(tokenStr, s.EncryptKey)
	if err != nil {
		return
	}
	return token, newUuid
}

// token解密
func (s *Sign) decrypt(token string) (payload, uuid string) {
	// aes 解码
	cipherText, err := encrypt.AESDecrypt(token, s.EncryptKey)
	if err != nil {
		return
	}

	tokenSlice := strings.Split(cipherText, Delimiter)
	if len(tokenSlice) < 2 {
		return
	}
	payload = tokenSlice[0]
	uuid = tokenSlice[1]
	return
}
