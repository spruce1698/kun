/**
* @Author: spruce
 * @Date: 2024-03-28 10:34
 * @Desc: jwt 签名,验签
*/

package token

import (
	"context"
	"net/http"
	"regexp"
	"strconv"
	"sync"
	"time"

	"advanced/pkg/encrypt"
	"advanced/pkg/utils"
	"advanced/pkg/xconfig"
	"advanced/pkg/xredis"

	v5 "github.com/golang-jwt/jwt/v5"
	"github.com/pkg/errors"
)

// 双token
// 登录成功时，会获取 2 个 token，一个是 Access Token
// 一个是 Refresh Token。Access Token 中包含用户的信息，Refresh Token 中不会含有用户信息，只会包含刷新 token 的过期时间这一个有用因素。
// 这两个 token 都需要被客户端保存到本地，访问需要认证的接口时，**只需要**携带 Access Token，如果报错 token 失效过期，则需要**同时**携带
// Access Token 和 Refresh Token 去请求刷新 token 的接口，如果此时 Refresh Token 没有过期，Access Token 是因为过期而失效时，则会再次返回新的
// Access Token 和 Refresh Token，这样就可以一直保持登录状态，如果 Refresh Token 过期了，则需要重新登录。
// 单token
// 客户端登录成功时，服务端会返回一个 token 给到客户端，客户端将这个 token 保存到本地，然后访问需要认证的接口时，携带这个 token，
// 但是如果报错 token 失效过期，那么则需要携带这个过期的 token 去请求刷新 token 的接口，这个刷新的接口会判断是不是因为 token 过期而失效，如果是，
// 那么则会解析出这个 token 中的信息，然后判断这个 token 的**首次签名时间**和当前时间对比，是不是小于**刷新 token**的时间，如果是，那么就重新颁发
// 一个 token，但是需要注意的是，重新颁发的这个 token 中记录的首次签名时间还是之前失效的 token 的首次签名时间，也就是首次签名时间不做变化，只更改了这个 token 的有效期。
// 这样就达到了通过一个 token 也可以做刷新的效果。

const (
	ErrorMissingSecret uint32 = 1 << iota
	ErrorExpiredToken
	ErrorAuthorizeElsewhere
	ErrorEmptyAuthHeader
	ErrorMissingIatField
	ErrorMissingExpField
	ErrorInvalidPublicKey
	ErrorInvalidPrivateKey
	ErrorNoPublicKeyFile
	ErrorNoPrivateKeyFile
	ErrorInvalidSigningAlgorithm
	ErrorEmptyToken
	ErrorFailedTokenCreation
	ErrorInvalidToken
	ErrorTokenEmpty // 无效的token

	DefaultSecret        = "aa4faYss2adf32aa3sdfC1Ba1As2A2fd" // 32位
	DefaultRefreshSecret = "2C9u5nEM8w4GWVrcSQ6ZxhXftOvDHFkL" // 32位
	DefaultQuery         = "Authorization"
	DefaultCache         = "token:disuse:"

	TokenTypeAccess  = "somebody"
	TokenTypeRefresh = "refresh"
)

var (
	once     sync.Once
	instance *Jwt = nil

	ErrInvalidSigningAlgorithm = newError("invalid signing algorithm", ErrorInvalidSigningAlgorithm)
	ErrInvalidToken            = newError("token is invalid", ErrorInvalidToken)
	ErrEmptyToken              = newError("token is empty", ErrorEmptyToken)
	ErrMissingIatField         = newError("missing iat field", ErrorMissingIatField)
	ErrMissingExpField         = newError("missing exp field", ErrorMissingExpField)
	ErrExpiredToken            = newError("token is expired", ErrorExpiredToken)
)

type (
	Jwt struct {
		Cache         *xredis.Client // 缓存
		ExpireTime    time.Duration  // 过期时间,单位:s
		RefreshTime   time.Duration  // 刷新时间戳,单位:s
		Secret        string         // 加密密钥
		RefreshSecret string         // 刷新密钥
		QueryKey      string         // Token查找key
		CacheKey      string         // Token废弃缓存key
	}

	JwtToken struct {
		AccessToken     string // 访问token
		AccessExpireAt  int64  // 访问token过期时间戳
		RefreshToken    string // 刷新token
		RefreshExpireAt int64  // 刷新token过期时间戳
	}
)

// NewJwt 创建
func NewJwt(conf *xconfig.Conf, redisCli *xredis.Client) *Jwt {
	if instance == nil {
		once.Do(
			func() {
				if redisCli == nil {
					panic("token 需要redis的支持,请检查redis的配置")
				}
				instance = &Jwt{
					ExpireTime:    2 * time.Hour,
					RefreshTime:   24 * 7 * time.Hour,
					Secret:        DefaultSecret,
					RefreshSecret: DefaultRefreshSecret,
					QueryKey:      DefaultQuery,
					CacheKey:      DefaultCache,
					Cache:         redisCli,
				}

				if conf.Token.QueryKey != "" {
					instance.QueryKey = conf.Token.QueryKey
				}
				if len(conf.Token.Secret) > 0 {
					instance.Secret = conf.Token.Secret
				}
				if len(conf.Token.RefreshSecret) > 0 {
					instance.RefreshSecret = conf.Token.RefreshSecret
				}
				if conf.Token.Expire > 0 {
					instance.ExpireTime = time.Duration(conf.Token.Expire) * time.Second
				}
				if conf.Token.Refresh > 0 {
					instance.RefreshTime = time.Duration(conf.Token.Refresh) * time.Second
				}
				if instance.RefreshTime <= instance.ExpireTime {
					panic("刷新时间必须大于 token 的过期时间")
				}
			})
	}
	return instance
}

// Gen 生成 token AccessToken和RefreshToken
func (j *Jwt) Gen(id int64) (*JwtToken, error) {
	cTime := time.Now()

	claims := v5.RegisteredClaims{
		IssuedAt:  v5.NewNumericDate(cTime),                       // 颁发时间
		NotBefore: v5.NewNumericDate(cTime.Add(-1 * time.Second)), // 生效时间
		ExpiresAt: v5.NewNumericDate(cTime.Add(j.ExpireTime)),     // 过期时间
		Issuer:    TokenTypeAccess,                                // 签发人
		Subject:   strconv.FormatInt(id, 10),                      // 主题,用户id
		ID:        utils.GenStr(0, 16),                            // id
	}
	accessExpireAt := claims.ExpiresAt.Unix()
	accessToken, err := v5.NewWithClaims(v5.SigningMethodHS384, claims).SignedString([]byte(j.Secret))
	if err != nil {
		return nil, err
	}

	refreshClaims := v5.RegisteredClaims{
		IssuedAt:  claims.IssuedAt,                                                        // 颁发时间
		NotBefore: claims.NotBefore,                                                       // 生效时间
		ExpiresAt: v5.NewNumericDate(cTime.Add(j.RefreshTime)),                            // 过期时间
		Issuer:    TokenTypeRefresh,                                                       // 签发人
		ID:        encrypt.MD5to16(claims.ID + claims.Subject + claims.IssuedAt.String()), // 主题,用户id
	}
	refreshExpireAt := claims.ExpiresAt.Unix()
	refreshToken, err := v5.NewWithClaims(v5.SigningMethodHS384, refreshClaims).SignedString([]byte(j.RefreshSecret))
	if err != nil {
		return nil, err
	}

	return &JwtToken{
		AccessToken:     accessToken,     // 访问token
		AccessExpireAt:  accessExpireAt,  // 访问token过期时间戳
		RefreshToken:    refreshToken,    // 刷新token
		RefreshExpireAt: refreshExpireAt, // 刷新token过期时间戳
	}, nil
}

// Refresh 刷新token AccessToken和RefreshToken
func (j *Jwt) Refresh(accessToken, refreshToken string) (*JwtToken, error) {
	keepOld := true
	// 先判断 refresh token 是否有效
	refreshClaims, err := j.Parse(refreshToken, TokenTypeRefresh)
	if err != nil {
		return nil, err
	}
	// 3min前的token生成新的token,3min内不变
	if refreshClaims.IssuedAt.Unix() < time.Now().Unix()-180 {
		keepOld = false
	}

	// 解析原的AccessToken
	accessClaims, err := j.Parse(accessToken, TokenTypeAccess)
	if err != nil && errors.Is(err, ErrExpiredToken) {
		keepOld = false
	} else if err != nil {
		return nil, err
	}
	if encrypt.MD5to16(accessClaims.ID+accessClaims.Subject+refreshClaims.IssuedAt.String()) != refreshClaims.ID {
		return nil, ErrInvalidToken
	}

	if keepOld {
		return &JwtToken{
			AccessToken:     accessToken,                    // 访问token
			AccessExpireAt:  accessClaims.ExpiresAt.Unix(),  // 访问token过期时间戳
			RefreshToken:    refreshToken,                   // 刷新token
			RefreshExpireAt: refreshClaims.ExpiresAt.Unix(), // 刷新token过期时间戳
		}, nil
	}

	id, _ := strconv.ParseInt(accessClaims.Subject, 10, 64)
	token, tokenErr := j.Gen(id)
	if tokenErr == nil && token != nil {
		// 生成行的后,旧的refreshToken废弃
		_ = j.Disuse(refreshToken, refreshClaims.ExpiresAt.Unix()-time.Now().Unix())
	}
	return token, tokenErr
}

// Find 查找
func (j *Jwt) Find(r *http.Request) string {
	// 从HEADER中获取TOKEN
	tokenStr := r.Header.Get(j.QueryKey)
	if tokenStr != "" {
		return tokenStr
	}
	// 从QUERY中获取TOKEN
	tokenStr = r.URL.Query().Get(j.QueryKey)
	if tokenStr != "" {
		return tokenStr
	}
	// 从PARAM中获取TOKEN
	tokenStr = r.Form.Get(j.QueryKey)
	if tokenStr != "" {
		return tokenStr
	}
	// 从COOKIE中获取TOKEN
	cookie, _ := r.Cookie(j.QueryKey)
	if cookie != nil {
		tokenStr = cookie.String()
		if tokenStr != "" {
			return tokenStr
		}
	}
	return ""
}

// Parse 解析
func (j *Jwt) Parse(tokenStr string, optType ...string) (*v5.RegisteredClaims, error) {
	cTime := time.Now()
	tokenStr = regexp.MustCompile(`(?i)Bearer `).ReplaceAllString(tokenStr, "")
	if tokenStr == "" {
		return nil, ErrEmptyToken
	}
	// tokenStr 在黑名单
	hasBlacklist, _ := j.Cache.Exists(context.Background(), j.CacheKey+encrypt.MD5(tokenStr)).Result()
	if hasBlacklist > 0 {
		return nil, ErrInvalidToken
	}

	// 解析 token
	payload := &v5.RegisteredClaims{}
	if len(optType) > 0 && optType[0] == TokenTypeRefresh {
		claim, err := v5.ParseWithClaims(tokenStr, payload, func(token *v5.Token) (any, error) {
			return []byte(j.RefreshSecret), nil
		})
		if err != nil || !claim.Valid {
			return nil, ErrInvalidToken
		}
		// 判断token类型是否错误
		if payload.Issuer != TokenTypeRefresh {
			return nil, ErrInvalidToken
		}
	} else {
		claim, err := v5.ParseWithClaims(tokenStr, payload, func(token *v5.Token) (any, error) {
			return []byte(j.Secret), nil
		})
		// 对token对象中的Claim进行类型断言
		if err != nil || !claim.Valid { // 校验token
			return nil, ErrInvalidToken
		}

		// 判断token类型是否错误
		if payload.Issuer != TokenTypeAccess || payload.Subject == "" {
			return nil, ErrInvalidToken
		}
		// id在黑名单
		hasBlacklist, _ = j.Cache.Exists(context.Background(), j.CacheKey+encrypt.MD5(payload.Subject)).Result()
		if hasBlacklist > 0 {
			return nil, ErrInvalidToken
		}
	}

	// 判断token类型是否错误
	if payload.ID == "" {
		return nil, ErrInvalidToken
	}

	// 是否还未生效 生效时间大于过期时间
	if payload.NotBefore.After(cTime) {
		return nil, ErrInvalidToken
	}
	// 是否过期 过期时间小于当前时间
	if payload.ExpiresAt.Before(cTime) {
		return nil, ErrExpiredToken
	}

	return payload, nil
}

// Disuse 废弃的值可以是accountId;也可以是整个key ,expiration 为过期时间
func (j *Jwt) Disuse(value string, expiration int64) error {
	cacheKey := j.CacheKey + encrypt.MD5(value)
	_, err := j.Cache.SetNX(context.Background(), cacheKey, 1, time.Duration(expiration)*time.Second).Result()
	return err
}

// CancelDisuse 取消废弃
func (j *Jwt) CancelDisuse(value string) error {
	cacheKey := j.CacheKey + encrypt.MD5(value)
	_, err := j.Cache.Del(context.Background(), cacheKey).Result()
	return err
}

// var (
// 	once     sync.Once
// 	instance *Jwt = nil
//
// 	ErrInvalidSigningAlgorithm = newError("invalid signing algorithm", ErrorInvalidSigningAlgorithm)
// 	ErrInvalidToken            = newError("token is invalid", ErrorInvalidToken)
// 	ErrEmptyToken              = newError("token is empty", ErrorEmptyToken)
// 	ErrMissingIatField         = newError("missing iat field", ErrorMissingIatField)
// 	ErrMissingExpField         = newError("missing exp field", ErrorMissingExpField)
// 	ErrExpiredToken            = newError("token is expired", ErrorExpiredToken)
// )
//
// type (
// 	Jwt struct {
// 		Cache       *xredis.Client // 缓存
// 		ExpireTime  time.Duration  // 过期时间,单位:s
// 		RefreshTime time.Duration  // 刷新时间戳,单位:s
// 		Secret      string         // 加密密钥
// 		QueryKey    string         // Token查找key
// 		CacheKey    string         // Token废弃缓存key
// 	}
//
// 	JwtToken struct {
// 		Token    string // 访问token
// 		ExpireAt int64  // 访问token过期时间戳,需要重新登录
// 	}
// )
//
// // 创建
// func NewJwt(conf *xconfig.Conf, log *xlog.Logger) *Jwt {
// 	if instance == nil {
// 		once.Do(
// 			func() {
// 				redis := xredis.New(conf, log)
// 				if redis == nil {
// 					panic("token 需要redis的支持,请检查redis的配置")
// 				}
// 				instance = &Jwt{
// 					ExpireTime:  2 * time.Hour,
// 					RefreshTime: 24 * 7 * time.Hour,
// 					Secret:      DefaultSecret,
// 					QueryKey:    DefaultQuery,
// 					CacheKey:    DefaultCache,
// 					Cache:       redis,
// 				}
//
// 				if conf.Token.QueryKey != "" {
// 					instance.QueryKey = conf.Token.QueryKey
// 				}
// 				if len(conf.Token.Secret) > 0 {
// 					instance.Secret = conf.Token.Secret
// 				}
// 				if conf.Token.Expire > 0 {
// 					instance.ExpireTime = time.Duration(conf.Token.Expire) * time.Second
// 				}
// 				if conf.Token.Refresh > 0 {
// 					instance.RefreshTime = time.Duration(conf.Token.Refresh) * time.Second
// 				}
// 				if instance.RefreshTime <= instance.ExpireTime {
// 					panic("刷新时间必须大于 token 的过期时间")
// 				}
// 			})
// 	}
// 	return instance
// }
//
// // 生成 token AccessToken和RefreshToken
// func (j *Jwt) Gen(id int64) (*JwtToken, error) {
// 	cTime := time.Now()
//
// 	claims := &v5.RegisteredClaims{
// 		IssuedAt:  v5.NewNumericDate(cTime),                       // 颁发时间首次签名时间（后续刷新 token 不会更新）
// 		NotBefore: v5.NewNumericDate(cTime.Add(-1 * time.Second)), // 生效时间
// 		ExpiresAt: v5.NewNumericDate(cTime.Add(j.ExpireTime)),     // 过期时间
// 		Issuer:    TokenTypeAccess,                                // 签发人
// 		Subject:   strconv.FormatInt(id, 10),                      // 主题,用户id
// 		ID:        utils.GenStr(0, 16),                            // id
// 	}
// 	token, err := j.createToken(claims)
// 	if err != nil {
// 		return nil, err
// 	}
//
// 	expireAt := v5.NewNumericDate(cTime.Add(j.RefreshTime)).Unix()
// 	return &JwtToken{
// 		Token:    token,    // 访问token
// 		ExpireAt: expireAt, // 访问token过期时间戳
// 	}, nil
// }
//
// // 刷新token
// func (j *Jwt) Refresh(token string) (*JwtToken, error) {
// 	// 先判断 token 是否有效
// 	claims, err := j.Parse(token)
// 	if err != nil && errors.Is(err, ErrExpiredToken) {
// 		if claims.IssuedAt.Add(j.RefreshTime).Unix() < time.Now().Unix() {
// 			return nil, ErrExpiredToken
// 		}
// 		id, _ := strconv.ParseInt(claims.Subject, 10, 64)
// 		newToken, tokenErr := j.Gen(id)
// 		if tokenErr == nil && newToken != nil {
// 			// 生成行的后,旧的refreshToken废弃
// 			_ = j.Disuse(token, int64(j.RefreshTime))
// 		}
// 		return newToken, tokenErr
// 	} else if err != nil {
// 		return nil, err
// 	}
// 	// 3min前的token生成新的token,3min内不变
// 	if claims.ExpiresAt.Unix() < time.Now().Unix()-180 {
// 		claims.ExpiresAt = v5.NewNumericDate(time.Now().Add(j.ExpireTime)) // 过期时间
// 		newToken, newTokenErr := j.createToken(claims)
// 		if newTokenErr != nil {
// 			return nil, newTokenErr
// 		}
// 		token = newToken
// 	}
// 	return &JwtToken{
// 		Token:    token,                   // 访问token
// 		ExpireAt: claims.ExpiresAt.Unix(), // 访问token过期时间戳
// 	}, nil
// }
//
// // 查找
// func (j *Jwt) Find(r *http.Request) string {
// 	// 从HEADER中获取TOKEN
// 	tokenStr := r.Header.Get(j.QueryKey)
// 	if tokenStr != "" {
// 		return tokenStr
// 	}
// 	// 从QUERY中获取TOKEN
// 	tokenStr = r.URL.Query().Get(j.QueryKey)
// 	if tokenStr != "" {
// 		return tokenStr
// 	}
// 	// 从PARAM中获取TOKEN
// 	tokenStr = r.Form.Get(j.QueryKey)
// 	if tokenStr != "" {
// 		return tokenStr
// 	}
// 	// 从COOKIE中获取TOKEN
// 	cookie, _ := r.Cookie(j.QueryKey)
// 	if cookie != nil {
// 		tokenStr = cookie.String()
// 		if tokenStr != "" {
// 			return tokenStr
// 		}
// 	}
// 	return ""
// }
//
// // 解析
// func (j *Jwt) Parse(tokenStr string) (*v5.RegisteredClaims, error) {
// 	cTime := time.Now()
// 	tokenStr = regexp.MustCompile(`(?i)Bearer `).ReplaceAllString(tokenStr, "")
// 	if tokenStr == "" {
// 		return nil, ErrEmptyToken
// 	}
// 	// tokenStr 在黑名单
// 	hasBlacklist, _ := j.Cache.Exists(context.Background(), j.CacheKey+encrypt.MD5(tokenStr)).Result()
// 	if hasBlacklist > 0 {
// 		return nil, ErrInvalidToken
// 	}
//
// 	// 解析 token
// 	payload := &v5.RegisteredClaims{}
// 	claim, err := v5.ParseWithClaims(tokenStr, payload, func(token *v5.Token) (any, error) {
// 		return []byte(j.Secret), nil
// 	})
// 	// 对token对象中的Claim进行类型断言
// 	if err != nil || !claim.Valid || payload.Subject == "" { // 校验token
// 		return nil, ErrInvalidToken
// 	}
//
// 	// id在黑名单
// 	hasBlacklist, _ = j.Cache.Exists(context.Background(), j.CacheKey+encrypt.MD5(payload.Subject)).Result()
// 	if hasBlacklist > 0 {
// 		return nil, ErrInvalidToken
// 	}
//
// 	// 是否还未生效 生效时间大于过期时间
// 	if payload.NotBefore.After(cTime) {
// 		return nil, ErrInvalidToken
// 	}
// 	// 是否过期 过期时间小于当前时间
// 	if payload.ExpiresAt.Before(cTime) {
// 		return nil, ErrExpiredToken
// 	}
//
// 	return payload, nil
// }
//
// // 废弃 的值可以是accountId;也可以是整个key ,expiration 为过期时间
// func (j *Jwt) Disuse(value string, expiration int64) error {
// 	cacheKey := j.CacheKey + encrypt.MD5(value)
// 	_, err := j.Cache.SetNX(context.Background(), cacheKey, 1, time.Duration(expiration)*time.Second).Result()
// 	return err
// }
//
// // 取消废弃
// func (j *Jwt) CancelDisuse(value string) error {
// 	cacheKey := j.CacheKey + encrypt.MD5(value)
// 	_, err := j.Cache.Del(context.Background(), cacheKey).Result()
// 	return err
// }
//
// // 创建 token，用于内部调用
// func (j *Jwt) createToken(claims *v5.RegisteredClaims) (string, error) {
// 	tokenClaims := v5.NewWithClaims(v5.SigningMethodHS384, claims)
// 	return tokenClaims.SignedString([]byte(j.Secret))
// }
