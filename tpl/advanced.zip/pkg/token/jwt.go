/**
* @Author: spruce
 * @Date: 2024-04-20 10:34
 * @Desc: jwt 签名,验签
*/

package token

import (
	"context"
	"fmt"
	"net/http"
	"regexp"
	"strconv"
	"sync"
	"time"

	"advanced/pkg/encrypt"
	"advanced/pkg/utils"
	"advanced/pkg/xconfig"
	"advanced/pkg/xredis"

	gojwt "github.com/golang-jwt/jwt"
	"github.com/pkg/errors"
)

const (
	JWTErrorMissingSecretKey uint32 = 1 << iota
	JWTErrorExpiredToken
	JWTErrorAuthorizeElsewhere
	JWTErrorEmptyAuthHeader
	JWTErrorMissingIatField
	JWTErrorMissingExpField
	JWTErrorInvalidPublicKey
	JWTErrorInvalidPrivateKey
	JWTErrorNoPublicKeyFile
	JWTErrorNoPrivateKeyFile
	JWTErrorInvalidSigningAlgorithm
	JWTErrorEmptyToken
	JWTErrorFailedTokenCreation
	JWTErrorInvalidToken
	JWTErrorTokenEmpty

	JwtAudience  = "aud"
	JwtExpiresAt = "exp"
	JwtId        = "jti"
	JwtIssuedAt  = "iat"
	JwtIssuer    = "iss"
	JwtNotBefore = "nbf"
	JwtSubject   = "sub"

	DefaultEncryptKey = "aa4faYss2adf3sdfC1Ba12aa3As2A2fd" // 32位
	DefaultQueryKey   = "token"
	DefaultCacheKey   = "token:disuse:%s"

	JwtPayloadOrganizeId = "organizeId"
	JwtPayloadAccountId  = "accountId"
	JwtPayloadGroupId    = "groupId"
)

var (
	once     sync.Once
	instance *Jwt = nil

	ErrInvalidSigningAlgorithm = newError("invalid signing algorithm", JWTErrorInvalidSigningAlgorithm)
	ErrInvalidToken            = newError("token is invalid", JWTErrorInvalidToken)
	ErrEmptyToken              = newError("token is empty", JWTErrorEmptyToken)
	ErrMissingIatField         = newError("missing iat field", JWTErrorMissingIatField)
	ErrMissingExpField         = newError("missing exp field", JWTErrorMissingExpField)
	ErrExpiredToken            = newError("token is expired", JWTErrorExpiredToken)
)

type (
	Jwt struct {
		Cache      *xredis.Client // 缓存
		Algorithm  string         // 加密算法
		ExpireTime time.Duration  // 过期时间
		Secret     string         // 加密密钥
		QueryKey   string         // Token查找key
		CacheKey   string         // Token废弃缓存key
	}
	JwtToken struct {
		Token     string
		ExpireAt  int64 // 过期时间戳
		RefreshAt int64 // 刷新时间戳
	}
)

// 创建JWT
func New(cnf *xconfig.Cnf, redis *xredis.Client) *Jwt {
	if instance == nil {
		once.Do(
			func() {

				if redis == nil {
					panic("token 需要redis的支持,请检查redis的配置")
				}

				instance = &Jwt{
					Algorithm:  "HS512",
					ExpireTime: 7 * 24 * time.Hour,
					Secret:     DefaultEncryptKey,
					QueryKey:   DefaultQueryKey,
					CacheKey:   DefaultCacheKey,
					Cache:      redis,
				}

				if cnf.Token.Algorithm == "HS256" || cnf.Token.Algorithm == "HS384" || cnf.Token.Algorithm == "HS512" {
					instance.Algorithm = cnf.Token.Algorithm
				}
				if cnf.Token.QueryKey != "" {
					instance.QueryKey = cnf.Token.QueryKey
				}
				if len(cnf.Token.Secret) > 0 {
					instance.Secret = cnf.Token.Secret
				}
				if cnf.Token.ExpireTime > 0 {
					instance.ExpireTime = time.Duration(cnf.Token.ExpireTime) * time.Second
				}
			})
	}
	return instance
}

// 生成 Jwt
func (j *Jwt) Generate(payload map[string]any) (*JwtToken, error) {
	timeNow := gojwt.TimeFunc()
	expire := timeNow.Add(j.ExpireTime).Unix()

	claims := make(gojwt.MapClaims)
	for k, v := range payload {
		claims[k] = v
	}

	claims[JwtNotBefore] = timeNow.Unix() - 6 // 开始生效时间
	claims[JwtIssuedAt] = timeNow.Unix()      // 颁发时间
	claims[JwtExpiresAt] = expire             // 过期时间

	accountId := ""
	if v, ok := payload[JwtPayloadAccountId]; ok && v != "" {
		accountId = strconv.FormatInt(v.(int64), 10)
	} else {
		accountId = utils.GenStr(0, 32)
	}

	encryptKey := strconv.FormatInt(expire, 10) + j.Secret
	audience, _ := encrypt.AESEncrypt(accountId, string([]rune(encryptKey)[:16]))
	claims[JwtAudience] = audience // 受众

	token := gojwt.New(gojwt.GetSigningMethod(j.Algorithm))
	token.Claims = claims
	tokenStr, err := token.SignedString([]byte(j.Secret))

	if err != nil {
		return nil, err
	}
	refresh := timeNow.Add(time.Duration(int64(float64(j.ExpireTime) * 0.7))).Unix()
	return &JwtToken{
		Token:     tokenStr,
		ExpireAt:  expire,
		RefreshAt: refresh,
	}, nil
}

// 查找 Jwt
func (j *Jwt) Find(r *http.Request) string {
	// 从HEADER中获取TOKEN
	tokenStr := r.Header.Get(j.QueryKey)
	if tokenStr != "" {
		return tokenStr
	}
	// 从QUERY中获取TOKEN
	tokenStr = r.URL.Query().Get(j.QueryKey)
	if tokenStr != "" {
		return tokenStr
	}
	// 从PARAM中获取TOKEN
	tokenStr = r.Form.Get(j.QueryKey)
	if tokenStr != "" {
		return tokenStr
	}
	// 从COOKIE中获取TOKEN
	cookie, _ := r.Cookie(j.QueryKey)
	if cookie != nil {
		tokenStr = cookie.String()
		if tokenStr != "" {
			return tokenStr
		}
	}
	return ""
}

// 解析 Jwt
func (j *Jwt) Parse(tokenStr string) (gojwt.MapClaims, error) {
	tokenStr = regexp.MustCompile(`(?i)Bearer `).ReplaceAllString(tokenStr, "")
	if tokenStr == "" {
		return nil, ErrEmptyToken
	}

	hasBlacklist, _ := j.Cache.Exists(context.Background(), fmt.Sprintf(j.CacheKey, encrypt.MD5(tokenStr))).Result()
	if hasBlacklist > 0 {
		return nil, ErrInvalidToken
	}

	token, err := gojwt.Parse(tokenStr, func(t *gojwt.Token) (any, error) {
		if gojwt.GetSigningMethod(j.Algorithm) != t.Method {
			return nil, ErrInvalidSigningAlgorithm
		}
		return []byte(j.Secret), nil
	})

	if token == nil {
		return nil, ErrInvalidToken
	}

	if err != nil {
		var e *gojwt.ValidationError
		if errors.As(err, &e) {
			if e.Errors == gojwt.ValidationErrorExpired {
				return nil, ErrExpiredToken
			} else {
				return nil, ErrInvalidToken
			}
		} else {
			return nil, ErrInvalidToken
		}
	}

	claims := token.Claims.(gojwt.MapClaims)

	timeNow := gojwt.TimeFunc()

	if aud, ok := claims[JwtAudience]; !ok || aud == "" { // 受众
		return nil, ErrInvalidToken
	}

	if iat, ok := claims[JwtIssuedAt]; !ok { // 开始时间
		return nil, ErrMissingIatField
	} else if int64(iat.(float64)) > timeNow.Unix()-2 { // 早于开始时间
		return nil, ErrInvalidToken
	}

	if exp, ok := claims[JwtExpiresAt]; !ok { // 过期时间
		return nil, ErrMissingExpField
	} else if int64(exp.(float64)) < timeNow.Unix() {
		return nil, ErrExpiredToken
	}

	if accountId, ok := claims[JwtPayloadAccountId]; ok {
		idString := strconv.FormatInt(int64(accountId.(float64)), 10)
		hasBlacklist, _ = j.Cache.Exists(context.Background(), fmt.Sprintf(j.CacheKey, encrypt.MD5(idString))).Result()
		if hasBlacklist > 0 {
			return nil, ErrInvalidToken
		}
	}

	claims[JwtExpiresAt] = int64(claims[JwtExpiresAt].(float64))
	claims[JwtIssuedAt] = int64(claims[JwtIssuedAt].(float64))
	claims[JwtNotBefore] = int64(claims[JwtNotBefore].(float64))

	if organizeId, ok := claims[JwtPayloadOrganizeId]; ok {
		claims[JwtPayloadOrganizeId] = int64(organizeId.(float64))
	}
	if accountId, ok := claims[JwtPayloadAccountId]; ok {
		claims[JwtPayloadAccountId] = int64(accountId.(float64))
	}
	if groupId, ok := claims[JwtPayloadGroupId]; ok {
		claims[JwtPayloadGroupId] = int64(groupId.(float64))
	}

	return claims, nil
}

// 刷新 Jwt
func (j *Jwt) Refresh(tokenStr string) (*JwtToken, error) {
	claims, err := j.Parse(tokenStr)
	if err != nil {
		return nil, err
	}

	newClaims := make(gojwt.MapClaims)
	for k, v := range claims {
		newClaims[k] = v
	}

	currentTime := gojwt.TimeFunc()
	expire := currentTime.Add(j.ExpireTime).Unix()

	if currentTime.Unix()-newClaims[JwtIssuedAt].(int64) < 180 { // 新生成的token 3min内刷新不变
		currentTime = time.Unix(newClaims[JwtIssuedAt].(int64), 0)
		expire = currentTime.Add(j.ExpireTime).Unix()
	} else {
		encryptKey := strconv.FormatInt(newClaims[JwtExpiresAt].(int64), 10) + j.Secret
		userIdByte, _ := encrypt.AESDecrypt(newClaims[JwtAudience].(string), string([]rune(encryptKey)[:16]))
		userId := userIdByte

		newEncryptKey := strconv.FormatInt(expire, 10) + j.Secret
		audience, _ := encrypt.AESEncrypt(userId, string([]rune(newEncryptKey)[:16]))
		newClaims[JwtAudience] = audience // 受众
	}

	newClaims[JwtNotBefore] = currentTime.Unix() - 6 // 开始生效时间
	newClaims[JwtIssuedAt] = currentTime.Unix()      // 颁发时间
	newClaims[JwtExpiresAt] = expire                 // 过期时间

	token := gojwt.New(gojwt.GetSigningMethod(j.Algorithm))
	token.Claims = newClaims
	newTokenStr, err := token.SignedString([]byte(j.Secret))
	if err != nil {
		return nil, err
	}
	refresh := currentTime.Add(time.Duration(int64(float64(j.ExpireTime) * 0.7))).Unix()
	return &JwtToken{
		Token:     newTokenStr,
		ExpireAt:  expire,
		RefreshAt: refresh,
	}, nil
}

// 废弃Jwt 的值可以是accountId;也可以是整个key  expiration 为过期时间
func (j *Jwt) Disuse(value string, expiration int64) error {
	cacheKey := fmt.Sprintf(j.CacheKey, encrypt.MD5(value))
	_, err := j.Cache.SetNX(context.Background(), cacheKey, 1, time.Duration(expiration)*time.Second).Result()
	return err
}

// 取消 废弃Jwt
func (j *Jwt) CancelDisuse(value string) error {
	cacheKey := fmt.Sprintf(j.CacheKey, encrypt.MD5(value))
	_, err := j.Cache.Del(context.Background(), cacheKey).Result()
	return err
}
