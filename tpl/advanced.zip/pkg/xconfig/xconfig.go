package xconfig

import (
	"fmt"
	"os"
	"strings"
	"sync"

	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

const (
	EnvDebug   = "debug"
	EnvTest    = "test"
	EnvStaging = "staging"
	EnvRelease = "release"
)

var (
	once     sync.Once
	instance *Conf = nil
)

type (
	Conf struct {
		Env     string
		Version string

		Server ServerConf
		Broker BrokerConf

		Token TokenConf

		Log LogConf

		Mysql  MysqlConf
		Redis  RedisConf
		Kafka  KafkaConf
		Jaeger JaegerConf
	}

	ServerConf struct {
		Name         string
		Port         int64
		ReadTimeout  int64
		WriteTimeout int64
	}
	BrokerConf struct {
		Name         string
		Port         int64
		ReadTimeout  int64
		WriteTimeout int64
	}

	TokenConf struct {
		Secret        string
		RefreshSecret string
		Expire        int64
		Refresh       int64

		QueryKey   string
		CacheKey   string
		MultiLogin bool
	}

	LogConf struct {
		Level        string
		FilePath     string
		Stdout       bool
		KafkaTopic   string
		KafkaBrokers []string
	}

	MysqlConf struct {
		LogLevel string
		Source   []string
	}
	RedisConf struct {
		Source   []string
		Password string
		Cluster  bool
	}
	KafkaConf struct {
		Brokers []string
	}
	JaegerConf struct {
		Endpoint string
	}
)

func New(path string) *Conf {
	if instance == nil {
		once.Do(func() {
			confPath := os.Getenv("CONF")
			if confPath == "" {
				confPath = path
			}
			v := viper.New()
			// 设置配置文件信息
			v.SetConfigFile(confPath) // 设置文件的类型

			// 读取配置文件
			if e := v.ReadInConfig(); e != nil {
				panic(fmt.Errorf("Fatal error config file: %s \n", e))
			}
			// 监听修改
			go v.WatchConfig()

			// 启用环境变量
			v.AutomaticEnv()                                   // 自动识别环境变量
			v.SetEnvKeyReplacer(strings.NewReplacer(".", "_")) // 将 . 替换为 _   SERVER_PORT=10088 覆盖文件中 server下面port值

			c := new(Conf)
			if e := v.Unmarshal(c); e != nil {
				panic(fmt.Errorf("Fatal error config to Conf: %s \n", e))
			}
			// 为配置修改增加一个回调函数 file改变时载入
			v.OnConfigChange(func(event fsnotify.Event) {
				if e := v.Unmarshal(c); e != nil {
					panic(fmt.Errorf("Fatal error config file changed: %s \n", e))
				}
			})
			instance = c
		})
	}
	return instance
}
