/**
 * @Author: albert
 * @Date: 2024-12-26
 * @Desc: TODO
 */

package utils

//
// import (
// 	"fmt"
// 	"io"
// 	"os"
// 	"path/filepath"
//
// 	"github.com/google/safearchive"
// 	"github.com/google/safearchive/tar"
// 	"github.com/google/safearchive/zip"
// 	"github.com/google/safeopen"
// 	"github.com/google/safetext/shell"
// 	"github.com/google/safetext/yaml"
// )
//
// // 安全shell
// func Shell() error {
// 	// 创建安全的 shell 命令模板
// 	tmpl, err := shell.New("ls {{.Dir}}")
// 	if err != nil {
// 		return err
// 	}
//
// 	// 执行模板
// 	cmd, err := tmpl.Execute(map[string]string{
// 		"Dir": "/tmp/user files/", // 包含空格的路径会被安全处理
// 	})
// 	if err != nil {
// 		return err
// 	}
//
// 	fmt.Printf("Safe command: %s\n", cmd)
// 	return nil
// }
//
// // 安全Yaml
// func Yaml() error {
// 	const tmpl = `
// name: {{.Name}}
// config:
//   path: {{.Path}}
//   command: {{.Command}}
// `
//
// 	// 创建安全的 YAML 模板
// 	tmpl, err := yaml.New("config").Parse(tmpl)
// 	if err != nil {
// 		return err
// 	}
//
// 	// 执行模板
// 	data := map[string]string{
// 		"Name":    "test-app",
// 		"Path":    "/usr/local/bin",
// 		"Command": "start.sh",
// 	}
//
// 	result, err := tmpl.Execute(data)
// 	if err != nil {
// 		return err
// 	}
// 	fmt.Println(result)
// 	return nil
// }
//
// // 安全打开文件
// func OpenFile() ([]byte, error) {
// 	// 安全地打开文件
// 	f, err := safeopen.OpenFile("path/to/file.txt", "base/dir")
// 	if err != nil {
// 		return []byte{}, err
// 	}
// 	defer f.Close()
//
// 	// 读取文件内容
// 	result, err := io.ReadAll(f)
// 	if err != nil {
// 		return []byte{}, err
// 	}
// 	return result, nil
// }
//
// // 安全目录遍历
// func WalkDirectory(baseDir, targetDir string) error {
// 	checker := safeopen.NewChecker(baseDir)
//
// 	return filepath.Walk(targetDir, func(path string, info os.FileInfo, err error) error {
// 		if err != nil {
// 			return err
// 		}
//
// 		// 验证路径是否安全
// 		if err = checker.IsSafePath(path); err != nil {
// 			return fmt.Errorf("unsafe path: %v", err)
// 		}
//
// 		// 处理文件...
// 		return nil
// 	})
// }
//
// // 安全解压 TAR 文件
// func ExtractTar(tarPath, destPath string) error {
// 	// 打开 tar 文件
// 	f, err := os.Open(tarPath)
// 	if err != nil {
// 		return err
// 	}
// 	defer f.Close()
//
// 	// 创建安全的解压器
// 	extractor := tar.NewExtractor()
//
// 	// 设置安全选项
// 	extractor.Options(tar.WithMaxFileSize(1 << 30))   // 最大文件限制：1GB
// 	extractor.Options(tar.WithMaxTotalSize(10 << 30)) // 最大总大小限制：10GB
// 	extractor.Options(tar.WithDisallowSymlinks(true)) // 禁止符号链接
//
// 	// 执行解压
// 	err = extractor.Extract(f, destPath)
// 	if err != nil {
// 		return fmt.Errorf("extraction failed: %v", err)
// 	}
//
// 	return nil
// }
//
// // 安全解压 Zip 文件
// func ExtractZip(zipPath, destPath string) error {
// 	// 创建安全的 ZIP 解压器
// 	extractor := zip.NewExtractor()
//
// 	// 设置安全选项
// 	extractor.Options(zip.WithMaxFileSize(1 << 30))   // 最大文件限制：1GB
// 	extractor.Options(zip.WithMaxTotalSize(10 << 30)) // 最大总大小限制：10GB
// 	extractor.Options(zip.WithDisallowZipBombs(true)) // 防止 ZIP 炸弹
//
// 	// 执行解压
// 	err := extractor.ExtractFile(zipPath, destPath)
// 	if err != nil {
// 		return fmt.Errorf("zip extraction failed: %v", err)
// 	}
//
// 	return nil
// }
//
// // 安全性检查示例
// func validateArchive(path string) error {
// 	validator := safearchive.NewValidator()
//
// 	// 设置验证规则
// 	validator.SetRules(safearchive.Rules{
// 		MaxFileSize:      1 << 30, // 1GB
// 		MaxFiles:         1000,
// 		DisallowSymlinks: true,
// 		AllowedPaths:     []string{"data/", "config/"},
// 		DisallowedPaths:  []string{"../", "./"},
// 	})
//
// 	// 执行验证
// 	return validator.Validate(path)
// }
