/**
 * @Author: spruce
 * @Date: 2024-03-28 16:56
 * @Desc: 网络相关函数
 */

package utils

import (
	"net"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/pkg/errors"
)

// 获取有效的端口
func AvailablePort() int64 {
	l, _ := net.Listen("tcp", ":0")
	defer func() {
		_ = l.Close()
	}()
	port := l.Addr().(*net.TCPAddr).Port
	return int64(port)
}

func IPv42Int64(ip string) int64 {
	b := net.ParseIP(ip).To4()
	if b == nil {
		return 0
	}
	return int64(b[3]) | int64(b[2])<<8 | int64(b[1])<<16 | int64(b[0])<<24
}

// 获得请求IP
func ExternalIP() (string, error) {
	iFaces, err := net.Interfaces()
	if err != nil {
		return "", err
	}
	for _, iFace := range iFaces {
		if iFace.Flags&net.FlagUp == 0 {
			continue // interface down
		}
		if iFace.Flags&net.FlagLoopback != 0 {
			continue // FlagLoopback interface
		}
		addrs, err := iFace.Addrs()
		if err != nil {
			return "", err
		}
		for _, addr := range addrs {
			var ip net.IP
			switch v := addr.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			if ip == nil || ip.IsLoopback() {
				continue
			}
			ip = ip.To4()
			if ip == nil {
				continue // not an ipv4 address
			}
			return ip.String(), nil
		}
	}
	return "", errors.New("are you connected to the network?")
}

// 获得本机IP
func LocalIP() (string, error) {
	addr, err := net.ResolveUDPAddr("udp", "1.2.3.4:1")
	if err != nil {
		return "", err
	}

	conn, err := net.DialUDP("udp", nil, addr)
	if err != nil {
		return "", err
	}

	defer func(conn *net.UDPConn) {
		_ = conn.Close()
	}(conn)

	host, _, err := net.SplitHostPort(conn.LocalAddr().String())
	if err != nil {
		return "", err
	}

	return host, nil
}

// 客户端ip
func ClientIP(c *gin.Context) string {
	ip127 := "127.0.0.1"
	ip := c.Request.Header.Get("X-Real-IP")
	if strings.Contains(ip, ip127) || ip == "" {
		ip = c.Request.Header.Get("X-Forwarded-For")
	}
	if ip == "" {
		ip = ip127
	}
	if remoteIP := c.RemoteIP(); remoteIP != ip127 {
		ip = remoteIP
	}
	if clientIP := c.ClientIP(); clientIP != ip127 {
		ip = clientIP
	}
	return ip
}

// 是否为ipv4地址
func IsIPv4(input string) bool {
	ip := net.ParseIP(input)
	return ip != nil && ip.To4() != nil
}

// 是否为ipv6地址
func IsIPv6(input string) bool {
	ip := net.ParseIP(input)
	return ip != nil && ip.To4() == nil
}
