/**
 * @Author:
 * @Date: 2024-03-28 18:31
 * @Desc: 雪花id测试
 */

package utils

import (
	"fmt"
	"testing"
)

func Test_GenId(t *testing.T) {
	id := NewSnowflake(0, 0).GenId()
	fmt.Println(id)
	fmt.Println(GenDeviceID(id))
	fmt.Println(GenTimestamp(id))
	fmt.Println(GenTime(id))
	fmt.Println(GenTimestampStatus())
}

func Benchmark_GetId(b *testing.B) {
	b.ResetTimer()
	snowflake := NewSnowflake(0, 0)
	for i := 0; i < b.N; i++ {
		id := snowflake.GenId()
		fmt.Println(id)
	}
}
