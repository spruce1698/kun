/**
 * @Author: spruce
 * @Date: 2024-04-20 16:12
 * @Desc: uuid 生成
 */

package utils

import "github.com/google/uuid"

// 生成UUID
func GenUUid() string {
	return uuid.NewString()
}
