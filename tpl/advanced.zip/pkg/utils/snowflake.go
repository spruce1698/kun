/**
 * @Author:
 * @Date: 2024-03-28 18:31
 * @Desc: 雪花算法 id
 */

package utils

import (
	"fmt"
	"math/rand/v2"
	"reflect"
	"strconv"
	"sync"
	"time"

	"github.com/sony/sonyflake" // Sony 公司的一个开源项目
)

// const (
// 	StartTimeStamp = int64(1577808000000)              // 开始时间毫秒截 (2020-01-01)
// 	MachineIdBits  = uint(10)                          // 机器id所占的位数
// 	SequenceBits   = uint(12)                          // 序列所占的位数
// 	MachineIdMax   = int64(-1 ^ (-1 << MachineIdBits)) // 支持的最大机器id数量
// 	SequenceMask   = int64(-1 ^ (-1 << SequenceBits))  //
// 	MachineIdShift = SequenceBits                      // 机器id左移位数
// 	TimestampShift = SequenceBits + MachineIdBits      // 时间戳左移位数
// )
//
// type Snowflake struct {
// 	sync.Mutex       // 锁
// 	timestamp  int64 // 时间戳 ，毫秒
// 	machineId  int64
// 	sequence   int64 // 序列号
// }
//
// func NewSnowflake() *Snowflake {
// 	workerId := rand.Int63n(MachineIdMax)
// 	// 生成一个新节点
// 	return &Snowflake{
// 		timestamp: 0,
// 		machineId: workerId,
// 		sequence:  0,
// 	}
// }
//
// // 生成分布式ID
// func (s *Snowflake) GetId() int64 {
// 	s.Lock()
// 	defer func() {
// 		s.Unlock()
// 	}()
// 	now := time.Now().UnixNano() / 1e6
// 	if s.timestamp == now {
// 		// 当同一时间戳（精度：毫秒）下多次生成id会增加序列号
// 		s.sequence = (s.sequence + 1) & SequenceMask
// 		if s.sequence == 0 {
// 			// 如果当前序列超出12bit长度，则需要等待下一毫秒
// 			// 下一毫秒将使用sequence:0
// 			for now <= s.timestamp {
// 				now = time.Now().UnixNano() / 1e6
// 			}
// 		}
// 	} else {
// 		// 不同时间戳（精度：毫秒）下直接使用序列号：0
// 		s.sequence = 0
// 	}
// 	s.timestamp = now
// 	r := (now-StartTimeStamp)<<TimestampShift | (s.machineId << MachineIdShift) | (s.sequence)
// 	return r
// }

const (
	epoch             = int64(1577808000000)                           // 设置起始时间(时间戳/毫秒)：2020-01-01 00:00:00，有效期69年
	timestampBits     = uint(41)                                       // 时间戳占用位数
	datacenterIdBits  = uint(5)                                        // 数据中心id所占位数
	workerIdBits      = uint(5)                                        // 机器id所占位数
	sequenceBits      = uint(12)                                       // 序列所占的位数
	timestampMax      = int64(-1 ^ (-1 << timestampBits))              // 时间戳最大值
	datacenterIdMax   = int64(-1 ^ (-1 << datacenterIdBits))           // 支持的最大数据中心id数量
	workerIdMax       = int64(-1 ^ (-1 << workerIdBits))               // 支持的最大机器id数量
	sequenceMask      = int64(-1 ^ (-1 << sequenceBits))               // 支持的最大序列id数量
	workerIdShift     = sequenceBits                                   // 机器id左移位数
	datacenterIdShift = sequenceBits + workerIdBits                    // 数据中心id左移位数
	timestampShift    = sequenceBits + workerIdBits + datacenterIdBits // 时间戳左移位数
)

type Snowflake struct {
	sync.Mutex
	timestamp    int64
	workerId     int64 // 节点ID
	datacenterId int64 // 数据中心ID
	sequence     int64
}

func NewSnowflake(datacenterId, workerId int64) *Snowflake {
	if datacenterId < 0 || datacenterId > datacenterIdMax {
		datacenterId = rand.Int64N(datacenterIdMax)
	}
	if workerId < 0 || workerId > workerIdMax {
		workerId = rand.Int64N(workerIdMax)
	}
	return &Snowflake{
		timestamp:    0,
		datacenterId: datacenterId,
		workerId:     workerId,
		sequence:     0,
	}
}

func (s *Snowflake) GenId() int64 {
	s.Lock()
	defer func() {
		s.Unlock()
	}()
	now := time.Now().UnixNano() / 1e6 // 转毫秒
	if s.timestamp == now {
		// 当同一时间戳（精度：毫秒）下多次生成id会增加序列号
		s.sequence = (s.sequence + 1) & sequenceMask
		if s.sequence == 0 {
			// 如果当前序列超出12bit长度，则需要等待下一毫秒
			// 下一毫秒将使用sequence:0
			for now <= s.timestamp {
				now = time.Now().UnixNano() / 1e6
			}
		}
	} else {
		// 不同时间戳（精度：毫秒）下直接使用序列号：0
		s.sequence = 0
	}
	t := now - epoch
	if t > timestampMax {
		// fmt.Errorf("epoch must be between 0 and %d", timestampMax-1)
		return 0
	}
	s.timestamp = now
	r := (t)<<timestampShift | (s.datacenterId << datacenterIdShift) | (s.workerId << workerIdShift) | (s.sequence)
	return r
}

func (s *Snowflake) GenIdString() string {
	return strconv.FormatInt(s.GenId(), 10)
}

// 获取数据中心ID和机器ID
func GenDeviceID(sid int64) (datacenterId, workerId int64) {
	datacenterId = (sid >> datacenterIdShift) & datacenterIdMax
	workerId = (sid >> workerIdShift) & workerIdMax
	return
}

// 获取创建ID时的时间戳(毫秒)
func GenTimestamp(sid int64) (timestamp int64) {
	timestamp = ((sid >> timestampShift) & timestampMax) + epoch
	return
}

// 获取创建ID时的时间字符串(精度：秒)
func GenTime(sid int64) (t string) {
	// 获取的时间戳/1000转换成秒
	t = time.Unix(GenTimestamp(sid)/1000, 0).Format("2006-01-02 15:04:05")
	return
}

// 获取时间戳已使用的占比：范围（0.0 - 1.0）
func GenTimestampStatus() (status float64) {
	status = float64(time.Now().UnixNano()/1e6-epoch) / float64(timestampMax)
	return
}

func SonySnowFlake() {
	var (
		sonyFlake     *sonyflake.Sonyflake
		sonyMachineID uint16
		st            time.Time
		err           error
	)

	startTime := "2024-08-20" // 初始化一个开始的时间，表示从这个时间开始算起
	machineID := 1            // 机器 ID
	st, err = time.Parse("2006-01-02", startTime)
	if err != nil {
		panic(err)
	}

	sonyMachineID = uint16(machineID)
	settings := sonyflake.Settings{
		StartTime: st,
		MachineID: func() (uint16, error) { return sonyMachineID, nil },
	}
	sonyFlake = sonyflake.NewSonyflake(settings)
	if sonyFlake == nil {
		panic("sonyflake not created")
	}

	id, err := sonyFlake.NextID()
	if err != nil {
		panic(err)
	}

	fmt.Printf("Int64  ID: %d type of: %T -> Type %v -> Value %v \n", id, id, reflect.TypeOf(id), reflect.ValueOf(id))

}
