/**
 * @Author:
 * @Date: 2024-03-28 18:31
 * @Desc: 雪花算法 id
 */

package utils

import (
	"math/rand/v2"
	"strconv"
	"sync"
	"time"

	"github.com/sony/sonyflake" // Sony 公司的一个开源项目
)

const (
	epoch          = int64(1735660800000)                       // 设置起始时间(时间戳/毫秒)：2025-01-01 00:00:00.000，有效期69年
	timestampBits  = uint(41)                                   // 时间戳占用位数
	centerIdBits   = uint(5)                                    // 数据中心id所占位数
	workerIdBits   = uint(5)                                    // 机器id所占位数
	sequenceBits   = uint(12)                                   // 序列所占的位数
	timestampMax   = int64(-1 ^ (-1 << timestampBits))          // 时间戳最大值
	centerIdMax    = int64(-1 ^ (-1 << centerIdBits))           // 支持的最大数据中心id数量
	workerIdMax    = int64(-1 ^ (-1 << workerIdBits))           // 支持的最大机器id数量
	sequenceMask   = int64(-1 ^ (-1 << sequenceBits))           // 支持的最大序列id数量
	workerIdShift  = sequenceBits                               // 机器id左移位数
	centerIdShift  = sequenceBits + workerIdBits                // 数据中心id左移位数
	timestampShift = sequenceBits + workerIdBits + centerIdBits // 时间戳左移位数
)

type Snowflake struct {
	sync.Mutex
	timestamp int64
	workerId  int64 // 节点ID
	centerId  int64 // 数据中心ID
	sequence  int64
}

func NewSnowflake(centerID, workerID int64) *Snowflake {
	if centerID < 0 || centerID > centerIdMax {
		centerID = rand.Int64N(centerIdMax)
	}
	if workerID < 0 || workerID > workerIdMax {
		workerID = rand.Int64N(workerIdMax)
	}
	return &Snowflake{
		timestamp: 0,
		centerId:  centerID,
		workerId:  workerID,
		sequence:  0,
	}
}

func (s *Snowflake) GenID() int64 {
	s.Lock()
	defer func() {
		s.Unlock()
	}()
	now := time.Now().UnixNano() / 1e6 // 转毫秒
	if s.timestamp == now {
		// 当同一时间戳（精度：毫秒）下多次生成id会增加序列号
		s.sequence = (s.sequence + 1) & sequenceMask
		if s.sequence == 0 {
			// 如果当前序列超出12bit长度，则需要等待下一毫秒
			// 下一毫秒将使用sequence:0
			for now <= s.timestamp {
				now = time.Now().UnixNano() / 1e6
			}
		}
	} else {
		// 不同时间戳（精度：毫秒）下直接使用序列号：0
		s.sequence = 0
	}
	t := now - epoch
	if t > timestampMax {
		// fmt.Errorf("epoch must be between 0 and %d", timestampMax-1)
		return 0
	}
	s.timestamp = now
	r := (t)<<timestampShift | (s.centerId << centerIdShift) | (s.workerId << workerIdShift) | (s.sequence)
	return r
}

func (s *Snowflake) GenIDString() string {
	return strconv.FormatInt(s.GenID(), 10)
}

// 获取数据中心ID和机器ID
func GetDeviceID(sid int64) (centerID, workerID int64) {
	centerID = (sid >> centerIdShift) & centerIdMax
	workerID = (sid >> workerIdShift) & workerIdMax
	return
}

// 获取创建ID时的时间戳(毫秒)
func GetTimestamp(sid int64) (timestamp int64) {
	timestamp = ((sid >> timestampShift) & timestampMax) + epoch
	return
}

// 获取创建ID时的时间字符串(精度：秒)
func GetDateTime(sid int64) (t string) {
	t = time.UnixMilli(GetTimestamp(sid)).Format("2006-01-02 15:04:05")
	return
}

// 获取时间戳已使用的占比：范围（0.0 - 1.0）
func GetTimeStatus() (status float64) {
	status = float64(time.Now().UnixMilli()-epoch) / float64(timestampMax)
	return
}

func SonySnowFlake(machineID uint16) uint64 {
	startTime := "2025-01-01" // 初始化一个开始的时间，表示从这个时间开始算起
	st, err := time.ParseInLocation("2006-01-02", startTime, time.Local)
	if err != nil {
		panic(err)
	}
	settings := sonyflake.Settings{
		StartTime: st,
		MachineID: func() (uint16, error) { return machineID, nil },
	}
	sonyFlake := sonyflake.NewSonyflake(settings)
	if sonyFlake == nil {
		panic("sonyflake not created")
	}

	id, err := sonyFlake.NextID()
	if err != nil {
		panic(err)
	}
	return id
}
