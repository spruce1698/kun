package utils

import (
	"strings"
	"testing"
)

func TestUnicode2Emoji(t *testing.T) {
	testCases := []struct {
		input    string
		expected string
	}{
		{"[\\u1F602]", "😂"},
		{"[\\u1F60A]", "😊"},
		{"[\\u1F60E]456", "😎456"},
		{"No emoji", "No emoji"},
	}

	for _, tc := range testCases {
		res := Unicode2Emoji(tc.input)

		// 转大写
		res = strings.ToUpper(res)
		expected := strings.ToUpper(tc.expected)
		t.Log(res)
		if res != expected {
			t.Errorf("Unexpected result - input: %s, expected: %s, got: %s",
				tc.input,
				expected,
				res,
			)
		}
	}
}

func TestUnicode2Emoji2(t *testing.T) {
	input := "[\\u1F602]"
	expected := "😂"
	result := Unicode2Emoji(input)
	t.Log(result)
	// 转大写
	expected = strings.ToUpper(expected)
	result = strings.ToUpper(result)
	t.Log(expected)
	if result != expected {
		t.Errorf("DecodeEmoji(%s) = %s; expected %s", input, result, expected)
	}
}

func TestEmoji2Unicode(t *testing.T) {
	testCases := []struct {
		input    string
		expected string
	}{
		{"Hello 😂", "Hello [\\u1F602]"},
		{"No emoji", "No emoji"},
	}

	for _, tc := range testCases {
		actual := Emoji2Unicode(tc.input)

		// 转大写
		actual = strings.ToUpper(actual)
		expected := strings.ToUpper(tc.expected)
		t.Log(actual)
		if actual != expected {
			t.Errorf("Unexpected result - input: %s, expected: %s, got: %s",
				tc.input,
				expected,
				actual,
			)
		}
	}
}

func TestEmoji2Unicode2(t *testing.T) {
	input := "😂"
	expected := "[\\u1F602]"
	result := Emoji2Unicode(input)

	// 转大写
	expected = strings.ToUpper(expected)
	result = strings.ToUpper(result)

	if result != expected {
		t.Errorf("EncodeEmoji(%s) = %s; expected %s", input, result, expected)
	}

}

func TestEmoji2Unicode3(t *testing.T) {
	input := "✈"
	result := strings.ToUpper(Emoji2Unicode(input))
	t.Errorf("EncodeEmoji(%s) = %s", input, result)
}
