/**
 * @Author: spruce
 * @Date: 2024-03-28 10:16
 * @Desc: 时间测试
 */

package utils

import (
	"fmt"
	"testing"
	"time"
)

func TestGetUtcTime(t *testing.T) {
	fmt.Println(DayStr(time.Now()))
}
