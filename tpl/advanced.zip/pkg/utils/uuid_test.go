/**
 * @Author: spruce
 * @Date: 2024-03-28 14:20
 * @Desc: uuid 测试
 */

package utils

import "testing"

func TestGenUUid(t *testing.T) {
	tests := []struct {
		name string
		want string
	}{
		{"1", "test"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GenUUid(); got != tt.want {
				t.Errorf("GenUUid() = %v, want %v", got, tt.want)
			}
		})
	}
}
