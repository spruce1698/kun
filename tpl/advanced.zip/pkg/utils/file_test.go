/**
 * @Author: spruce
 * @Date: 2024-03-28 10:19
 * @Desc: 文件操作测试
 */

package utils

import (
	"reflect"
	"testing"
)

func TestBuildDir(t *testing.T) {
	type args struct {
		absDir string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := BuildDir(tt.args.absDir); (err != nil) != tt.wantErr {
				t.Errorf("BuildDir() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestCheckFileIsExist(t *testing.T) {
	type args struct {
		fileName string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := CheckFileIsExist(tt.args.fileName); got != tt.want {
				t.Errorf("CheckFileIsExist() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDeleteFile(t *testing.T) {
	type args struct {
		absDir string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := DeleteFile(tt.args.absDir); (err != nil) != tt.wantErr {
				t.Errorf("DeleteFile() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestGetCurrentDirectory(t *testing.T) {
	tests := []struct {
		name string
		want string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetCurrentDirectory(); got != tt.want {
				t.Errorf("GetCurrentDirectory() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetModelPath(t *testing.T) {
	tests := []struct {
		name string
		want string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetModelPath(); got != tt.want {
				t.Errorf("GetModelPath() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetPathDirs(t *testing.T) {
	type args struct {
		absDir string
	}
	tests := []struct {
		name   string
		args   args
		wantRe []string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotRe := GetPathDirs(tt.args.absDir); !reflect.DeepEqual(gotRe, tt.wantRe) {
				t.Errorf("GetPathDirs() = %v, want %v", gotRe, tt.wantRe)
			}
		})
	}
}

func TestGetPathFiles(t *testing.T) {
	type args struct {
		absDir string
	}
	tests := []struct {
		name   string
		args   args
		wantRe []string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotRe := GetPathFiles(tt.args.absDir); !reflect.DeepEqual(gotRe, tt.wantRe) {
				t.Errorf("GetPathFiles() = %v, want %v", gotRe, tt.wantRe)
			}
		})
	}
}

func TestReadFile(t *testing.T) {
	type args struct {
		fileName string
	}
	tests := []struct {
		name    string
		args    args
		wantSrc []string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotSrc := ReadFile(tt.args.fileName); !reflect.DeepEqual(gotSrc, tt.wantSrc) {
				t.Errorf("ReadFile() = %v, want %v", gotSrc, tt.wantSrc)
			}
		})
	}
}

func TestSaveToFile(t *testing.T) {
	type args struct {
		fileName string
		src      []string
		isClear  bool
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := SaveToFile(tt.args.fileName, tt.args.src, tt.args.isClear); got != tt.want {
				t.Errorf("SaveToFile() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestWriteFile(t *testing.T) {
	type args struct {
		fileName string
		src      []string
		isClear  bool
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := WriteFile(tt.args.fileName, tt.args.src, tt.args.isClear); got != tt.want {
				t.Errorf("WriteFile() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestBuildDir1(t *testing.T) {
	type args struct {
		absDir string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := BuildDir(tt.args.absDir); (err != nil) != tt.wantErr {
				t.Errorf("BuildDir() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestCheckFileIsExist1(t *testing.T) {
	type args struct {
		fileName string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := CheckFileIsExist(tt.args.fileName); got != tt.want {
				t.Errorf("CheckFileIsExist() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDeleteFile1(t *testing.T) {
	type args struct {
		absDir string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := DeleteFile(tt.args.absDir); (err != nil) != tt.wantErr {
				t.Errorf("DeleteFile() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestGetCurrentDirectory1(t *testing.T) {
	tests := []struct {
		name string
		want string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetCurrentDirectory(); got != tt.want {
				t.Errorf("GetCurrentDirectory() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetModelPath1(t *testing.T) {
	tests := []struct {
		name string
		want string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetModelPath(); got != tt.want {
				t.Errorf("GetModelPath() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetPathDirs1(t *testing.T) {
	type args struct {
		absDir string
	}
	tests := []struct {
		name   string
		args   args
		wantRe []string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotRe := GetPathDirs(tt.args.absDir); !reflect.DeepEqual(gotRe, tt.wantRe) {
				t.Errorf("GetPathDirs() = %v, want %v", gotRe, tt.wantRe)
			}
		})
	}
}

func TestGetPathFiles1(t *testing.T) {
	type args struct {
		absDir string
	}
	tests := []struct {
		name   string
		args   args
		wantRe []string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotRe := GetPathFiles(tt.args.absDir); !reflect.DeepEqual(gotRe, tt.wantRe) {
				t.Errorf("GetPathFiles() = %v, want %v", gotRe, tt.wantRe)
			}
		})
	}
}

func TestReadFile1(t *testing.T) {
	type args struct {
		fileName string
	}
	tests := []struct {
		name    string
		args    args
		wantSrc []string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotSrc := ReadFile(tt.args.fileName); !reflect.DeepEqual(gotSrc, tt.wantSrc) {
				t.Errorf("ReadFile() = %v, want %v", gotSrc, tt.wantSrc)
			}
		})
	}
}

func TestSaveToFile1(t *testing.T) {
	type args struct {
		fileName string
		src      []string
		isClear  bool
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := SaveToFile(tt.args.fileName, tt.args.src, tt.args.isClear); got != tt.want {
				t.Errorf("SaveToFile() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestWriteFile1(t *testing.T) {
	type args struct {
		fileName string
		src      []string
		isClear  bool
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := WriteFile(tt.args.fileName, tt.args.src, tt.args.isClear); got != tt.want {
				t.Errorf("WriteFile() = %v, want %v", got, tt.want)
			}
		})
	}
}
