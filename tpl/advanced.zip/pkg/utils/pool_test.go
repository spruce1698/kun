/**
 * @Author: spruce
 * @Date: 2024-03-28 15:34
 * @Desc: 协程池 测试
 */

package utils

import (
	"fmt"
	"testing"
)

func TestNewPool(t *testing.T) {

	// 创建一个协程池，设置工作协程数为3
	pool := NewPool(3)

	// 添加任务到协程池
	for i := 0; i < 10; i++ {
		taskID := i
		task := Task{
			ID: taskID,
			Job: func() {
				fmt.Printf("Task %d is running\n", taskID)
			},
		}
		pool.AddTask(task)
	}

	// 等待所有任务完成
	pool.Wait()

}
