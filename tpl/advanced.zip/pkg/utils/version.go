/**
 * @Author: spruce
 * @Date: 2024-03-28 15:01
 * @Desc: 版本比较,是否在版本范围,版本排序
 */

package utils

import (
	"sort"

	"github.com/hashicorp/go-version"
)

func Less(target, in string) (bool, error) {
	inVersion, err := version.NewVersion(in)
	if err != nil {
		return false, err
	}
	targetVersion, err := version.NewVersion(target)
	if err != nil {
		return false, err
	}
	return inVersion.LessThan(targetVersion), nil
}

func Greater(target, in string) (bool, error) {
	inVersion, err := version.NewVersion(in)
	if err != nil {
		return false, err
	}
	targetVersion, err := version.NewVersion(target)
	if err != nil {
		return false, err
	}
	return inVersion.GreaterThan(targetVersion), nil
}

func Equal(target, in string) (bool, error) {
	inVersion, err := version.NewVersion(in)
	if err != nil {
		return false, err
	}
	targetVersion, err := version.NewVersion(target)
	if err != nil {
		return false, err
	}
	return inVersion.Equal(targetVersion), nil
}

func InRange(rangeStr, in string) (bool, error) {
	inVersion, err := version.NewVersion(in)
	if err != nil {
		return false, err
	}

	constraints, err := version.NewConstraint(rangeStr)
	if err != nil {
		return false, err
	}
	return constraints.Check(inVersion), nil
}

func Sort(in []string) []string {
	versions := make([]*version.Version, len(in))
	for i, raw := range in {
		v, _ := version.NewVersion(raw)
		versions[i] = v
	}
	sort.Sort(version.Collection(versions))
	result := make([]string, len(versions))
	for i, v := range versions {
		result[i] = v.String()
	}
	return result
}
