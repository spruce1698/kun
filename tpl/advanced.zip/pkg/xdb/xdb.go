/**
 * @Author:
 * @Date: 2024-03-28 17:01
 * @Desc: 数据库操作
 */

package xdb

import (
	"fmt"
	"log"
	"os"
	"sync"
	"time"

	"advanced/pkg/xconfig"
	"advanced/pkg/xlog"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	gormLogger "gorm.io/gorm/logger"
	"gorm.io/plugin/dbresolver"
	"gorm.io/plugin/opentelemetry/tracing"
)

var (
	once     sync.Once
	instance *Client = nil
)

type Client = gorm.DB

func New(conf *xconfig.Conf, logger *xlog.Logger) *Client {
	if instance == nil {
		once.Do(
			func() {
				if len(conf.Mysql.Source) == 0 {
					panic("mysql 配置错误")
				}

				logLevel := gormLogger.Warn
				if conf.Mysql.LogLevel == "debug" {
					logLevel = gormLogger.Info
				}

				newLogger := initLog(
					log.New(os.Stdout, "\n", log.LstdFlags), // io writer
					gormLogger.Config{
						SlowThreshold:             200 * time.Millisecond, // 慢 SQL 阈值
						IgnoreRecordNotFoundError: true,                   // 忽略 ErrRecordNotFound 记录到日志
						LogLevel:                  logLevel,               // Log level  gormlog.Silent
					},
					logger,
				)

				masterConfig := mysql.New(mysql.Config{
					DSN:                       conf.Mysql.Source[0],
					DefaultStringSize:         1024, // string 类型字段的默认长度
					DisableDatetimePrecision:  true, // 禁用 datetime 精度，MySQL 5.6 之前的数据库不支持
					DontSupportRenameIndex:    true, // 重命名索引时采用删除并新建的方式，MySQL 5.7 之前的数据库和 MariaDB 不支持重命名索引
					DontSupportRenameColumn:   true, // 用 `change` 重命名列，MySQL 8 之前的数据库和 MariaDB 不支持重命名列
					SkipInitializeWithVersion: true, // 根据当前 MySQL 版本自动配置
				})

				var err error
				instance, err = gorm.Open(masterConfig, &gorm.Config{
					Logger:                   newLogger,
					QueryFields:              true,
					DisableNestedTransaction: true, // 禁用嵌套事务
				})
				if err != nil {
					logger.Fatal(fmt.Sprintf("初始化主数据库失败, error: %v \n", err.Error()))
					return
				}
				if len(conf.Mysql.Source) > 1 {
					err = instance.Use(dbresolver.Register(dbresolver.Config{
						Replicas: []gorm.Dialector{mysql.Open(conf.Mysql.Source[1])},
						Policy:   dbresolver.RandomPolicy{},
					}))
					if err != nil {
						logger.Fatal(fmt.Sprintf("初始化从数据库失败, error: %v \n", err.Error()))
						return
					}
				}

				// 添加 OpenTelemetry 插件
				if err = instance.Use(tracing.NewPlugin()); err != nil {
					logger.Fatal(fmt.Sprintf("初始化MySql数据库失败, error: %v \n", err.Error()))
					return
				}

				// 设置连接池
				sqlDB, err := instance.DB()
				if err != nil {
					logger.Fatal(fmt.Sprintf("初始化MySql数据库失败, error: %v \n", err.Error()))
					return
				}
				sqlDB.SetMaxIdleConns(10)           // 设置空闲连接池中连接的最大数量
				sqlDB.SetMaxOpenConns(100)          // 设置打开数据库连接的最大数量。
				sqlDB.SetConnMaxLifetime(time.Hour) // 设置了连接可复用的最大时间。
			},
		)
	}
	return instance
}
