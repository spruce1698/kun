/**
 * @Author:
 * @Date: 2024-03-28 15:06
 * @Desc: 数据库日志
 */

package xdb

import (
	"context"
	"fmt"
	"time"

	"advanced/pkg/xlog"

	"gorm.io/gorm/logger"
	"gorm.io/gorm/utils"
)

type xdbLogger struct {
	logger.Writer
	logger.Config
	infoStr, warnStr, errStr, traceStr, traceErrStr, traceWarnStr string
	xLogger                                                       *xlog.Logger
}

func initLog(writer logger.Writer, config logger.Config) logger.Interface {
	var (
		infoStr      = "%s [info] "
		warnStr      = "%s [warn] "
		errStr       = "%s [error] "
		traceStr     = "%s [%.3fms] [rows:%v] %s"
		traceWarnStr = "%s %s [%.3fms] [rows:%v] %s"
		traceErrStr  = "%s %s [%.3fms] [rows:%v] %s"
	)

	return &xdbLogger{
		Writer:       writer,
		Config:       config,
		infoStr:      infoStr,
		warnStr:      warnStr,
		errStr:       errStr,
		traceStr:     traceStr,
		traceWarnStr: traceWarnStr,
		traceErrStr:  traceErrStr,
		xLogger:      xlog.L(),
	}
}

func (l *xdbLogger) LogMode(level logger.LogLevel) logger.Interface {
	newLogger := *l
	newLogger.LogLevel = level
	return &newLogger
}

func (l *xdbLogger) Info(ctx context.Context, msg string, data ...any) {
	if l.LogLevel >= logger.Info {
		l.xLogger.Info(fmt.Sprintf(l.infoStr+msg, append([]any{utils.FileWithLineNum()}, data...)...))
	}
}

func (l *xdbLogger) Warn(ctx context.Context, msg string, data ...any) {
	if l.LogLevel >= logger.Warn {
		l.xLogger.Warn(fmt.Sprintf(l.warnStr+msg, append([]any{utils.FileWithLineNum()}, data...)...))
	}
}

func (l *xdbLogger) Error(ctx context.Context, msg string, data ...any) {
	if l.LogLevel >= logger.Error {
		l.xLogger.Error(fmt.Sprintf(l.errStr+msg, append([]any{utils.FileWithLineNum()}, data...)...))
	}
}

func (l *xdbLogger) Trace(ctx context.Context, begin time.Time, fc func() (string, int64), err error) {

	if l.LogLevel <= logger.Silent {
		return
	}

	elapsed := time.Since(begin)
	switch {
	case err != nil && l.LogLevel >= logger.Error && (err != logger.ErrRecordNotFound || !l.IgnoreRecordNotFoundError):
		sql, rows := fc()
		if rows == -1 {
			l.xLogger.Error(fmt.Sprintf(l.traceErrStr, utils.FileWithLineNum(), err, float64(elapsed.Nanoseconds())/1e6, "-", sql))
		} else {
			l.xLogger.Error(fmt.Sprintf(l.traceErrStr, utils.FileWithLineNum(), err, float64(elapsed.Nanoseconds())/1e6, rows, sql))
		}
	case elapsed > l.SlowThreshold && l.SlowThreshold != 0 && l.LogLevel >= logger.Warn:
		sql, rows := fc()
		slowLog := fmt.Sprintf("SLOW SQL >= %v", l.SlowThreshold)
		if rows == -1 {
			l.xLogger.Warn(fmt.Sprintf(l.traceWarnStr, utils.FileWithLineNum(), slowLog, float64(elapsed.Nanoseconds())/1e6, "-", sql))
		} else {
			l.xLogger.Warn(fmt.Sprintf(l.traceWarnStr, utils.FileWithLineNum(), slowLog, float64(elapsed.Nanoseconds())/1e6, rows, sql))
		}
	case l.LogLevel == logger.Info:
		sql, rows := fc()
		if rows == -1 {
			l.xLogger.Info(fmt.Sprintf(l.traceStr, utils.FileWithLineNum(), float64(elapsed.Nanoseconds())/1e6, "-", sql))
		} else {
			l.xLogger.Info(fmt.Sprintf(l.traceStr, utils.FileWithLineNum(), float64(elapsed.Nanoseconds())/1e6, rows, sql))
		}
	}

}
