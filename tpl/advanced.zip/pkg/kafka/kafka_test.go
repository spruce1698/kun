/**
* @Author: spruce
 * @Date: 2024-03-28 10:40
 * @Desc: kafka 测试
*/

package kafka

import (
	"crypto/hmac"
	"crypto/md5"
	"crypto/sha1"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"sort"
	"strings"
	"sync"
	"testing"
	"time"

	"advanced/pkg/xconfig"

	"github.com/go-resty/resty/v2"
)

type User struct {
	Name string
}

var cnf = &xconfig.Cnf{
	Kafka: struct {
		Brokers []string
	}{
		Brokers: []string{"127.0.0.1:9092"},
	},
}

func aa(key, value string) error {
	var user User
	err := json.Unmarshal([]byte(value), &user)
	if err != nil {
		fmt.Printf("json unmarshal err: %v \n", err)
	}
	fmt.Printf("message at  %s = %s time=%d \n", key, value, time.Now().UnixNano())
	return nil
}

func ab(key, value string) error {
	var user User
	err := json.Unmarshal([]byte(value), &user)
	if err != nil {
		fmt.Printf("json unmarshal err: %v \n", err)
	}
	fmt.Printf("ab message at  %s = %s time=%d \n", key, value, time.Now().UnixNano())
	if strings.Contains(key, "KEY:") {
		return errors.New("哈哈有key ")
	}
	return nil
}

func ac(key, value string) error {
	var user User
	err := json.Unmarshal([]byte(value), &user)
	if err != nil {
		fmt.Printf("json unmarshal err: %v \n", err)
	}
	fmt.Printf("ac message at  %s = %s time=%d \n", key, value, time.Now().UnixNano())
	if strings.Contains(key, "KEY:") {
		return errors.New("哈哈有key ")
	}
	return nil
}

func TestKafka_CreateTopic(t *testing.T) {
	topic := "topic-a"
	err := NewClient(cnf).CreateTopic(topic, 1)
	t.Log(err)
}
func TestKafka_TopicList(t *testing.T) {
	list, err := NewClient(cnf).TopicList()
	fmt.Println(err)
	fmt.Println(list)
}
func TestKafka_DelTopic(t *testing.T) {
	_ = NewClient(cnf).DelTopic("topic-a")
}

func TestKafka_Pub(t *testing.T) {
	p := NewPublisher(cnf)

	for i := 0; i < 10; i++ {
		user := &User{
			"A:" + time.Now().Format(time.RFC3339),
		}
		str, _ := json.Marshal(user)
		err := p.Pub("topic-a", str)
		if err != nil {
			t.Log(err)
		}
	}

}

func TestKafka_PubWithKey(t *testing.T) {

	p := NewPublisher(cnf)
	for i := 0; i < 10; i++ {

		user := &User{
			"B:" + time.Now().Format(time.RFC3339),
		}
		str, _ := json.Marshal(user)

		err := p.PubWithKey("topic-a", fmt.Sprintf("KEY:%d", time.Now().UnixNano()), str)
		if err != nil {
			t.Log(err)
		}
	}
}

func TestKafka_PushList(t *testing.T) {

	p := NewPublisher(cnf)
	msgList := make([]Msg, 0, 10)
	for i := 0; i < 10; i++ {

		user := &User{
			"B:" + time.Now().Format(time.RFC3339),
		}
		str, _ := json.Marshal(user)
		topic := "topic-a1"
		if i%2 == 0 {
			topic = "topic-a"
		}
		msgList = append(msgList, Msg{
			Topic: topic,
			Key:   fmt.Sprintf("KEY:%d", i),
			Value: str,
		})
	}
	err := p.PubList(msgList...)
	if err != nil {
		t.Log(err)
	}
}

func TestKafka_Sub(t *testing.T) {
	NewSubscriber(cnf).Sub("topic-a", "oneaaa", aa)
}

func TestKafka_SubFetch(t *testing.T) {
	NewSubscriber(cnf).SubFetch("topic-a", "fetch", ab)
}

func TestKafka_SubFetchAC(t *testing.T) {
	NewSubscriber(cnf).SubFetch("topic-a", "fetch_ac", ac)
}

func BenchmarkKafkaGoAsyncInParallel(b *testing.B) {
	b.ReportAllocs()
	b.ResetTimer()

	client := resty.New()
	client.SetBaseURL("http://127.0.0.1:10080/")
	client.SetRetryCount(3)

	path := "/prepay-web/v1/prepay/member/balance/fetchPaymentCode?memberId=305a4169771c48ff8622c9d1ab0f220f"
	client.SetHeaders(map[string]string{
		"Authorization": authorization("GET", path, "", ""),
		"User-Agent":    "swjld.com",
	})

	client.SetHeaders(map[string]string{
		"Authorization": authorization("GET", path, "", ""),
		"User-Agent":    "1.com",
	})
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {

			// r, err := http.NewRequest("GET", "http://127.0.0.1:10080/prepay-web/v1/prepay/member/balance/fetchPaymentCode?memberId=305a4169771c48ff8622c9d1ab0f220f", strings.NewReader(""))
			// if err != nil {
			// 	return
			// }
			// r.Header.Add("Authorization", authorization("GET", path, "", ""))
			//
			// response, err := (&http.Client{}).Do(r)
			// if err != nil {
			// 	return
			// }
			// defer response.Body.Close()
			// resultBody, err := ioutil.ReadAll(response.Body)
			// if err != nil {
			// 	return
			// }
			// fmt.Println(string(resultBody))
			// Create a Resty Client

			response, _ := client.R().Get(path)
			fmt.Println(response.Request)
			if response.Body() != nil {
				fmt.Println(string(response.Body()))
			}
		}
	})
}

func BenchmarkTestKafka(b *testing.B) {
	client := resty.New()
	path := "/prepay-web/v1/prepay/member/balance/fetchPaymentCode?memberId=305a4169771c48ff8622c9d1ab0f220f"
	client.SetHeaders(map[string]string{
		"Authorization": authorization("GET", path, "", ""),
		"User-Agent":    "swjld.com",
	})
	client.SetBaseURL("http://127.0.0.1:10080/")
	client.SetRetryCount(3)
	for n := 0; n < 500; n++ {
		response, _ := client.R().Get(path)
		fmt.Println(response.Request.URL)
		if response.Body() != nil {
			fmt.Println(string(response.Body()))
		}
	}
}

func authorization(method, path, contentType, data string) (authorization string) {
	bodyMd5Base64 := ""
	if data != "" && method == "POST" {
		md5String := md5.Sum([]byte(data))
		bodyMD5 := strings.ToUpper(fmt.Sprintf("%x", md5String))
		bodyMd5Base64 = base64.StdEncoding.EncodeToString([]byte(bodyMD5))
	}
	u, _ := url.Parse(path)
	var query map[string][]string = u.Query()
	if len(query) > 1 {
		qm := make(QueryMap, len(query)+1)
		for k, v := range query {
			if len(v) == 1 {
				qm.Set(k, v[0])
			}
		}
		path = strings.ReplaceAll(path, u.RawQuery, "") + qm.SortParams()
	}
	ciphertext := method + "\n" + bodyMd5Base64 + "\n" + contentType + "\n\n" + path
	hmacObj := hmac.New(sha1.New, []byte("CIIDBJMNTX"))
	hmacObj.Write([]byte(ciphertext))
	signatureBase64 := base64.StdEncoding.EncodeToString(hmacObj.Sum([]byte("")))
	authorization = "Sign 2jx9n326:" + signatureBase64
	return
}

type QueryMap map[string]interface{}

var mu = new(sync.RWMutex)

// 设置参数
func (qm QueryMap) Set(key string, value interface{}) QueryMap {
	mu.Lock()
	qm[key] = value
	mu.Unlock()
	return qm
}

// 获取参数转换string
func (qm QueryMap) GetString(key string) string {
	if qm == nil {
		return ""
	}
	mu.RLock()
	defer mu.RUnlock()
	value, ok := qm[key]
	if !ok {
		return ""
	}
	v, ok := value.(string)
	if !ok {
		return convertToString(value)
	}
	return v
}

// ("bar=baz&foo=quux") sorted by key.
func (qm QueryMap) SortParams() string {
	var (
		buf     strings.Builder
		keyList []string
	)
	mu.RLock()
	for k := range qm {
		keyList = append(keyList, k)
	}
	sort.Strings(keyList)
	mu.RUnlock()
	for _, k := range keyList {
		if v := qm.GetString(k); v != "" {
			buf.WriteString(k)
			buf.WriteByte('=')
			buf.WriteString(v)
			buf.WriteByte('&')
		}
	}
	if buf.Len() <= 0 {
		return ""
	}
	return buf.String()[:buf.Len()-1]
}

func convertToString(v interface{}) (str string) {
	if v == nil {
		return ""
	}
	var (
		bs  []byte
		err error
	)
	if bs, err = json.Marshal(v); err != nil {
		return ""
	}
	str = string(bs)
	return
}
