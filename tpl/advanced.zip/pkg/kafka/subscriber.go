package kafka

import (
	"context"
	"errors"
	"fmt"
	"io"
	"sync"
	"time"

	"advanced/pkg/xconfig"

	kafkaGo "github.com/segmentio/kafka-go"
)

const (
	topicGroupKey = "%s:%s"
)

type (
	Subscriber struct {
		brokers []string
		box     sync.Map
	}
)

func NewSubscriber(cnf *xconfig.Cnf) *Subscriber {
	if len(cnf.Kafka.Brokers) == 0 {
		panic("无可用的节点信息")
	}
	return &Subscriber{
		brokers: cnf.Kafka.Brokers,
		box:     sync.Map{},
	}
}

// 订阅者 kafka提交
func (s *Subscriber) Sub(topic, group string, handler func(key, value string) error) {
	key := fmt.Sprintf(topicGroupKey, topic, group)
	sub, ok := s.box.Load(key)
	if !ok {
		sub = kafkaGo.NewReader(kafkaGo.ReaderConfig{
			StartOffset: kafkaGo.FirstOffset,
			Brokers:     s.brokers,
			GroupID:     group,
			Topic:       topic,
			MinBytes:    10e3, // 10KB fetch.min.bytes 服务器应该为获取请求返回的最小数据量。如果没有足够的数据可用，请求将等待那么多数据累积后再响应请求
			MaxBytes:    10e6, // 10MB
			// CommitInterval: time.Second,           // 提交间隔指示将偏移提交到代理的间隔。如果为 0，则同步处理提交。 要加 GroupID 才能自动提交
			MaxWait: time.Millisecond, // fetch.max.wait.ms 默认10s如果没有足够的数据立即满足fetch.min.bytes提供的要求，服务器在响应fetch请求之前将阻塞的最长时间
		})
	}
	ctx := context.Background()
	for {
		msg, err := sub.(*kafkaGo.Reader).ReadMessage(ctx)
		if err != nil {
			fmt.Printf("--sub-: %v\n", err)
			break
		}
		if subErr := handler(string(msg.Key), string(msg.Value)); subErr != nil {
			fmt.Printf("sub error: %v \n", subErr)
			continue
		}
	}
	// defer sub.Close()
}

// 订阅者 程序提交(速度快)
func (s *Subscriber) SubFetch(topic, group string, handler func(key, value string) error) {
	key := fmt.Sprintf(topicGroupKey, topic, group)
	sub, ok := s.box.Load(key)
	if !ok {
		sub = kafkaGo.NewReader(kafkaGo.ReaderConfig{
			StartOffset: kafkaGo.FirstOffset,
			Brokers:     s.brokers,
			GroupID:     group,
			Topic:       topic,
			MinBytes:    10e3, // 10KB fetch.min.bytes 服务器应该为获取请求返回的最小数据量。如果没有足够的数据可用，请求将等待那么多数据累积后再响应请求
			MaxBytes:    10e6, // 10MB
			// CommitInterval: time.Second,           // 提交间隔指示将偏移提交到代理的间隔。如果为 0，则同步处理提交。 要加 GroupID 才能自动提交
			MaxWait: 10 * time.Millisecond, // fetch.max.wait.ms 默认10s如果没有足够的数据立即满足fetch.min.bytes提供的要求，服务器在响应fetch请求之前将阻塞的最长时间
		})
	}
	ctx := context.Background()
	for {
		msg, err := sub.(*kafkaGo.Reader).FetchMessage(ctx)
		// io.EOF means sub closed
		// io.ErrClosedPipe means committing messages on the sub,
		// kafka will refire the messages on uncommitted messages, ignore
		if errors.Is(err, io.EOF) || errors.Is(err, io.ErrClosedPipe) {
			break
		}
		if err != nil {
			fmt.Printf("--SubFetch--: %v \n", err)
			break
		}

		if consumeErr := handler(string(msg.Key), string(msg.Value)); consumeErr != nil {
			fmt.Printf("sub error: %v \n", consumeErr)
			continue
		}
		if commitErr := sub.(*kafkaGo.Reader).CommitMessages(ctx, msg); commitErr != nil {
			fmt.Printf("commit failed, error: %v \n", err)
		}
	}
	// defer sub.Close()
}

func (s *Subscriber) Close() {
	s.box.Range(func(_, value any) bool {
		go func() {
			_ = value.(*kafkaGo.Reader).Close()
		}()
		return true
	})
}
