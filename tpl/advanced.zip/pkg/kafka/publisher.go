package kafka

import (
	"context"
	"strconv"
	"time"

	"advanced/pkg/xconfig"

	"github.com/pkg/errors"
	kafkaGo "github.com/segmentio/kafka-go"
)

type (
	Publisher struct {
		brokers []string
	}
	Msg struct {
		Topic string
		Key   string
		Value []byte
	}
)

func NewPublisher(conf *xconfig.Conf) *Publisher {
	if len(conf.Kafka.Brokers) == 0 {
		panic("无可用的节点信息")
	}
	return &Publisher{
		brokers: conf.Kafka.Brokers,
	}
}

func (p *Publisher) Pub(topic string, value []byte) error {
	pub := &kafkaGo.Writer{
		Addr:         kafkaGo.TCP(p.brokers...),
		Topic:        topic,
		Balancer:     &kafkaGo.LeastBytes{},
		Compression:  kafkaGo.Snappy,        // 启用压缩
		BatchTimeout: 50 * time.Millisecond, // linger.ms 如果消息的大小一直达不到batch.size设置的值，那么等待多久后任然允许发送消息
		// BatchSize		batch.size	当多条消息被发送到同一个分区时，生产者会尝试把多条消息变成批量发送。这有助于提高客户端和服务器的性能。值设置的太小，可能会降低吞吐量 参数设置的太大，可能会更浪费内存，并增加消息发送的延迟时间
		// 配置为消息体积，而非条数，单位为字节
		Async: true, // 异步
	}
	msg := kafkaGo.Message{
		Key:   []byte(strconv.FormatInt(time.Now().UnixNano(), 10)),
		Value: value,
	}
	defer func(p *kafkaGo.Writer) {
		_ = p.Close()
	}(pub)
	return pub.WriteMessages(context.Background(), msg)
}

func (p *Publisher) PubWithKey(topic, key string, value []byte) error {
	pub := &kafkaGo.Writer{
		Addr:         kafkaGo.TCP(p.brokers...),
		Topic:        topic,
		Balancer:     &kafkaGo.LeastBytes{},
		Compression:  kafkaGo.Snappy,        // 启用压缩
		BatchTimeout: 50 * time.Millisecond, // linger.ms 如果消息的大小一直达不到batch.size设置的值，那么等待多久后任然允许发送消息
		// BatchSize		batch.size	当多条消息被发送到同一个分区时，生产者会尝试把多条消息变成批量发送。这有助于提高客户端和服务器的性能。值设置的太小，可能会降低吞吐量 参数设置的太大，可能会更浪费内存，并增加消息发送的延迟时间
		// 配置为消息体积，而非条数，单位为字节
		Async: true, // 异步
	}
	msg := kafkaGo.Message{
		Key:   []byte(key),
		Value: value,
	}
	defer func(p *kafkaGo.Writer) {
		_ = p.Close()
	}(pub)
	return pub.WriteMessages(context.Background(), msg)
}

func (p *Publisher) PubList(msgSet ...Msg) error {
	if len(msgSet) == 0 {
		return errors.New("Msg 不能为空")
	}
	pub := &kafkaGo.Writer{
		Addr:         kafkaGo.TCP(p.brokers...),
		Balancer:     &kafkaGo.LeastBytes{},
		Compression:  kafkaGo.Snappy,        // 启用压缩
		BatchTimeout: 50 * time.Millisecond, // linger.ms 如果消息的大小一直达不到batch.size设置的值，那么等待多久后任然允许发送消息
		// BatchSize		batch.size	当多条消息被发送到同一个分区时，生产者会尝试把多条消息变成批量发送。这有助于提高客户端和服务器的性能。值设置的太小，可能会降低吞吐量 参数设置的太大，可能会更浪费内存，并增加消息发送的延迟时间
		// 配置为消息体积，而非条数，单位为字节
		Async: true, // 异步
	}
	msgList := make([]kafkaGo.Message, len(msgSet))
	for i, msg := range msgSet {
		msgList[i] = kafkaGo.Message{
			Topic: msg.Topic,
			Key:   []byte(msg.Key),
			Value: msg.Value,
		}
	}
	defer func(p *kafkaGo.Writer) {
		_ = p.Close()
	}(pub)
	return pub.WriteMessages(context.Background(), msgList...)
}
