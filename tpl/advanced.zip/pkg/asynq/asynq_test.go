/**
* @Author: spruce
 * @Date: 2024-03-28 11:55
 * @Desc: asynq 测试
*/

package asynq

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"
	"time"

	"advanced/pkg/xconfig"

	"github.com/hibiken/asynq"
)

type (
	MsgType  string
	MsgTopic string
	MsgGroup string
)

// 消息类型
const (
	// 支付充值
	MsgTypePayRecharge MsgType = "pay_recharge"
)

// 消息Topic
const (
	// 支付消息topic
	MsgTopicPay MsgTopic = "topic_pay"
)

// 消息group
const (
	// 支付消息topic
	MsgGroupPay  MsgGroup = "group_pay"
	MsgGroupPay1 MsgGroup = "group_pay1"
)

var taskName = "email:welcome"

type MessagePayload struct {
	Type    string
	Content string
}

var cnf = &xconfig.Cnf{
	Redis: struct {
		Source   []string
		Password string
		Cluster  bool
	}{
		Source:   []string{"127.0.0.1:6379"},
		Password: "1cVeQ26GhlUSsRmx",
		Cluster:  false,
	},
}

func TestAsynq_SyncPub(t *testing.T) {
	msg := &MessagePayload{
		"SyncPush",
		"异步消息,消息时间:" + time.Now().Format(time.RFC3339),
	}
	payload, _ := json.Marshal(msg)

	_, err := New(cnf).SyncPub(DefaultQueue, taskName, string(payload))
	t.Log(err)
}

func TestAsynq_DelayPub(t *testing.T) {
	msg := &MessagePayload{
		"DelayPush",
		"我是2s后发送的的消息,发送时间:" + time.Now().Format(time.RFC3339),
	}
	payload, _ := json.Marshal(msg)

	_, err := New(cnf).DelayPub(DefaultQueue, taskName, string(payload), 2*time.Second)
	t.Log(err)

}

func TestAsynq_SetCronPub(t *testing.T) {
	msg := &MessagePayload{
		"DelayPush",
		"我是定时任务3s,发送时间:" + time.Now().Format(time.RFC3339),
	}
	payload, _ := json.Marshal(msg)

	err := New(cnf).SetCronPub(string(MsgTopicPay), string(payload), "@every 3s")
	t.Log(err)

}
func TestAsynq_DelCronPub(t *testing.T) {
	err := New(cnf).SetCronPub(string(MsgTopicPay), "", "@every 2s")
	t.Log(err)
}

func TestAsynq_CronStaticPub(t *testing.T) {
	msg := &MessagePayload{
		"CronPush",
		"每2s执行一次,消息时间:" + time.Now().Format(time.RFC3339),
	}
	payload, _ := json.Marshal(msg)

	_, err := New(cnf).CronStaticPub(DefaultQueue, taskName, string(payload), "@every 2s")
	t.Log(err)
}

func TestAsynq_CronPub(t *testing.T) {
	// msg := &MessagePayload{
	// 	"CronPush",
	// 	"每2s执行一次,消息时间:" + time.Now().Format(time.RFC3339),
	// }
	// payload, _ := json.Marshal(msg)
	//
	// provider := ProviderConfig{
	// 	CronSpec: "@every 2s",
	// 	TaskName: taskName,
	// 	Payload:  string(payload),
	// }
	// providerString, _ := json.Marshal(provider)
	// fmt.Println(string(providerString))

	err := New(cnf).CronPub()
	t.Log(err)
}

func TestRead(t *testing.T) {
	srv := New(cnf).Server()

	mux := asynq.NewServeMux()
	mux.HandleFunc("topic_pay", Read)

	if err := srv.Run(mux); err != nil {
		t.Fatal(err)
	}

	// Stop worker server.
	srv.Stop()

}

func Read(ctx context.Context, t *asynq.Task) error {
	// var p MessagePayload
	// if err := json.Unmarshal(t.Payload(), &p); err != nil {
	//     return err
	// }
	fmt.Printf(" [*] 时间=%s Type=%s  Content=%s \n", time.Now().Format(time.RFC3339), t.Type(), t.Payload())
	return nil
}
