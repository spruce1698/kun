/**
 * @Author:
 * @Date: 2024-03-28 15:10
 * @Desc: error 错误
 */

package xerror

import (
	"context"
	"crypto/md5"
	"encoding/binary"
	"fmt"
	"strings"

	"advanced/pkg/xlog"
)

type (
	Error interface {
		error
		Code() int
		Error() string
		Log()
	}

	defaultError struct {
		code    int
		message string
		err     error
	}
)

func NewError(ctx context.Context, code int, message string, err error) error {
	e := &defaultError{
		code:    code,
		message: message,
		err:     err,
	}
	if e.err != nil {
		e.message = fmt.Sprintf("%s!错误代码:%4s", e.message, errCode(e.err))
		e.Log(ctx)
	}
	return e
}

func (e *defaultError) Code() int {
	return e.code
}

func (e *defaultError) Error() string {
	return e.message
}

func (e *defaultError) Log(ctx context.Context) {
	if e.err != nil {
		xlog.Errorf(ctx, "错误代码:%4s %v", errCode(e.err), e.err)
	}
}

func errCode(err error) string {
	h := md5.Sum([]byte(err.Error()))
	u := binary.BigEndian.Uint32(h[0:16])
	u64 := uint64(u & 0xFFFFF)
	s := fmt.Sprintf("%4s", base36Encode(u64))
	r := strings.NewReplacer(
		" ", "0",
		"O", "0",
		"I", "1",
	).Replace(s)
	return r
}
