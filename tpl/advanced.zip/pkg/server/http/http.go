/**
 * @Author: spruce
 * @Date: 2024-04-20 14:59
 * @Desc: http Engine
 */

package http

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"

	"advanced/internal/controller"
	"advanced/internal/middleware"
	"advanced/internal/router"
	"advanced/pkg/server"
	"advanced/pkg/token"
	"advanced/pkg/utils"
	"advanced/pkg/validator"
	"advanced/pkg/xconfig"
	"advanced/pkg/xdb"
	"advanced/pkg/xlog"
	"advanced/pkg/xredis"

	"github.com/gin-contrib/pprof"
	"github.com/gin-gonic/gin"
)

type Server struct {
	port         int64
	readTimeout  int64
	writeTimeout int64

	logger *xlog.Logger
	db     *xdb.Client
	redis  *xredis.Client

	engine *gin.Engine
	server *http.Server
}

func New(cnf *xconfig.Cnf, log *xlog.Logger, db *xdb.Client, redis *xredis.Client, jwt *token.Jwt, ctl *controller.CtlSet, rs []router.Routers) (server.Engine, error) {

	eng := gin.New()
	gin.SetMode(cnf.Env)

	if cnf.Env == xconfig.EnvStaging || cnf.Env == xconfig.EnvRelease {
		gin.SetMode(gin.ReleaseMode)
		// 禁止gin的默认输出
		gin.DefaultWriter = io.Discard
	}

	// 性能分析 - 正式环境不要使用！！！
	if cnf.Env == xconfig.EnvDebug {
		pprof.Register(eng)
	}

	// 接管gin框架默认的日志和捕获异常
	if cnf.Env == xconfig.EnvDebug || cnf.Env == xconfig.EnvTest { // 测试或开发环境
		eng.Use(
			middleware.Logger(log),
			middleware.Recovery(true, log),
		)
	} else {
		eng.Use(
			middleware.Logger(log),
			middleware.Recovery(false, log),
		)
	}

	// 跨域
	eng.Use(middleware.CORS())

	// 限制
	// eng.Use(middleware.Limit(10))

	// 缺失路由
	eng.NoRoute(router.NotFoundHandle)

	// 探针路由
	router.Ping(eng)

	// Swagger 路由
	if cnf.Env == xconfig.EnvDebug || cnf.Env == xconfig.EnvTest {
		router.SwaggerRouter(eng)
	}

	// 业务路由
	for _, r := range rs {
		r(eng, jwt, ctl)
	}

	port := cnf.Http.Port
	if port == 0 {
		port = utils.AvailablePort()
	}
	readTimeout := cnf.Http.ReadTimeout
	if readTimeout == 0 {
		readTimeout = 120 // 2min
	}
	writeTimeout := cnf.Http.WriteTimeout
	if writeTimeout == 0 {
		writeTimeout = 120 // 2min
	}
	return &Server{

		port:         port,
		readTimeout:  readTimeout,
		writeTimeout: writeTimeout,

		logger: log,
		db:     db,
		redis:  redis,

		engine: eng,
	}, nil
}

func (s *Server) Start() error {

	// 验证器翻译
	validator.New("zh")

	// 初始化HTTP/JOB服务
	svr := &http.Server{
		Addr:         fmt.Sprintf(":%d", s.port),
		Handler:      s.engine,
		ReadTimeout:  time.Duration(s.readTimeout) * time.Second,
		WriteTimeout: time.Duration(s.writeTimeout) * time.Second,
	}

	// 启动成功
	s.logger.Warn(fmt.Sprintf("Http server 启动 (Host: 0.0.0.0:%d  Pid:%d) \n", s.port, os.Getpid()))

	go func() {
		if err := svr.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			s.logger.Warn(fmt.Sprintf("Listen: %s\n", err))
			s.Stop()
		}
	}()

	s.server = svr

	return nil
}

func (s *Server) Stop() {
	s.logger.Warn("Http server stopping ...")

	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(5)*time.Second)
	defer cancel()

	// 优雅关闭
	// 关闭 http server
	if s.server != nil {
		if err := s.server.Shutdown(ctx); err != nil {
			s.logger.Warn(fmt.Sprintf("http server shutdown err:%v", err))
		}
		s.logger.Warn("Close http server")
	}
	// 关闭 db
	if s.db != nil {
		sqlDB, _ := s.db.DB()
		if sqlDB != nil {
			if err := sqlDB.Close(); err != nil {
				s.logger.Warn(fmt.Sprintf("db shutdown err:%v", err))
			}
		}
		s.logger.Warn("Close Db")
	}

	// 关闭 redis
	if s.redis != nil {
		if err := s.redis.Close(); err != nil {
			s.logger.Warn(fmt.Sprintf("redis shutdown err:%v", err))
		}
		s.logger.Warn("Close redis")
	}

	// TODO 其他关闭
	s.logger.Warn("Http server stopped")
}
