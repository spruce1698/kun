/**
 * @Author:
 * @Date: 2024-03-28 13:45
 * @Desc: redis
 */

package xredis

import (
	"context"
	"fmt"
	"sync"
	"time"

	"advanced/pkg/xconfig"
	"advanced/pkg/xlog"

	"github.com/redis/go-redis/extra/redisotel/v9"
	"github.com/redis/go-redis/v9"
)

var (
	once     sync.Once
	instance *Client = nil
)

const Nil = redis.Nil

type Client struct {
	redis.UniversalClient
}

func New(conf *xconfig.Conf, logger *xlog.Logger) *Client {
	if instance == nil {
		once.Do(func() {

			if len(conf.Redis.Source) == 0 {
				panic("redis 配置错误")
			}

			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			var client redis.UniversalClient
			if conf.Redis.Cluster {
				client = redis.NewClusterClient(&redis.ClusterOptions{
					Addrs:    conf.Redis.Source,
					Password: conf.Redis.Password,
					PoolSize: 100,
				})
			} else {
				client = redis.NewClient(&redis.Options{
					Addr:     conf.Redis.Source[0],
					Password: conf.Redis.Password, // no password set
					PoolSize: 100,                 // 连接池大小
				})
			}

			// 使用官方的 OpenTelemetry 插件
			if err := redisotel.InstrumentTracing(client); err != nil {
				logger.Fatal(fmt.Sprintf("ping redis[%v]失败, error: %v \n", conf.Redis.Source[0], err.Error()))
				return
			}

			instance = &Client{client}

			_, err := instance.Ping(ctx).Result()
			if err != nil {
				logger.Fatal(fmt.Sprintf("ping redis[%v]失败, error: %v \n", conf.Redis.Source[0], err.Error()))
				return
			}
		})
	}
	return instance
}
