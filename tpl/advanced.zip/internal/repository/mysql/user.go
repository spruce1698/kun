package mysql

import "context"

//go:generate mockgen -source=./user.go -destination=../../../test/mocks/repository/mysql/user.go  -package mock_repo_mysql -aux_files mysql=./user_gen.go

var _ UserRepo = (*customUser)(nil)

type (
	UserRepo interface {
		userRepo
		ListWithMore(ctx context.Context, args *UserSearch) ([]*User, bool, error)
	}
	UserSearch struct {
		Id       *int64 `json:"id"`       // id
		Username string `json:"username"` // 用户名
		SearchPage
	}

	customUser struct {
		*defaultUser
	}
)

func NewUserRepo(c *Conn) UserRepo {
	return &customUser{
		defaultUser: newUserRepo(c),
	}
}

func (c *customUser) ListWithMore(ctx context.Context, args *UserSearch) ([]*User, bool, error) {
	model := c.WithContext(ctx).Model(c.repo)
	if args.Username != "" {
		model = model.Where(" username LIKE ? ", "%"+args.Username+"%")
	}
	if args.Id != nil {
		model = model.Where(" id = ? ", args.Id)
	}

	var result []*User
	model = model.Order(
		c.HandleRank(
			args.OrderField,
			args.OrderType,
			"`"+c.repo.TableName()+"`.`id`",
		),
	)
	offset, limit := c.HandlePage(args.Page, args.PageSize)
	// 在请求的数据基础上+1，以此来判断是否还有数据
	limit = limit + 1
	err := model.Offset(offset).Limit(limit).Find(&result).Error

	ln := len(result)
	var hasMore bool
	if ln == limit {
		result = result[:ln-1]
		hasMore = true
	}
	return result, hasMore, err
}
