package mysql

import "context"

//go:generate mockgen -source=./demo.go -destination=../../../test/mocks/repository/mysql/demo.go  -package mock_repo_mysql -aux_files mysql=./demo_gen.go

var _ DemoRepo = (*customDemoRepo)(nil)

type (
	DemoRepo interface {
		demoRepo
		FindByName(ctx context.Context, name string) (*Demo, error)
		ListWithTotal(ctx context.Context, args *DemoSearch) ([]*Demo, int64, error)
		ListWithMore(ctx context.Context, args *DemoSearch) ([]*Demo, bool, error)
	}
	DemoSearch struct {
		Id   *int64 `json:"id"`   // id
		Name string `json:"name"` // 名称
		SearchPage
	}
	customDemoRepo struct {
		*defaultDemoRepo
	}
)

func NewDemoRepo(c *Conn) DemoRepo {
	return &customDemoRepo{
		defaultDemoRepo: newDemoRepo(c),
	}
}

func (r *customDemoRepo) FindByName(ctx context.Context, name string) (*Demo, error) {
	result := &Demo{}
	err := r.WithContext(ctx).Where(" name = ? ", name).First(result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (r *customDemoRepo) ListWithTotal(ctx context.Context, args *DemoSearch) ([]*Demo, int64, error) {
	model := r.WithContext(ctx).Model(r.model)
	if args.Name != "" {
		model = model.Where(" name LIKE ? ", "%"+args.Name+"%")
	}
	if args.Id != nil {
		model = model.Where(" id = ? ", args.Id)
	}
	var total int64
	err := model.WithContext(ctx).Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	if total == 0 {
		return nil, 0, ErrNotFound
	}

	var result []*Demo
	model = model.Order(
		r.HandleRank(
			args.OrderField,
			args.OrderType,
			"`"+r.model.TableName()+"`.`id`",
		),
	)
	offset, limit := r.HandlePage(args.Page, args.PageSize)
	err = model.Offset(offset).Limit(limit).Find(&result).Error

	return result, total, err
}

func (r *customDemoRepo) ListWithMore(ctx context.Context, args *DemoSearch) ([]*Demo, bool, error) {
	model := r.WithContext(ctx).Model(r.model)
	if args.Name != "" {
		model = model.Where(" name LIKE ? ", "%"+args.Name+"%")
	}
	if args.Id != nil {
		model = model.Where(" id = ? ", args.Id)
	}

	var result []*Demo
	model = model.Order(
		r.HandleRank(
			args.OrderField,
			args.OrderType,
			"`"+r.model.TableName()+"`.`id`",
		),
	)
	offset, limit := r.HandlePage(args.Page, args.PageSize)
	// 在请求的数据基础上+1，以此来判断是否还有数据
	limit += 1
	err := model.Offset(offset).Limit(limit).Find(&result).Error

	ln := len(result)
	var hasMore bool
	if ln == limit {
		result = result[:ln-1]
		hasMore = true
	}

	return result, hasMore, err
}
