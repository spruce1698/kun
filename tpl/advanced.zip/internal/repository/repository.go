/**
 * @Author: spruce
 * @Date: 2024-04-20 13:57
 * @Desc: 存储层 wire配置
 */

package repository

import (
	"advanced/internal/repository/cache"
	"advanced/internal/repository/db"

	"github.com/google/wire"
)

// ====================== TODO 需要手动配置  存储层 修改后重新wire ======================

// 存储层
var WireSet = wire.NewSet(
	db.NewUserRepo,
	cache.NewUserRepo,
)
