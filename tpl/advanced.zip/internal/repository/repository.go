/**
 * @Author: spruce
 * @Date: 2024-04-20 13:57
 * @Desc: wire InjectSet 自定义
 */

package repository

import (
	"advanced/internal/repository/cache"
	"advanced/internal/repository/db"

	"github.com/google/wire"
)

// 存储层   // TODO 需要手动增加 后执行 wire
var InjectSet = wire.NewSet(
	db.NewUserRepo,
	cache.NewUserRepo,
)
