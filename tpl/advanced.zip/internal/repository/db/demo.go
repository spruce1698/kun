package db

import (
	"context"

	"github.com/pkg/errors"
)

//go:generate mockgen -source=./demo.go -destination=../../../test/mocks/repository/db/demo.go  -package mock_repo_db -aux_files mysql=./demo_gen.go

var _ DemoDb = (*customDemoDb)(nil)

type (
	DemoDb interface {
		demoDb
		FindByName(ctx context.Context, name string) (*Demo, error)
		FindListWithTotal(ctx context.Context, args *DemoSearch) ([]*Demo, int64, error)
		FindListWithMore(ctx context.Context, args *DemoSearch) ([]*Demo, bool, error)
		UpdateTrans(ctx context.Context, id int64, upData *Demo) error
	}
	customDemoDb struct {
		*defaultDemoDb
	}
	DemoSearch struct {
		SearchPage

		Id   *int64 `json:"id"`   // id
		Name string `json:"name"` // 名称
	}
)

func NewDemoDb(c *Conn) DemoDb {
	return &customDemoDb{
		defaultDemoDb: newDemoDb(c),
	}
}

func (c *customDemoDb) FindByName(ctx context.Context, name string) (*Demo, error) {
	result := &Demo{}
	err := c.WithContext(ctx).Where(" name = ? ", name).First(result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (c *customDemoDb) FindListWithTotal(ctx context.Context, args *DemoSearch) ([]*Demo, int64, error) {
	model := c.WithContext(ctx).Model(c.model)
	if args.Name != "" {
		model = model.Where(" name LIKE ? ", "%"+args.Name+"%")
	}
	if args.Id != nil {
		model = model.Where(" id = ? ", args.Id)
	}
	var total int64
	err := model.WithContext(ctx).Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	if total == 0 {
		return nil, 0, ErrNotFound
	}

	var result []*Demo
	model = model.Order(
		c.HandleRank(
			args.OrderField,
			args.OrderType,
			"`"+c.model.TableName()+"`.`id`",
		),
	)
	offset, limit := c.HandlePage(args.Page, args.PageSize)
	err = model.Offset(offset).Limit(limit).Find(&result).Error

	return result, total, err
}

func (c *customDemoDb) FindListWithMore(ctx context.Context, args *DemoSearch) ([]*Demo, bool, error) {
	model := c.WithContext(ctx).Model(c.model)
	if args.Name != "" {
		model = model.Where(" name LIKE ? ", "%"+args.Name+"%")
	}
	if args.Id != nil {
		model = model.Where(" id = ? ", args.Id)
	}

	var result []*Demo
	model = model.Order(
		c.HandleRank(
			args.OrderField,
			args.OrderType,
			"`"+c.model.TableName()+"`.`id`",
		),
	)
	offset, limit := c.HandlePage(args.Page, args.PageSize)
	// 在请求的数据基础上+1，以此来判断是否还有数据
	limit += 1
	err := model.Offset(offset).Limit(limit).Find(&result).Error

	ln := len(result)
	var hasMore bool
	if ln == limit {
		result = result[:ln-1]
		hasMore = true
	}

	return result, hasMore, err
}

func (c *customDemoDb) UpdateTrans(ctx context.Context, id int64, upData *Demo) error {
	err := c.Conn.Tx(ctx, func(ctx context.Context) error {
		preOne := id - 1
		demo, err := c.FindOne(ctx, preOne)
		if err != nil {
			return err
		}
		err = c.Delete(ctx, []int64{preOne})
		if err != nil {
			return err
		}
		if demo.Id == 3 {
			return errors.New("id是3,不能修改")
		}
		_, err = c.UpdateColumns(ctx, id, map[string]any{"name": upData.Name, "test1": upData.Test1, "test4": upData.Test4})
		return err
	})
	return err
}
