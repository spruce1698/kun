package db

import (
	"context"

	"github.com/pkg/errors"
)

//go:generate mockgen -source=./demo.go -destination=../../../test/mocks/repository/db/demo.go  -package mock_repo_db -aux_files mysql=./demo_gen.go

var _ DemoDb = (*customDemoDb)(nil)

type (
	DemoDb interface {
		demoDb

		ListWithTotal(ctx context.Context, args *DemoSearch) ([]*Demo, int64, error)
		ListWithMore(ctx context.Context, args *DemoSearch) ([]*Demo, bool, error)
		UpdateTrans(ctx context.Context, id int64, upData *Demo) error
		FindStream(ctx context.Context, handler func(*Demo) error) error
		FindByName(ctx context.Context, name string) (*Demo, error)

		// TODO: add your code here and delete this line
	}

	customDemoDb struct {
		*defaultDemoDb
	}

	DemoSearch struct {
		SearchPage
	}

	// TODO: add your code here and delete this line
)

func NewDemoDb(c *Conn) DemoDb {
	return &customDemoDb{
		defaultDemoDb: newDemoDb(c),
	}
}

func (c *customDemoDb) ListWithTotal(ctx context.Context, args *DemoSearch) ([]*Demo, int64, error) {
	model := c.WithContext(ctx).Model(c.model)

	var total int64
	err := model.WithContext(ctx).Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	if total == 0 {
		return nil, 0, ErrNotFound
	}
	model = model.Order(
		c.HandleRank(
			args.OrderField,
			args.OrderType,
			"`"+TableDemo+"`.`id`",
		),
	)
	offset, limit := c.HandlePage(args.Page, args.PageSize)
	//  time>lastTime or (time==lastTime and id>lastId)
	if args.LastId > 0 && args.Page > 1 {
		if args.OrderType == 0 {
			model = model.Where("`id` > ?", args.LastId).Limit(limit)
		} else {
			model = model.Where("`id` < ?", args.LastId).Limit(limit)
		}
	} else if offset > 100000 { // 考虑深分页 SELECT * FROM demo INNER JOIN (SELECT id FROM demo LIMIT 100000, 10) AS tmp USING(id);
		model = c.WithContext(ctx).Model(c.model).
			Joins("INNER JOIN (?) AS tmp USING(id)", model.Select("id").Offset(offset).Limit(limit))
	} else {
		model = model.Offset(offset).Limit(limit)
	}

	result := make([]*Demo, 0, limit)
	err = model.Find(&result).Error
	if err != nil {
		return nil, 0, err
	}
	if len(result) == 0 {
		return nil, 0, ErrNotFound
	}
	return result, total, nil
}

func (c *customDemoDb) ListWithMore(ctx context.Context, args *DemoSearch) ([]*Demo, bool, error) {
	model := c.WithContext(ctx).Model(c.model)

	model = model.Order(
		c.HandleRank(
			args.OrderField,
			args.OrderType,
			"`"+TableDemo+"`.`id`",
		),
	)
	offset, limit := c.HandlePage(args.Page, args.PageSize)
	// 在请求的数据基础上+1，以此来判断是否还有数据
	limit += 1

	if args.LastId > 0 && args.Page > 1 {
		if args.OrderType == 0 {
			model = model.Where("`id` > ?", args.LastId).Limit(limit)
		} else {
			model = model.Where("`id` < ?", args.LastId).Limit(limit)
		}
	} else if offset > 100000 { // 考虑深分页
		model = c.WithContext(ctx).Model(c.model).
			Joins("INNER JOIN (?) AS tmp USING(id)", model.Select("id").Offset(offset).Limit(limit))
	} else {
		model = model.Offset(offset).Limit(limit)
	}

	result := make([]*Demo, 0, limit)
	err := model.Find(&result).Error
	if err != nil {
		return nil, false, err
	}

	ln := len(result)
	if ln == 0 {
		return nil, false, ErrNotFound
	}
	var hasMore bool
	if ln == limit {
		result = result[:ln-1]
		hasMore = true
	}

	return result, hasMore, nil
}

func (c *customDemoDb) UpdateTrans(ctx context.Context, id int64, upData *Demo) error {
	err := c.Conn.Tx(ctx, func(ctx context.Context) error {
		preOne := id - 1
		demo, err := c.Find(ctx, preOne)
		if err != nil {
			return err
		}
		err = c.Delete(ctx, []int64{preOne})
		if err != nil {
			return err
		}
		if demo.Id == 3 {
			return errors.New("id是3,不能修改")
		}
		_, err = c.UpdateFields(ctx, id, map[string]any{"name": upData.Name, "test1": upData.Test1, "test4": upData.Test4})
		return err
	})
	return err
}

func (c *customDemoDb) FindStream(ctx context.Context, handler func(*Demo) error) error {
	rows, err := c.WithContext(ctx).Model(c.model).Order("`id` ASC").Rows()
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var item Demo
		if err := c.WithContext(ctx).ScanRows(rows, &item); err != nil {
			return err
		}
		if err := handler(&item); err != nil {
			return err
		}
	}
	return nil
}

// FindByName 根据名称查找(登录账号)
func (c *customDemoDb) FindByName(ctx context.Context, name string) (*Demo, error) {
	result := &Demo{}
	err := c.WithContext(ctx).Where(" `name` = ? ", name).First(result).Error
	if err != nil {
		return nil, err
	}
	return result, nil
}
