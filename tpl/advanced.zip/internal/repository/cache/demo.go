/**
 * @Author: spruce
 * @Date: 2024-03-28 21:36
 * @Desc: demo cache
 */

package cache

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"advanced/pkg/xredis"

	"github.com/pkg/errors"
)

var _ DemoCache = (*demoCache)(nil)

type (
	DemoCache interface {
		// 查询缓存
		Get(ctx context.Context, id int64) (data *Demo, err error)
		// 添加缓存
		Set(ctx context.Context, id int64, data *Demo, expiration int64) (err error)
		// 删除缓存(Redis + 本地),用于数据更新/删除后失效缓存
		Delete(ctx context.Context, id int64) error
	}
	demoCache struct {
		common     *xredis.Client
		localCache *LocalCache
	}

	//  Demo缓存数据
	Demo struct {
		Id     int64
		Name   string // 名称
		Test4  int32  // 测试4
		RoleId int64  // 角色id
	}
)

func NewDemoCache(c *xredis.Client) DemoCache {
	return &demoCache{
		common:     c,
		localCache: NewLocalCache(5*time.Minute, 10*time.Minute),
	}
}

func (d *demoCache) Get(ctx context.Context, id int64) (*Demo, error) {
	key := fmt.Sprintf(DemoInfoKey, id)

	// 1. 查询本地缓存
	if value, ok := d.localCache.Get(key); ok {
		if demo, ok := value.(*Demo); ok {
			return demo, nil
		}
	}

	// 2. 查询Redis缓存
	var demo *Demo
	data, err := d.common.Get(ctx, key).Bytes()
	if err != nil {
		if errors.Is(err, xredis.Nil) {
			return nil, fmt.Errorf("cache miss: %w", xredis.Nil)
		}
		return nil, fmt.Errorf("get cache failed: %w", err)
	}
	err = json.Unmarshal(data, &demo)
	if err != nil {
		return nil, err
	}
	// 设置本地缓存
	d.localCache.Set(key, demo, 5*time.Minute)
	return demo, nil
}

func (d *demoCache) Set(ctx context.Context, id int64, data *Demo, expiration int64) error {
	key := fmt.Sprintf(DemoInfoKey, id)

	value, valueErr := json.Marshal(data)
	if valueErr != nil {
		return valueErr
	}
	err := d.common.Set(ctx, key, string(value), time.Duration(expiration)*time.Second).Err()
	if err != nil {
		return err
	}
	return nil
}

func (d *demoCache) Delete(ctx context.Context, id int64) error {
	key := fmt.Sprintf(DemoInfoKey, id)

	// 本地缓存是 Redis 的副本,无论 Redis 删除是否成功都先清本地,避免残留旧值。
	d.localCache.Delete(key)

	// 删除 Redis,失败时包装原始错误(不吞原因)。
	if err := d.common.Del(ctx, key).Err(); err != nil {
		return fmt.Errorf("delete cache failed: %w", err)
	}
	return nil
}

// TODO Warmup 缓存预热
func (d *demoCache) Warmup(ctx context.Context) error {

	return nil
}
