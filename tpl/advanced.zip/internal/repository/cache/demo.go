/**
 * @Author: spruce
 * @Date: 2024-03-28 21:36
 * @Desc: demo cache
 */

package cache

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"advanced/pkg/xredis"

	"github.com/pkg/errors"
)

var _ DemoCache = (*demoCache)(nil)

type (
	DemoCache interface {
		// 查询缓存
		Get(ctx context.Context, id int64) (data *Demo, err error)
		// 添加缓存
		Set(ctx context.Context, id int64, data *Demo, expiration int64) (err error)
	}
	demoCache struct {
		common     *xredis.Client
		localCache *LocalCache
	}

	//  Demo缓存数据
	Demo struct {
		Id    int64
		Name  string // 名称
		Test4 int32  // 测试4
	}
)

func NewDemoCache(c *xredis.Client) DemoCache {
	return &demoCache{
		common:     c,
		localCache: NewLocalCache(5*time.Minute, 10*time.Minute),
	}
}

func (d *demoCache) Get(ctx context.Context, id int64) (*Demo, error) {
	key := fmt.Sprintf(DemoInfoKey, id)

	// 1. 查询本地缓存
	if value, ok := d.localCache.Get(key); ok {
		if demo, ok := value.(*Demo); ok {
			return demo, nil
		}
	}

	// 2. 查询Redis缓存
	var demo *Demo
	data, err := d.common.Get(ctx, key).Bytes()
	if err != nil {
		if errors.Is(err, xredis.Nil) {
			return nil, errors.New("cache miss")
		}
		return nil, errors.New("get cache failed")
	}
	err = json.Unmarshal(data, &demo)
	if err != nil {
		return nil, err
	}
	// 设置本地缓存
	d.localCache.Set(key, demo, 5*time.Minute)
	return demo, nil
}

func (d *demoCache) Set(ctx context.Context, id int64, data *Demo, expiration int64) error {
	key := fmt.Sprintf(DemoInfoKey, id)

	value, valueErr := json.Marshal(data)
	if valueErr != nil {
		return valueErr
	}
	err := d.common.Set(ctx, key, string(value), time.Duration(expiration)*time.Second).Err()
	if err != nil {
		return err
	}
	return nil
}

func (d *demoCache) Delete(ctx context.Context, id int64) error {
	key := fmt.Sprintf(DemoInfoKey, id)

	if err := d.common.Del(ctx, key).Err(); err != nil {
		return errors.New("delete cache failed")
	}
	// 设置本地缓存
	d.localCache.Delete(key)
	return nil
}

// Warmup 缓存预热
func (d *demoCache) Warmup(ctx context.Context) error {

	return nil
}
