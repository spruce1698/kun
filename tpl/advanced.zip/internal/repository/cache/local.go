package cache

import (
	"sync"
	"time"

	goCache "github.com/patrickmn/go-cache"
)

type LocalCache struct {
	cache *goCache.Cache
	mu    sync.RWMutex
}

//  创建本地缓存
func NewLocalCache(defaultExpiration, cleanupInterval time.Duration) *LocalCache {
	return &LocalCache{
		cache: goCache.New(defaultExpiration, cleanupInterval),
	}
}

//  设置缓存
func (l *LocalCache) Set(key string, value any, expiration time.Duration) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.cache.Set(key, value, expiration)
}

//  获取缓存
func (l *LocalCache) Get(key string) (any, bool) {
	l.mu.RLock()
	defer l.mu.RUnlock()
	return l.cache.Get(key)
}

//  删除缓存
func (l *LocalCache) Delete(key string) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.cache.Delete(key)
}
