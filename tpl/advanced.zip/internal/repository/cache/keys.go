package cache

// CacheKey 缓存键同一管理
const (
	DemoInfoKey = "demo:%d"
)
