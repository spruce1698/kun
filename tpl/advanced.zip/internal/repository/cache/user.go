/**
 * @Author: spruce
 * @Date: 2024-04-20 21:36
 * @Desc: demo cache
 */

package cache

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"advanced/pkg/xredis"

	"github.com/pkg/errors"
)

var _ UserRepo = (*defaultUser)(nil)

type (
	UserRepo interface {
		// 添加缓存
		SetUser(ctx context.Context, id int64, data *User, expiration int64) (err error)
		GetUser(ctx context.Context, id int64) (data *User, err error)
	}
	// User 缓存数据
	User struct {
		Id       int64  `json:"id"`       // 用户id
		Username string `json:"username"` // 用户名
		Email    string `json:"email"`    // 邮箱
	}

	defaultUser struct {
		infoKey string // 缓存key
		common  *xredis.Client
	}
)

func NewUserRepo(cli *xredis.Client) UserRepo {
	return &defaultUser{
		infoKey: "user:%d",
		common:  cli,
	}
}

func (d *defaultUser) SetUser(ctx context.Context, id int64, data *User, expiration int64) (err error) {
	key := fmt.Sprintf(d.infoKey, id)
	value, valueErr := json.Marshal(data)
	if valueErr != nil {
		return valueErr
	}
	err = d.common.Set(ctx, key, string(value), time.Duration(expiration)*time.Second).Err()
	if err != nil {
		return err
	}
	return nil
}

func (d *defaultUser) GetUser(ctx context.Context, id int64) (data *User, err error) {
	key := fmt.Sprintf(d.infoKey, id)
	info := d.common.Get(ctx, key).Val()
	if len(info) == 0 {
		return nil, errors.New("获取 User 缓存错误")
	}
	err = json.Unmarshal([]byte(info), &data)
	if err != nil {
		return nil, err
	}
	return data, nil
}
