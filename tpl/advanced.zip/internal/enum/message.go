/**
 * @Author: spruce
 * @Date: 2022/4/2 15:19
 * @Desc: topic的枚举
 */

package enum

type (
	MsgType  string
	MsgTopic string
	MsgGroup string
)

// 消息类型
const (
	// 支付充值
	DemoMsgTypePayRecharge MsgType = "demo_pay_recharge"
)

// 消息Topic
const (
	// 支付消息topic
	DemoMsgTopicPay MsgTopic = "demo_topic_pay"
)

// 消息group
const (
	// 支付消息topic
	DemoMsgGroupPay  MsgGroup = "demo_group_pay"
	DemoMsgGroupPay1 MsgGroup = "demo_group_pay1"
)

// Demo支付充值消息
type DemoPayRecharge struct {
	PayType    int64   `json:"pay_type"`    // 支付类型 参考 enum.DemoPayTypeAlipay
	Status     int64   `json:"status"`      // 状态 1:发起中 2:成功 3:失败 参考 enum.DemoPayStatusIng
	UserId     int64   `json:"user_id"`     // 充值用户id
	TradeNo    string  `json:"trans_no"`    // 内部交易单号
	Cash       float64 `json:"cash"`        // 交易的现金(单位元)
	CreateTime string  `json:"create_time"` // 发生时间
	Remark     string  `json:"remark"`      // 备注信息
}
