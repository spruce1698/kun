/**
* @Author: spruce
 * @Date: 2024-04-20 16:45
 * @Desc: ctx key 值
*/

package enum

const (
	CtxMgrAuthToken      string = "Mgr.Auth.Token"
	CtxMgrAuthOrganizeId string = "Mgr.Auth.OrganizeId"
	CtxMgrAuthAccountId  string = "Mgr.Auth.AccountId"
	CtxMgrAuthGroupId    string = "Mgr.Auth.GroupId"
	CtxMgrAuthFormat     string = "%d-%d-%d" // mgr auth 格式化字符串 orgId-accountId-groupId
)
