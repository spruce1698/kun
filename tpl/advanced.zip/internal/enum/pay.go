/**
* @Author: spruce
 * @Date: 2024-04-20 17:00
 * @Desc: 类型
*/

package enum

// Demo交易状态
const (
	DemoPayStatusIng     = 1 // 进行中
	DemoPayStatusSuccess = 2 // 成功
	DemoPayStatusFail    = 3 // 失败
)

// Demo支付方式
const (
	DemoPayTypeAlipay = 1 // 支付宝
	DemoPayTypeWxpay  = 2 // 微信
)
