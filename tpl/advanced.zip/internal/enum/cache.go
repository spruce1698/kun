/**
 * @Author: spruce
 * @Date: 2024-04-20 15:51
 * @Desc: 缓存常量
 */

package enum
