/**
 * @Author: spruce
 * @Date: 2024-04-20 17:30
 * @Desc: api 常量/枚举
 */

package enum

const (
	RouterPrefixApi = "/api"
	RouterPrefixMgr = "/mgr"
)
