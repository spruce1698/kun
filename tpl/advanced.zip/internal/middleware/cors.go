/**
 * @Author:
 * @Date: 2024-03-28 10:41
 * @Desc: 跨域中间件
 */

package middleware

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// CORS 跨域中间件
func CORS() gin.HandlerFunc {
	return func(ctx *gin.Context) {
		// 设置允许跨域的域名，*代表允许任意域名跨域
		ctx.Header("Access-Control-Allow-Origin", "*")
		// 可以带cookies
		ctx.Header("Access-Control-Allow-Credentials", "true")
		// 允许的header类型
		ctx.Header("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With,X-Request-Id,Client-Type,App-Version,Token,token")
		// 跨域允许的请求方式
		ctx.Header("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT, PATCH, DELETE")
		if ctx.Request.Method == "OPTIONS" {
			ctx.AbortWithStatus(http.StatusNoContent)
			return
		}
		ctx.Next()
	}
}
