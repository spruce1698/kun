/**
 * @Author:
 * @Date: 2024-03-28 13:46
 * @Desc: 授权验证中间件
 */

package middleware

import (
	"advanced/internal/global"
	"advanced/pkg/token"
	"advanced/pkg/xconfig"
	"advanced/pkg/xerror"
	"advanced/pkg/xhttp"
	"advanced/pkg/xlog"

	"github.com/gin-gonic/gin"
	"github.com/pkg/errors"
)

// jwt授权
func Auth(cnf *xconfig.Cnf, log *xlog.Logger) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		err := parsePayload(ctx, cnf, log)
		if err != nil {
			var e *token.Error
			if errors.As(err, &e) {
				switch e.Errors {
				case token.ErrorExpiredToken:
					xhttp.AuthFail(ctx, xerror.AuthTimeOut)
					ctx.Abort()
					return
				default:
					xhttp.AuthFail(ctx, xerror.AuthError)
					ctx.Abort()
					return
				}
			}
			xhttp.AuthFail(ctx, xerror.AuthError)
			ctx.Abort()
			return
		}
		ctx.Next()
	}
}

// 可选授权
func OptAuth(cnf *xconfig.Cnf, log *xlog.Logger) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		_ = parsePayload(ctx, cnf, log)
		ctx.Next()
	}
}

// 如果有就写入授权
func WireAuth(cnf *xconfig.Cnf, log *xlog.Logger) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		// 查找token
		if tokenStr := token.NewJwt(cnf, log).Find(ctx.Request); tokenStr != "" {
			ctx.Set(global.CtxAuthToken, tokenStr)
		}
		ctx.Next()
	}
}

func parsePayload(ctx *gin.Context, cnf *xconfig.Cnf, log *xlog.Logger) (err error) {
	jwt := token.NewJwt(cnf, log)
	// 查找token
	if tokenStr := jwt.Find(ctx.Request); tokenStr != "" {
		payload, parseErr := jwt.Parse(tokenStr)
		if parseErr != nil {
			err = parseErr
		} else {
			ctx.Set(global.CtxAuthToken, tokenStr)
			ctx.Set(global.CtxAuthOrganizeId, payload.OrganizeId)
			ctx.Set(global.CtxAuthAccountId, payload.AccountId)
			ctx.Set(global.CtxAuthGroupId, payload.GroupId)
		}
	} else {
		err = token.ErrEmptyToken
	}
	return err
}
