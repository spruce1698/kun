/**
 * @Author: spruce
 * @Date: 2024-04-20 13:46
 * @Desc: token验证中间件
 */

package middleware

import (
	"advanced/internal/enum"
	"advanced/pkg/token"
	"advanced/pkg/xerror"
	"advanced/pkg/xhttp"

	"github.com/gin-gonic/gin"
	"github.com/pkg/errors"
)

// jwt授权
func Auth(jwt *token.Jwt) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		err := parsePayload(ctx, jwt)
		if err != nil {
			var e *token.Error
			if errors.As(err, &e) {
				switch e.Errors {
				case token.JWTErrorExpiredToken:
					xhttp.AuthFail(ctx, xerror.AuthTimeOut)
					ctx.Abort()
					return
				default:
					xhttp.AuthFail(ctx, xerror.AuthError)
					ctx.Abort()
					return
				}
			}
			xhttp.AuthFail(ctx, xerror.AuthError)
			ctx.Abort()
			return
		}
		ctx.Next()
	}
}

// 可选授权
func OptAuth(jwt *token.Jwt) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		_ = parsePayload(ctx, jwt)
		ctx.Next()
	}
}
func parsePayload(ctx *gin.Context, jwt *token.Jwt) (err error) {
	// 查找token
	if tokenStr := jwt.Find(ctx.Request); tokenStr != "" {
		payload, parseErr := jwt.Parse(tokenStr)
		if parseErr != nil {
			err = parseErr
		} else {
			ctx.Set(enum.CtxMgrAuthToken, tokenStr)
			for k, v := range payload {
				if k == token.JwtPayloadOrganizeId {
					ctx.Set(enum.CtxMgrAuthOrganizeId, v.(int64))
				} else if k == token.JwtPayloadAccountId {
					ctx.Set(enum.CtxMgrAuthAccountId, v.(int64))
				} else if k == token.JwtPayloadGroupId {
					ctx.Set(enum.CtxMgrAuthGroupId, v.(int64))
				}
			}
		}
	} else {
		err = token.ErrEmptyToken
	}
	return err
}
