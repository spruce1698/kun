/**
 * @Author: albert
 * @Date: 2024-12-26
 * @Desc: csrf
 */

package middleware

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/csrf"
)

// CSRF 中间件
func CSRF() gin.HandlerFunc {
	return func(ctx *gin.Context) {
		// 初始化 CSRF 保护中间件
		csrfProtection := csrf.Protect(
			[]byte("32-byte-long-auth-key"),  // 替换为你的安全密钥
			csrf.Secure(false),               // 是否只在 HTTPS 中启用，开发阶段可以设置为 false
			csrf.RequestHeader("CSRF-Token"), // 通过header获取csrftoken
			// csrf.CookieName("CSRF-Token"), // 通过cookie获取csrftoken
			csrf.Path("/"),
			csrf.SameSite(csrf.SameSiteLaxMode),
			csrf.HttpOnly(true), // 指定cookie的值只能在服务端设置，禁止在客户端使用javascript修改
			csrf.ErrorHandler(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(http.StatusForbidden)
				_, _ = w.Write([]byte(`{"message": "Forbidden - CSRF token invalid"}`))
				ctx.Abort()
			})),
		)

		// 将 Gin 的上下文转换为标准 http.Handler
		csrfHandler := csrfProtection(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// 更新 Gin 上下文的请求对象
			ctx.Request = r
			// 继续处理 Gin 的后续中间件和路由逻辑
			ctx.Next()
		}))

		// 直接使用 Gin 的 c.Writer
		csrfHandler.ServeHTTP(ctx.Writer, ctx.Request)
	}
}
