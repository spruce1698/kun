/**
 * @Author:
 * @Date: 2024-03-28 18:18
 * @Desc: 处理panic
 */

package middleware

import (
	"net"
	"net/http"
	"net/http/httputil"
	"os"
	"runtime/debug"
	"strings"

	"advanced/pkg/xlog"

	"github.com/gin-gonic/gin"
)

// recover掉项目可能出现的panic，并使用日志记录相关日志
func Recovery(stack bool, log *xlog.Logger) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		defer func() {
			if err := recover(); err != nil {
				// Check for a broken connection, as it is not really a
				// condition that warrants a panic stack trace.
				var brokenPipe bool
				if ne, ok := err.(*net.OpError); ok {
					if se, okk := ne.Err.(*os.SyscallError); okk {
						if strings.Contains(strings.ToLower(se.Error()), "broken pipe") ||
							strings.Contains(strings.ToLower(se.Error()), "connection reset by peer") {
							brokenPipe = true
						}
					}
				}

				httpRequest, _ := httputil.DumpRequest(ctx.Request, false)
				if brokenPipe {
					log.Error(ctx.Request.URL.Path,
						xlog.Any("error", err),
						xlog.String("request", string(httpRequest)),
					)
					// If the connection is dead, we can't write a status to it.
					_ = ctx.Error(err.(error))
					ctx.Abort()
					return
				}

				if stack {
					log.Error("[Recovery from panic]",
						xlog.Any("error", err),
						xlog.String("request", string(httpRequest)),
						xlog.String("stack", string(debug.Stack())),
					)
				} else {
					log.Error("[Recovery from panic]",
						xlog.Any("error", err),
						xlog.String("request", string(httpRequest)),
					)
				}
				ctx.AbortWithStatus(http.StatusInternalServerError)
			}
		}()
		ctx.Next()
	}
}
