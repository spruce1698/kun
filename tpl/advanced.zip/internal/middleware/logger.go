/**
 * @Author:
 * @Date: 2024-03-28 18:18
 * @Desc: 日志中间件,接管gin日志
 */

package middleware

import (
	"bytes"
	"io"
	"time"

	"advanced/pkg/encrypt"
	"advanced/pkg/utils"
	"advanced/pkg/xlog"

	"github.com/gin-gonic/gin"
)

// 接管gin框架默认的日志
func Logger(log *xlog.Logger) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		start := time.Now()
		trace := encrypt.MD5(utils.GenUUid())
		path := ctx.Request.URL.Path
		query := ctx.Request.URL.RawQuery

		// 请求包体写回。
		requestBody, _ := ctx.GetRawData()
		if len(requestBody) > 0 {
			ctx.Request.Body = io.NopCloser(bytes.NewBuffer(requestBody)) // 关键点
		}

		// 请求信息
		log.Info(path,
			xlog.String("trace", trace),
			xlog.String("method", ctx.Request.Method),
			xlog.String("path", path),
			xlog.String("query", query),
			xlog.String("ip", ctx.ClientIP()),
			xlog.Int("status", ctx.Writer.Status()),
			xlog.String("user-agent", ctx.Request.UserAgent()),
			xlog.String("errors", ctx.Errors.ByType(gin.ErrorTypePrivate).String()),
			xlog.String("request-body", string(requestBody)),
		)

		// 使用自定义 ResponseWriter
		crw := &CustomResponseWriter{
			body:           bytes.NewBufferString(""),
			ResponseWriter: ctx.Writer,
		}
		ctx.Writer = crw

		// 执行请求处理程序和其他中间件函数
		ctx.Next()

		// 响应内容和处理时间
		log.Info(path,
			xlog.String("trace", trace),
			xlog.String("method", ctx.Request.Method),
			xlog.String("path", path),
			xlog.String("query", query),
			xlog.String("ip", ctx.ClientIP()),
			xlog.Int("status", ctx.Writer.Status()),
			xlog.String("user-agent", ctx.Request.UserAgent()),
			xlog.String("errors", ctx.Errors.ByType(gin.ErrorTypePrivate).String()),
			xlog.String("request-body", string(requestBody)),
			xlog.String("response-body", string(crw.body.Bytes())),
			xlog.String("cost", time.Since(start).String()),
		)
	}
}

// CustomResponseWriter 封装 gin ResponseWriter 用于获取回包内容。
type CustomResponseWriter struct {
	gin.ResponseWriter
	body *bytes.Buffer
}

func (w CustomResponseWriter) Write(b []byte) (int, error) {
	w.body.Write(b)
	return w.ResponseWriter.Write(b)
}
