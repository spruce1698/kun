/**
 * @Author: spruce
 * @Date: 2024-04-20 11:08
 * @Desc: 路由层 wire 配置
 */

package router

import (
	"net/http"

	"advanced/internal/controller"
	v0 "advanced/internal/router/v0"
	"advanced/pkg/token"
	"advanced/pkg/xhttp"

	"github.com/gin-gonic/gin"

	"advanced/docs" // 千万不要忘了导入把你上一步生成的docs

	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
)

type (
	Routers func(e *gin.Engine, jwt *token.Jwt, ctl *controller.ServerCtl)
)

// 缺省路由
func NotFoundHandle(ctx *gin.Context) {
	xhttp.WithNotFoundPath(ctx)
}

// ping 路由
func Ping(e *gin.Engine) {
	e.GET("/ping", func(ctx *gin.Context) {
		ctx.String(http.StatusOK, "pong")
	})
}

// SwaggerRouter 路由
func SwaggerRouter(e *gin.Engine) {
	docs.SwaggerInfo.BasePath = ""
	e.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler)) // /swagger/index.html
}

// ====================== TODO 需要手动配置  http 路由层 修改后重新wire ======================

// 路由层
func WireServerSet() []Routers {
	return []Routers{
		v0.User,
	}
}
