/**
 * @Author: spruce
 * @Date: 2024-04-20 11:08
 * @Desc: wire 路由配置 InjectSet
 */

package router

import (
	"net/http"

	"advanced/internal/controller"
	v0 "advanced/internal/router/v0"
	"advanced/pkg/token"
	"advanced/pkg/xhttp"

	"github.com/gin-gonic/gin"

	docs "advanced/docs" // 千万不要忘了导入把你上一步生成的docs

	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
)

type (
	Routers func(e *gin.Engine, jwt *token.Jwt, ctl *controller.CtlSet)
)

// 缺省路由
func NotFoundHandle(ctx *gin.Context) {
	xhttp.WithNotFoundPath(ctx)
}

// ping 路由
func Ping(e *gin.Engine) {
	e.GET("/ping", func(ctx *gin.Context) {
		ctx.String(http.StatusOK, "pong")
	})
}

// SwaggerRouter 路由
func SwaggerRouter(e *gin.Engine) {
	docs.SwaggerInfo.BasePath = ""
	e.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler)) // /swagger/index.html
}

// 路由层   // TODO 需要手动增加 后执行 wire
func InjectSet() []Routers {
	return []Routers{
		v0.User,
	}
}
