/**
 * @Author: spruce
 * @Date: 2024-04-20 11:11
 * @Desc: 默认用户路由
 */

package v0

import (
	"advanced/internal/controller"
	"advanced/internal/enum"
	"advanced/pkg/token"

	"github.com/gin-gonic/gin"
)

func User(e *gin.Engine, jwt *token.Jwt, ctl *controller.CtlSet) {
	// api user路由
	apiGroup := e.Group(enum.RouterPrefixApi)
	{
		apiGroup.GET("/user", ctl.UserCtl.GetUserById)
		apiGroup.GET("/user/list", ctl.UserCtl.GetUserList)
		apiGroup.POST("/user/senMsg", ctl.UserCtl.SenMsg)
		apiGroup.POST("/user/delMsg", ctl.UserCtl.DelMsg)
	}

}
