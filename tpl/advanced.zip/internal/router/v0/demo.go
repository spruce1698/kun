/**
 * @Author: spruce
 * @Date: 2024-03-28 11:11
 * @Desc: v0 路由
 */

package v0

import (
	"advanced/internal/controller"
	"advanced/internal/global"
	"advanced/internal/middleware"
	"advanced/pkg/token"

	"github.com/gin-gonic/gin"
)

func Demo(e *gin.Engine, jwt *token.Jwt, ctx *controller.ServerCtrlCtx) {
	// api Demo路由
	apiGroup := e.Group(global.RouterPrefixApi)
	{
		apiGroup.GET("/demo/:id", ctx.DemoCtrl.Detail)
		apiGroup.GET("/demo/list", ctx.DemoCtrl.List)
		apiGroup.POST("/demo/create", ctx.DemoCtrl.Create)
		apiGroup.POST("/demo/update", ctx.DemoCtrl.Update)
		apiGroup.POST("/demo/delete", ctx.DemoCtrl.Delete)
		apiGroup.POST("/demo/softdelete", ctx.DemoCtrl.SoftDelete)

		apiGroup.POST("/demo/sendMsg", ctx.DemoCtrl.SendMsg)
		apiGroup.POST("/demo/delMsg", ctx.DemoCtrl.DelMsg)

		apiGroup.GET("/demo/csrf", middleware.CSRF(), ctx.DemoCtrl.GetCsrf)
		apiGroup.POST("/demo/submitCsrf", middleware.CSRF(), ctx.DemoCtrl.SubmitCsrf)
	}
}
