package controller

import (
	"errors"

	"advanced/internal/service"
	"advanced/pkg/validator"
	"advanced/pkg/xerror"
	"advanced/pkg/xhttp"

	"github.com/gin-gonic/gin"
)

type (
	UserCtl struct {
		userSvc service.UserSvc
	}
	userOneReq struct {
		Id int64 `form:"id" binding:"required"`
	}
	userListReq struct {
		Page     int64 `form:"page,default=1" binding:"required,gte=1"`
		PageSize int64 `form:"pagesize,default=20" binding:"required,customizePageSize"`
	}
)

func NewUserCtl(userSvc service.UserSvc) *UserCtl {
	return &UserCtl{
		userSvc: userSvc,
	}
}

// @Summary GetUserById
// @Description 查询 user 详情
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "userID"
// @Success 200 {string} string "{"code":0,"message":"GetUser成功","data":{"id":1,"username":"name","email":"name@email.com"}}"
// @Failure 500 {string} string "{"code":50000,"message":"GetUserById失败","data":""}"
// @Router /api/user [get]
func (c *UserCtl) GetUserById(ctx *gin.Context) {
	params := &userOneReq{}
	if err := ctx.ShouldBind(params); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err.Error())
		return
	}

	data, err := c.userSvc.GetUserById(params.Id)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "GetUser成功", data)
}

// @Summary GetUserList
// @Description 查询 user 列表
// @Tags api
// @Accept json
// @Produce json
// @Param page query int true "当前页"
// @Param pageSize query int true "分页条数"
// @Router /api/user/list [get]
func (c *UserCtl) GetUserList(ctx *gin.Context) {
	req := &userListReq{}
	if err := ctx.ShouldBind(req); err != nil {
		var valErrs validator.Errors
		// validator.Errors 类型错误直接返回
		if ok := errors.As(err, &valErrs); ok {
			// 对 validator.Errors 类型错误则进行翻译
			xhttp.BusCode(ctx, xerror.ParamError, "", validator.Message(valErrs))
			return
		}
		// 非validator.Errors 类型错误直接返回
		xhttp.BusCode(ctx, xerror.ParamError, err.Error())
		return
	}
	hasMore, items, err := c.userSvc.GetList(req.Page, req.PageSize)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.More(ctx, "GetUserList 成功", req.Page, req.PageSize, hasMore, items)
}

// @Summary SenMsg
// @Description  发送消息
// @Tags api
// @Accept json
// @Produce json
// @Router /api/user/senMsg [post]
func (c *UserCtl) SenMsg(ctx *gin.Context) {
	err := c.userSvc.SendMsg()
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "SenMsg 成功", nil)
}

// @Summary DelMsg
// @Description  取消定时消息
// @Tags api
// @Accept json
// @Produce json
// @Router /api/user/delMsg [post]
func (c *UserCtl) DelMsg(ctx *gin.Context) {
	err := c.userSvc.DelMsg()
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "DelMsg 成功", nil)
}
