package demo

import (
	"advanced/internal/service/svc"
	"advanced/pkg/xerror"
	"advanced/pkg/xhttp"

	"github.com/jinzhu/copier"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/csrf"
)

type (
	DemoCtrl struct {
		DemoSvc svc.DemoSvc
	}
)

// @Summary Detail
// @Description demo详情
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "demoID"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /api/demo/:id [get]
func (d *DemoCtrl) Detail(ctx *gin.Context) {
	// 获取参数两种方式
	// 方式1:
	// idStr := ctx.Param("id")
	// if idStr == "" {
	// 	xhttp.BusCode(ctx, xerror.ParamError, errors.New("id不能为空"))
	// 	return
	// }
	// id, _ := strconv.ParseInt(idStr, 10, 64)

	//  方式2(推荐可以方便验证参数):
	type detailId struct {
		Id int64 `uri:"id" binding:"required,min=1,max=100"` // 或者 binding:"required,gte=1,lte=130"
	}
	var urlId detailId
	if err := ctx.ShouldBindUri(&urlId); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	id := urlId.Id

	info, err := d.DemoSvc.Detail(ctx.Request.Context(), id)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "Get Demo Detail 成功", info)
}

// @Summary List
// @Description 根据条件查询demo列表
// @Tags api
// @Accept json
// @Produce json
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /api/demo/list [get]
func (d *DemoCtrl) List(ctx *gin.Context) {
	req := &struct {
		xhttp.PageArg
		Id   *int64 `form:"id"   json:"id"`
		Name string `form:"name"  json:"name"` // 名称
	}{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}

	args := &svc.DemoListArgs{}
	_ = copier.Copy(args, req)

	result, total, err := d.DemoSvc.FindList(ctx.Request.Context(), args)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.List(ctx, "Get Demo List 成功", total, req.Page, req.PageSize, result)
}

// @Summary Create
// @Description 写一个demo
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "demoID"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /api/demo/create [post]
func (d *DemoCtrl) Create(ctx *gin.Context) {
	req := &struct {
		Name  string  `form:"name"  json:"name"  binding:"required"` // 名称
		Test1 float64 `form:"test1"  json:"test1"`                   // 测试1
		Test4 int32   `form:"test4"  json:"test4"`                   // 测试4
	}{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	args := &svc.Demo{}
	_ = copier.Copy(args, req)
	err := d.DemoSvc.Create(ctx.Request.Context(), args)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "Create Demo 成功", nil)
}

// @Summary Update
// @Description 更新一个demo,有事务
// @Tags api
// @Accept json
// @Produce json
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /api/demo/update [post]
func (d *DemoCtrl) Update(ctx *gin.Context) {
	req := &struct {
		Id    int64   `json:"id"   binding:"required"` //
		Name  string  `json:"name"`                    // 名称
		Test1 float64 `json:"test1"`                   // 测试1
		Test4 int32   `json:"test4"`                   // 测试4
	}{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}
	args := &svc.Demo{}
	_ = copier.Copy(args, req)
	err := d.DemoSvc.Update(ctx.Request.Context(), args)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "Update Demo 成功", nil)
}

// @Summary Delete
// @Description 删除一个demo
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "demoID"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /demo/delete [post]
func (d *DemoCtrl) Delete(ctx *gin.Context) {
	req := &struct {
		Id int64 `form:"id" json:"id" binding:"required,gte=1,lte=130"`
	}{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}

	err := d.DemoSvc.Delete(ctx.Request.Context(), req.Id)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "Delete Demo 成功", nil)
}

// @Summary SoftDelete
// @Description 逻辑删除一个demo
// @Tags api
// @Accept json
// @Produce json
// @Param id query int true "demoID"
// @Success 200 {string} string "{"code":0,"message":"demo-Demo成功","data":{"id":100,"name":"我是demo名称"}}"
// @Failure 500 {string} string "{"code":50000,"message":"demo查询失败","data":""}"
// @Router /demo/softdelete [post]
func (d *DemoCtrl) SoftDelete(ctx *gin.Context) {
	req := &struct {
		Id int64 `form:"id" json:"id" binding:"required,gte=1,lte=130"`
	}{}
	if err := ctx.ShouldBind(req); err != nil {
		xhttp.BusCode(ctx, xerror.ParamError, err)
		return
	}

	err := d.DemoSvc.SoftDelete(ctx.Request.Context(), req.Id)
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "SoftDelete Demo 成功", nil)
}

func (d *DemoCtrl) SendMsg(ctx *gin.Context) {
	err := d.DemoSvc.SendMsg(ctx.Request.Context())
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "SenMsg 成功", nil)
}

func (d *DemoCtrl) DelMsg(ctx *gin.Context) {
	err := d.DemoSvc.DelMsg(ctx.Request.Context())
	if err != nil {
		xhttp.BusFail(ctx, err)
		return
	}
	xhttp.Data(ctx, "DelMsg 成功", nil)
}

func (d *DemoCtrl) GetCsrf(ctx *gin.Context) {
	csrfToken := csrf.Token(ctx.Request)
	xhttp.Data(ctx, "GetCsrf 成功", csrfToken)
}

func (d *DemoCtrl) SubmitCsrf(ctx *gin.Context) {
	xhttp.Data(ctx, "SubmitCsrf 成功", "")
}
