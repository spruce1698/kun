/**
 * @Author: spruce
 * @Date: 2024-04-20 15:39
 * @Desc: wire 订阅服务配置
 */

package msgbus

import (
	"advanced/internal/enum"
	"advanced/internal/msgbus/subscriber"
	"advanced/internal/service"
)

// 订阅服务  // TODO 需要手动增加
func InjectSet(svc *service.SvcSet) *subscriber.Task {
	return &subscriber.Task{
		KafkaSet: []*subscriber.Kafka{
			{
				Topic:   enum.DemoMsgTopicPay,
				Group:   enum.DemoMsgGroupPay,
				Handler: svc.SubMsgSvc.SubDemoPayKafka,
			},
			{
				Topic:   enum.DemoMsgTopicPay,
				Group:   enum.DemoMsgGroupPay1,
				Handler: svc.SubMsgSvc.SubKafkaTypeDemoPay,
			},
		},
		AsynqSet: []*subscriber.Asynq{
			{
				Topic:   enum.DemoMsgTopicPay,
				Handler: svc.SubMsgSvc.SubAqPay,
			},
		},
	}
}
