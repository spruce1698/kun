/**
* @Author: spruce
 * @Date: 2024-04-20 11:08
 * @Desc: 订阅者
*/

package subscriber

import (
	"context"
	"fmt"
	"os"
	"sync"

	"advanced/internal/enum"
	"advanced/pkg/asynq"
	"advanced/pkg/kafka"
	"advanced/pkg/xconfig"
)

type (
	Sub struct {
		wg     *sync.WaitGroup
		cnf    *xconfig.Cnf
		aQueue *asynq.Asynq
		task   *Task
	}
	Task struct {
		KafkaSet []*Kafka
		AsynqSet []*Asynq
	}
	Kafka struct {
		Topic   enum.MsgTopic
		Group   enum.MsgGroup
		Handler func(key, value string) error
	}
	Asynq struct {
		Topic   enum.MsgTopic
		Handler func(context.Context, *asynq.Task) error
	}
)

func New(wg *sync.WaitGroup, cnf *xconfig.Cnf, task *Task) *Sub {
	return &Sub{
		wg:     wg,
		cnf:    cnf,
		aQueue: asynq.New(cnf),
		task:   task,
	}
}

// kafka 消费者
func (s *Sub) Kafka() {

	if s.task.KafkaSet == nil || len(s.task.KafkaSet) <= 0 {
		return
	}

	k := kafka.NewSubscriber(s.cnf)
	s.wg.Add(len(s.task.KafkaSet))
	for _, kq := range s.task.KafkaSet {
		go func(v *Kafka) {
			k.Sub(string(v.Topic), string(v.Group), v.Handler)
			defer s.wg.Done()
		}(kq)
	}
	defer k.Close()
}

// Asynq 消费者
func (s *Sub) Asynq() {

	if s.task.AsynqSet == nil || len(s.task.AsynqSet) <= 0 {
		return
	}

	s.wg.Add(1)
	go func() {
		srv := s.aQueue.Server()
		mux := asynq.NewServeMux()
		// 添加任务
		for _, aq := range s.task.AsynqSet {
			mux.HandleFunc(string(aq.Topic), aq.Handler)
		}
		if err := srv.Run(mux); err != nil {
			fmt.Printf("!!!CronJobErr!!! run err:%+v \n ", err)
			srv.Shutdown()
			os.Exit(1)
		}
		defer srv.Stop()
		defer s.wg.Done()
	}()
}

// Asynq 周期性任务服务
func (s *Sub) AsynqCron() {
	s.wg.Add(1)
	go func() {
		_ = s.aQueue.CronPub()
		defer s.wg.Done()
	}()
}
