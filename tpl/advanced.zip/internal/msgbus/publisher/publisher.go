/**
* @Author: spruce
 * @Date: 2024-04-20 17:27
 * @Desc: 发布者
*/

package publisher

import (
	"fmt"
	"time"

	"advanced/internal/enum"
	"advanced/pkg/asynq"
	"advanced/pkg/kafka"
	"advanced/pkg/xconfig"
	"advanced/pkg/xlog"
)

type (
	Pub struct {
		kQueue *kafka.Publisher
		aQueue *asynq.Asynq
		logger *xlog.Logger
	}
)

func New(cnf *xconfig.Cnf, log *xlog.Logger) *Pub {
	return &Pub{
		kQueue: kafka.NewPublisher(cnf),
		aQueue: asynq.New(cnf),
		logger: log,
	}
}

func (p *Pub) Kafka(topic enum.MsgTopic, message []byte) error {
	topicStr := string(topic)
	err := p.kQueue.Pub(topicStr, message)
	if err != nil {
		return fmt.Errorf("kafka topic:%s 发布消息:%s 失败, error:%v", topicStr, message, err)
	}
	return nil
}

func (p *Pub) KafkaWithType(topic enum.MsgTopic, msgType enum.MsgType, message []byte) error {
	topicStr := string(topic)
	msgTypeStr := string(msgType)
	err := p.kQueue.PubWithKey(topicStr, msgTypeStr, message)
	if err != nil {
		return fmt.Errorf("kafka topic:%s 发布类型:%s 消息:%s 失败, error:%v", topicStr, msgTypeStr, message, err)
	}
	return nil
}

// 发布延时消息,单位s
func (p *Pub) Delay(topic enum.MsgTopic, message string, delay int64) error {
	topicStr := string(topic)
	_, err := p.aQueue.DelayPub(asynq.CriticalQueue, topicStr, message, time.Duration(delay)*time.Second)
	if err != nil {
		return fmt.Errorf("topic:%s  发布延时消息:%s 失败, error:%v", topicStr, message, err)
	}
	return nil
}

// 发布异步消息
func (p *Pub) Sync(topic enum.MsgTopic, message string) error {
	topicStr := string(topic)
	_, err := p.aQueue.SyncPub(asynq.DefaultQueue, topicStr, message)
	if err != nil {
		return fmt.Errorf("topic:%s  发布异步消息:%s 失败, error:%v", topicStr, message, err)
	}
	return nil
}

// 发布定时消息
func (p *Pub) Cron(topic enum.MsgTopic, message, cronSpec string) error {
	topicStr := string(topic)
	err := p.aQueue.SetCronPub(topicStr, message, cronSpec)
	if err != nil {
		return fmt.Errorf("topic:%s  发布周期/定时消息:%s 失败, error:%v", topicStr, message, err)
	}
	return nil
}

// 发布取消消息
func (p *Pub) DelCron(topic enum.MsgTopic) error {
	topicStr := string(topic)
	err := p.aQueue.DelCronPub(topicStr)
	if err != nil {
		return fmt.Errorf("topic:%s  取消周期/定时消息 失败, error:%v", topicStr, err)
	}
	return nil
}
