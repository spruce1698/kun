/**
 * @Author: spruce
 * @Date: 2024-04-20 15:13
 * @Desc: 订阅消息处理
 */

package service

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"advanced/internal/enum"
	"advanced/internal/repository/cache"
	"advanced/internal/repository/db"
	"advanced/pkg/asynq"
	"advanced/pkg/utils"
)

var _ SubMsgSvc = (*subMsgSvc)(nil)

type (
	SubMsgSvc interface {
		SubDemoPayKafka(key, value string) error

		SubKafkaTypeDemoPay(key, value string) error

		SubAqPay(ctx context.Context, task *asynq.Task) error
	}
	Demo struct {
		Id    int64  `json:"id"`
		Name  string `json:"name"`
		Test4 int32  `json:"test4"`
	}
	MongoDemo struct {
		Id         string `json:"id"`
		CategoryId int64  `json:"categoryId"` // 文章分类
		Title      string `json:"title"`      // 文章标题
	}
	Account struct {
		Id         int64   `json:"id"`         // 账号id
		OrganizeId int64   `json:"organizeId"` // 组织机构id
		GroupId    *int64  `json:"groupId"`    // 帐号分组id
		Nickname   *string `json:"nickname"`   // 昵称
	}

	FindByIdResp struct {
		Id       int64  `json:"id"`
		Name     string `json:"name"`
		Username string `json:"username"`
		Password string `json:"password"`
		Enabled  bool   `json:"enabled"`
	}

	subMsgSvc struct {
		*Service
		userDb    db.UserRepo
		userCache cache.UserRepo
	}
)

func NewSubMsgSvc(svc *Service, userDb db.UserRepo, userCache cache.UserRepo) SubMsgSvc {
	return &subMsgSvc{
		Service:   svc,
		userDb:    userDb,
		userCache: userCache,
	}
}

// Kafka事件订阅
func (s *subMsgSvc) SubDemoPayKafka(key, value string) error {

	msg := &enum.DemoPayRecharge{}
	_ = json.Unmarshal([]byte(value), msg)

	fmt.Printf("SubDemoPayKafka--Kafka-Subscriber-Fetch:消费时间:%s:%s \n", utils.TimeStr(time.Now()), value)

	return nil
}

// Kafka-type 事件订阅
func (s *subMsgSvc) SubKafkaTypeDemoPay(key, value string) error {
	switch enum.MsgType(key) {
	case enum.DemoMsgTypePayRecharge: // 充值

		msg := &enum.DemoPayRecharge{}
		_ = json.Unmarshal([]byte(value), msg)

		fmt.Printf("SubKafkaTypeDemoPay--Kafka-Subscriber-Fetch:消费时间:%s:%s \n", utils.TimeStr(time.Now()), value)
		// TODO: do something 逻辑处理start
		return nil
	default:
		s.logger.Error("未知的支付事件类型:" + key + value)
	}
	return nil
}

// aq订阅
func (s *subMsgSvc) SubAqPay(ctx context.Context, task *asynq.Task) error {
	fmt.Printf("AqSubscriber:消费时间:%s: %s %s  \n", utils.TimeStr(time.Now()), task.Type(), task.Payload())
	// TODO: do something 逻辑处理start
	return nil
}
