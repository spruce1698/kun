package service

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"advanced/internal/enum"
	"advanced/internal/repository/cache"
	"advanced/internal/repository/db"
	"advanced/pkg/utils"
	"advanced/pkg/xerror"

	"github.com/jinzhu/copier"
	"github.com/pkg/errors"
)

//go:generate mockgen -source=./user.go -destination=../../test/mocks/service/user.go  -package mock_service

var _ UserSvc = (*userSvc)(nil)

type (
	UserSvc interface {
		GetUserById(id int64) (result *User, err error)
		GetList(page, pageSize int64) (hasMore bool, items []*User, err error)
		SendMsg() (err error)
		DelMsg() (err error)
	}
	User struct {
		Id       int64  `json:"id"`
		Username string `json:"username"`
		Email    string `json:"email"`
	}

	userSvc struct {
		*Service
		userDb    db.UserRepo
		userCache cache.UserRepo
	}
)

func NewUserSvc(svc *Service, userDb db.UserRepo, userCache cache.UserRepo) UserSvc {
	return &userSvc{
		Service:   svc,
		userDb:    userDb,
		userCache: userCache,
	}
}

func (s *userSvc) GetUserById(id int64) (result *User, err error) {
	ctx := context.Background()
	if id > 0 {

		// msg, _ := json.Marshal(&enum.PayRecharge{
		// 	TradeNo:    "1111111",
		// 	PayType:    enum.PayTypeAlipay,
		// 	Status:     enum.PayStatusComplete,
		// 	UserId:     123,
		// 	Cash:       1.20,
		// 	CreateTime: utils.TimeStr(time.Now()),
		// 	Remark:     "KQ充值异步消息",
		// })
		// _ = s.msgPub.KafkaWithType(enum.MsgTopicPay, enum.MsgTypePayRecharge, msg)
		//
		// msg1, _ := json.Marshal(&enum.PayRecharge{
		// 	TradeNo:    "1111111",
		// 	PayType:    enum.PayTypeAlipay,
		// 	Status:     enum.PayStatusComplete,
		// 	UserId:     123,
		// 	Cash:       1.20,
		// 	CreateTime: utils.GetTimeStr(time.Now()),
		// 	Remark:     "AQ充值异步消息",
		// })
		// _ = s.msgPub.Delay(enum.MsgTopicPay, string(msg1), 5)

		result = &User{}
		user, cacheErr := s.userCache.GetUser(ctx, id)
		if cacheErr != nil {
			s.logger.Info(fmt.Sprintf("Get User Cache 失败:err %v \n", cacheErr))
			dbUser, dbErr := s.userDb.FindOne(ctx, id)
			if dbErr != nil {
				if errors.Is(dbErr, db.ErrNotFound) {
					return nil, xerror.NewError(xerror.BusinessError, "没有相关记录", dbErr)
				}
				return result, xerror.NewError(xerror.BusinessError, "GetUserById失败", dbErr)
			}
			_ = copier.Copy(result, dbUser)
			return result, nil
		}

		_ = copier.Copy(result, user)
		return result, nil

	}
	return result, xerror.NewError(xerror.BusinessError, "GetUserById 失败", nil)
}

func (s *userSvc) GetList(page, pageSize int64) (hasMore bool, items []*User, err error) {
	ctx := context.Background()
	search := &db.UserSearch{}
	search.Page = page
	search.PageSize = pageSize
	list, hasMore, listErr := s.userDb.ListWithMore(ctx, search)
	if listErr != nil {
		return false, nil, xerror.NewError(xerror.BusinessError, "Get User List失败", err)
	}
	result := make([]*User, len(list))
	for i, v := range list {
		t := &User{}
		_ = copier.Copy(t, v)
		result[i] = t
	}
	return hasMore, result, nil
}

func (s *userSvc) SendMsg() (err error) {
	demoMsg0, _ := json.Marshal(&enum.DemoPayRecharge{
		TradeNo:    "O100",
		PayType:    enum.DemoPayTypeAlipay,
		Status:     enum.DemoPayStatusIng,
		UserId:     123,
		Cash:       1.20,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "Kafka-消息",
	})
	_ = s.msgPub.Kafka(enum.DemoMsgTopicPay, demoMsg0)

	demoMsg1, _ := json.Marshal(&enum.DemoPayRecharge{
		TradeNo:    "O100",
		PayType:    enum.DemoPayTypeAlipay,
		Status:     enum.DemoPayStatusIng,
		UserId:     123,
		Cash:       1.20,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "Kafka-type-消息",
	})
	_ = s.msgPub.KafkaWithType(enum.DemoMsgTopicPay, enum.DemoMsgTypePayRecharge, demoMsg1)

	demoMsg2, _ := json.Marshal(&enum.DemoPayRecharge{
		TradeNo:    "O101",
		PayType:    enum.DemoPayTypeWxpay,
		Status:     enum.DemoPayStatusSuccess,
		UserId:     123,
		Cash:       1.20,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "5s延迟消息",
	})
	_ = s.msgPub.Delay(enum.DemoMsgTopicPay, string(demoMsg2), 5)

	demoMsg3, _ := json.Marshal(&enum.DemoPayRecharge{
		TradeNo:    "O102",
		PayType:    enum.DemoPayTypeWxpay,
		Status:     enum.DemoPayStatusSuccess,
		UserId:     123,
		Cash:       1.20,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "AQ-异步-消息",
	})
	_ = s.msgPub.Sync(enum.DemoMsgTopicPay, string(demoMsg3))

	demoMsg4, _ := json.Marshal(&enum.DemoPayRecharge{
		TradeNo:    "O103",
		PayType:    enum.DemoPayTypeWxpay,
		Status:     enum.DemoPayStatusFail,
		UserId:     0,
		Cash:       0,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "AQ-每三秒一次-消息",
	})
	_ = s.msgPub.Cron(enum.DemoMsgTopicPay, string(demoMsg4), "@every 3s")

	return nil
}

func (s *userSvc) DelMsg() (err error) {
	_ = s.msgPub.DelCron(enum.DemoMsgTopicPay)
	return nil
}
