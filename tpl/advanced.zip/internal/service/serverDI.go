package service

import (
	"advanced/internal/event"
	"advanced/internal/service/svc"

	"github.com/google/wire"
)

// 服务层
var WireServerSet = wire.NewSet(
	// 基础ctx
	wire.Struct(new(svc.Ctx), "*"),

	//  event
	event.NewPub,
	// ==== Add Event before this line, don't edit this line.====

	//  service
	wire.Struct(new(svc.DemoCtx), "*"),
	svc.NewDemoSvc,

	// ==== Add Svc before this line, don't edit this line.====
)
