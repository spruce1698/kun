package svc

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"advanced/internal/event"
	"advanced/internal/global"
	"advanced/internal/repository/cache"
	"advanced/internal/repository/db"
	"advanced/pkg/utils"
	"advanced/pkg/xerror"
	"advanced/pkg/xlog"

	"github.com/jinzhu/copier"
	"github.com/pkg/errors"
)

//go:generate mockgen -source=./demo.go -destination=../../../test/mocks/service/demo.go  -package mock_service

var _ DemoSvc = (*demoSvc)(nil)

type (
	DemoSvc interface {
		Detail(ctx context.Context, id int64) (*Demo, error)
		FindList(ctx context.Context, args *DemoListArgs) ([]*Demo, int64, error)
		Create(ctx context.Context, args *Demo) error
		Update(ctx context.Context, args *Demo) error
		Delete(ctx context.Context, id int64) error
		SoftDelete(ctx context.Context, id int64) error

		SendMsg(ctx context.Context) error
		DelMsg(ctx context.Context) error
	}
	DemoCtx struct {
		*Ctx

		DemoDb    db.DemoDb
		DemoCache cache.DemoCache
		MsgPub    *event.Pub
	}
	demoSvc struct {
		ctx *DemoCtx
	}

	DemoListArgs struct {
		OrderField string // 排序字段
		OrderType  int64  // 排序类型 0:升序,1:降序
		Page       int64  // 添加验证规则
		PageSize   int64  // 添加验证规则

		Id   *int64
		Name string
	}

	Demo struct {
		Id    int64
		Name  string
		Test1 float64
		Test4 int32
	}
)

func NewDemoSvc(ctx *DemoCtx) DemoSvc {
	return &demoSvc{
		ctx: ctx,
	}
}

// 查找一个
func (d *demoSvc) Detail(ctx context.Context, id int64) (*Demo, error) {
	if id <= 2 {
		return nil, xerror.NewError(ctx, xerror.InvalidArgument, "Get Demo Detail invalid id", nil)
	}

	xlog.Info(ctx, "Demo Detail", "测试手工日志")

	result := &Demo{}
	demo, cacheErr := d.ctx.DemoCache.Get(ctx, id)
	if cacheErr != nil {
		xlog.Info(ctx, fmt.Sprintf("Get Demo Detail 失败:err %v", cacheErr))
		demoDb, dbErr := d.ctx.DemoDb.FindOne(ctx, id)
		if dbErr != nil {
			if errors.Is(dbErr, db.ErrNotFound) {
				return nil, xerror.NewError(ctx, xerror.BusinessError, "没有相关记录", dbErr)
			}
			return result, xerror.NewError(ctx, xerror.BusinessError, "Demo Detail 失败", dbErr)
		}
		_ = d.ctx.DemoCache.Set(ctx, id, &cache.Demo{
			Id:    demoDb.Id,
			Name:  demoDb.Name,
			Test4: demoDb.Test4,
		}, 0)
		_ = copier.Copy(result, demoDb)
		return result, nil
	}
	_ = copier.Copy(result, demo)
	return result, nil
}

// 查找列表
func (d *demoSvc) FindList(ctx context.Context, args *DemoListArgs) ([]*Demo, int64, error) {

	dbArgs := &db.DemoSearch{}
	_ = copier.Copy(dbArgs, args)

	list, total, listErr := d.ctx.DemoDb.FindListWithTotal(ctx, dbArgs)
	if listErr != nil {
		if errors.Is(listErr, db.ErrNotFound) {
			return []*Demo{}, 0, nil
		}
		return nil, 0, xerror.NewError(ctx, xerror.BusinessError, "Get Demo List 失败", listErr)
	}
	result := make([]*Demo, 0, len(list))
	if len(list) > 0 {
		for _, demo := range list {
			var item Demo
			_ = copier.Copy(&item, demo)
			result = append(result, &item)
		}
	}
	return result, total, nil
}

// 创建
func (d *demoSvc) Create(ctx context.Context, args *Demo) error {
	_, dbErr := d.ctx.DemoDb.Insert(ctx, &db.Demo{
		Name:  args.Name,
		Test1: args.Test1,
		Test4: args.Test4,
	})
	if dbErr != nil {
		return xerror.NewError(ctx, xerror.BusinessError, "Create Demo 失败", dbErr)
	}
	return nil
}

// 修改(事务示例)
func (d *demoSvc) Update(ctx context.Context, args *Demo) error {
	if args.Id > 0 {
		// 两种事务方式
		// 方式1:
		// err := d.ctx.Conn.Tx(ctx, func(ctx context.Context) error {
		//     preOne := args.Id - 1
		//     demo, err := d.ctx.DemoDb.FindOne(ctx, preOne)
		//     if err != nil {
		//         return err
		//     }
		//     err = d.ctx.DemoDb.Delete(ctx, []int64{preOne})
		//     if err != nil {
		//         return err
		//     }
		//     if demo.Id == 3 {
		//         return errors.New("id是3,不能修改")
		//     }
		//     _, err = d.ctx.DemoDb.UpdateColumns(ctx, args.Id, map[string]any{"name": args.Name, "test1": args.Test1, "test4": args.Test4})
		//     return err
		// })
		// 方式2:
		err := d.ctx.DemoDb.UpdateTrans(ctx, args.Id, &db.Demo{
			Name:  args.Name,
			Test1: args.Test1,
			Test4: args.Test4,
		})

		if err != nil {
			return xerror.NewError(ctx, xerror.BusinessError, "Update Demo 失败", err)
		}
		return nil
	}
	return xerror.NewError(ctx, xerror.BusinessError, "Update Demo 失败", nil)
}

// 物理删除
func (d *demoSvc) Delete(ctx context.Context, id int64) error {
	if id > 0 {
		err := d.ctx.DemoDb.Delete(ctx, []int64{id})
		if err != nil {
			return xerror.NewError(ctx, xerror.BusinessError, "Delete Demo 失败", err)
		}
	}
	return nil
}

// 逻辑删除
func (d *demoSvc) SoftDelete(ctx context.Context, id int64) error {
	if id > 0 {
		err := d.ctx.DemoDb.SoftDelete(ctx, []int64{id})
		if err != nil {
			return xerror.NewError(ctx, xerror.BusinessError, "SoftDelete Demo 失败", err)
		}
	}
	return nil
}

// 发送消息
func (d *demoSvc) SendMsg(ctx context.Context) error {
	demoMsg0, _ := json.Marshal(&global.PayRecharge{
		TradeNo:    "O100",
		PayType:    global.PayTypeAlipay,
		Status:     global.PayStatusIng,
		UserId:     123,
		Cash:       1.20,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "Kafka-消息",
	})
	_ = d.ctx.MsgPub.Kafka(global.EventTopicPay, demoMsg0)

	demoMsg1, _ := json.Marshal(&global.PayRecharge{
		TradeNo:    "O101",
		PayType:    global.PayTypeAlipay,
		Status:     global.PayStatusIng,
		UserId:     123,
		Cash:       1.20,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "Kafka-type-消息",
	})
	_ = d.ctx.MsgPub.KafkaWithType(global.EventTopicPay, global.EventTypePayRecharge, demoMsg1)

	demoMsg2, _ := json.Marshal(&global.PayRecharge{
		TradeNo:    "O102",
		PayType:    global.PayTypeWxpay,
		Status:     global.PayStatusSuccess,
		UserId:     123,
		Cash:       1.20,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "5s延迟消息",
	})
	_ = d.ctx.MsgPub.Delay(global.EventTopicPay, string(demoMsg2), 5)

	demoMsg3, _ := json.Marshal(&global.PayRecharge{
		TradeNo:    "O103",
		PayType:    global.PayTypeWxpay,
		Status:     global.PayStatusSuccess,
		UserId:     123,
		Cash:       1.20,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "AQ-异步-消息",
	})
	_ = d.ctx.MsgPub.Sync(global.EventTopicPay, string(demoMsg3))

	demoMsg4, _ := json.Marshal(&global.PayRecharge{
		TradeNo:    "O104",
		PayType:    global.PayTypeWxpay,
		Status:     global.PayStatusSuccess,
		UserId:     123,
		Cash:       1.20,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "AQ-MsgTopicPay1-异步-消息",
	})
	_ = d.ctx.MsgPub.Sync(global.EventTopicPay1, string(demoMsg4))

	demoMsg5, _ := json.Marshal(&global.PayRecharge{
		TradeNo:    "O105",
		PayType:    global.PayTypeWxpay,
		Status:     global.PayStatusFail,
		UserId:     0,
		Cash:       0,
		CreateTime: utils.TimeStr(time.Now()),
		Remark:     "AQ-每三秒一次-消息",
	})
	_ = d.ctx.MsgPub.Cron(global.EventTopicPay, string(demoMsg5), "@every 3s")

	return nil
}

// 发送删除消息
func (d *demoSvc) DelMsg(ctx context.Context) error {
	_ = d.ctx.MsgPub.DelCron(global.EventTopicPay)
	return nil
}
