/**
 * @Author: spruce
 * @Date: 2024-04-20 22:26
 * @Desc: 服务 wire 配置
 */

package service

import (
	"advanced/internal/pubsub/publisher"
	"advanced/internal/repository/mysql"
	"advanced/pkg/token"
	"advanced/pkg/xconfig"
	"advanced/pkg/xlog"

	"github.com/google/wire"
)

type Service struct {
	cnf    *xconfig.Cnf
	logger *xlog.Logger
	jwt    *token.Jwt

	tx     mysql.ConnTx
	msgPub *publisher.Pub
}

func NewService(cnf *xconfig.Cnf, log *xlog.Logger, jwt *token.Jwt, tx mysql.ConnTx, pub *publisher.Pub) *Service {
	return &Service{
		cnf:    cnf,
		logger: log,
		jwt:    jwt,
		tx:     tx,
		msgPub: pub,
	}
}

// ====================== TODO 需要手动配置  http 服务层 修改后重新wire ======================

// 服务列表
type ServerSvc struct {
	UserSvc UserSvc
}

// 服务层
var WireServerSet = wire.NewSet(
	NewService,
	NewUserSvc,
)

// ====================== TODO 需要手动配置  broker 服务层 修改后重新wire ======================

// 服务列表
type BrokerSvc struct {
	SubMsgSvc SubMsgSvc
}

// 服务层
var WireBrokerSet = wire.NewSet(
	NewService,
	NewSubMsgSvc,
)
