/**
 * @Author: spruce
 * @Date: 2024-04-20 22:26
 * @Desc: 服务 wire 配置
 */

package service

import (
	"advanced/internal/msgbus/publisher"
	"advanced/internal/repository/db"
	"advanced/pkg/token"
	"advanced/pkg/xconfig"
	"advanced/pkg/xlog"

	"github.com/google/wire"
)

type Service struct {
	cnf    *xconfig.Cnf
	logger *xlog.Logger
	jwt    *token.Jwt

	tx     db.ConnTx
	msgPub *publisher.Pub
}

func NewService(cnf *xconfig.Cnf, log *xlog.Logger, jwt *token.Jwt, tx db.ConnTx, pub *publisher.Pub) *Service {
	return &Service{
		cnf:    cnf,
		logger: log,
		jwt:    jwt,
		tx:     tx,
		msgPub: pub,
	}
}

// 服务列表    // TODO 需要手动增加 后执行 wire
type SvcSet struct {
	UserSvc   UserSvc
	SubMsgSvc SubMsgSvc
}

// 服务层   // TODO 需要手动增加 后执行 wire
var InjectSet = wire.NewSet(
	NewService,
	NewUserSvc,
	NewSubMsgSvc,
)
