/**
 * @Author: albert
 * @Date: 2024-07-02
 * @Desc: broker logic
 */

package logic

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"advanced/internal/global"
	"advanced/internal/repository/cache"
	"advanced/internal/repository/mysql"
	"advanced/pkg/asynq"
	"advanced/pkg/utils"
)

//go:generate mockgen -source=./broker.go -destination=../../test/mocks/logic/broker.go  -package mock_logic

var _ BrokerLogic = (*brokerLogic)(nil)

type (
	BrokerLogic interface {
		SubPayRecharge(key, value string) error
		KQPayDemo(key, value string) error
		SubAqPay(ctx context.Context, task *asynq.Task) error
		SubAqPay1(ctx context.Context, task *asynq.Task) error
	}
	brokerLogic struct {
		*Logic
		demoMysql mysql.DemoRepo
		demoCache cache.DemoRepo
	}
)

func NewBrokerLogic(logic *Logic, demoMysql mysql.DemoRepo, demoCache cache.DemoRepo) BrokerLogic {
	return &brokerLogic{
		Logic:     logic,
		demoMysql: demoMysql,
		demoCache: demoCache,
	}
}

// 支付事件订阅
func (l *brokerLogic) SubPayRecharge(key, value string) error {
	switch global.MsgType(key) {
	case global.MsgTypePayRecharge: // 充值
		msg := &global.PayRecharge{}
		_ = json.Unmarshal([]byte(value), msg)

		fmt.Printf("SubPayRecharge-type:消费时间:%s:%s \n", utils.TimeStr(time.Now()), value)

		// TODO: do something 逻辑处理start...

		return nil
	default:
		l.logger.Error("未知的支付事件类型:" + key + value)
	}
	return nil
}

// 支付事件订阅,无类型
func (l *brokerLogic) KQPayDemo(key, value string) error {
	msg := &global.PayRecharge{}
	_ = json.Unmarshal([]byte(value), msg)

	fmt.Printf("KQPayDemo:not key 消费时间:%s:%s \n", utils.TimeStr(time.Now()), value)

	// TODO: do something 逻辑处理start...

	return nil
}

// aq订阅
func (l *brokerLogic) SubAqPay(ctx context.Context, task *asynq.Task) error {
	fmt.Printf("SubAqPay:消费时间:%s: %s %s  \n", utils.TimeStr(time.Now()), task.Type(), task.Payload())

	// TODO: do something 逻辑处理start...

	return nil
}

func (l *brokerLogic) SubAqPay1(ctx context.Context, task *asynq.Task) error {
	fmt.Printf("SubAqPay1:消费时间:%s: %s %s  \n", utils.TimeStr(time.Now()), task.Type(), task.Payload())

	// TODO: do something 逻辑处理start...
	return nil
}
