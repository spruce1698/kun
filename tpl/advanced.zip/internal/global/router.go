/**
 * @Author: spruce
 * @Date: 2024-03-28 17:30
 * @Desc: 路由 常量
 */

package global

const (
	RouterPrefixApi = "/api"
	RouterPrefixMgr = "/mgr"
)
