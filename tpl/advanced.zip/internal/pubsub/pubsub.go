/**
 * @Author: spruce
 * @Date: 2024-04-20 15:39
 * @Desc:  发布/订阅服务 wire配置
 */

package pubsub

import (
	"advanced/internal/enum"
	"advanced/internal/pubsub/subscriber"
	"advanced/internal/service"
)

// ====================== TODO 需要手动配置  broker 订阅服务 修改后重新wire ======================

// 订阅服务
func WireSet(svc *service.BrokerSvc) *subscriber.Task {
	return &subscriber.Task{
		KafkaSet: []*subscriber.Kafka{
			{
				Topic:   enum.DemoMsgTopicPay,
				Group:   enum.DemoMsgGroupPay,
				Handler: svc.SubMsgSvc.SubDemoPayKafka,
			},
			{
				Topic:   enum.DemoMsgTopicPay,
				Group:   enum.DemoMsgGroupPay1,
				Handler: svc.SubMsgSvc.SubKafkaTypeDemoPay,
			},
		},
		AsynqSet: []*subscriber.Asynq{
			{
				Topic:   enum.DemoMsgTopicPay,
				Handler: svc.SubMsgSvc.SubAqPay,
			},
		},
	}
}
