/**
* @Author: spruce
 * @Date: 2024-03-28 11:08
 * @Desc: 消息订阅器
*/

package pubsub

import (
	"context"
	"fmt"
	"os"
	"sync"

	"advanced/internal/global"
	"advanced/pkg/asynq"
	"advanced/pkg/kafka"
	"advanced/pkg/xconfig"
)

type (
	Sub struct {
		wg     *sync.WaitGroup
		cnf    *xconfig.Cnf
		aQueue *asynq.Asynq
		task   *Task
	}
	Task struct {
		KafkaSet []*Kafka
		AsynqSet []*Asynq
	}
	Kafka struct {
		Topic   global.MsgTopic
		Group   global.MsgGroup
		Handler func(key, value string) error
	}
	Asynq struct {
		Topic   global.MsgTopic
		Handler func(context.Context, *asynq.Task) error
	}
)

func NewSub(wg *sync.WaitGroup, cnf *xconfig.Cnf, task *Task) *Sub {
	return &Sub{
		wg:     wg,
		cnf:    cnf,
		aQueue: asynq.New(cnf),
		task:   task,
	}
}

// kafka 消费者
func (s *Sub) Kafka() {

	if s.task.KafkaSet == nil || len(s.task.KafkaSet) <= 0 {
		return
	}

	k := kafka.NewSubscriber(s.cnf)

	s.wg.Add(len(s.task.KafkaSet))
	for _, kq := range s.task.KafkaSet {
		go func(v *Kafka) {
			// k.Sub(string(v.Topic), string(v.Group), v.Handler)
			k.SubFetch(string(v.Topic), string(v.Group), v.Handler)
			defer s.wg.Done()
		}(kq)
	}

	defer k.Close()
}

// Asynq 消费者
func (s *Sub) Asynq() {
	if s.task.AsynqSet == nil || len(s.task.AsynqSet) <= 0 {
		return
	}

	s.wg.Add(1)
	go func() {
		srv := s.aQueue.Server()
		mux := asynq.NewServeMux()
		// 添加任务
		for _, aq := range s.task.AsynqSet {
			mux.HandleFunc(string(aq.Topic), aq.Handler)
		}
		if err := srv.Run(mux); err != nil {
			fmt.Printf("!!!CronJobErr!!! run err:%+v \n ", err)
			srv.Shutdown()
			os.Exit(1)
		}
		defer srv.Stop()
		defer s.wg.Done()
	}()
}

// Asynq 周期性任务服务
func (s *Sub) AsynqCron() {
	s.wg.Add(1)
	go func() {
		_ = s.aQueue.CronPub()
		defer s.wg.Done()
	}()
}

// ==============github.com/robfig/cron 周期性任务=====================================

// "github.com/robfig/cron/v3"
//  CronFun func(corner *cron.Cron)

// // 周期性任务服务精确到秒
// func (s *Sub) Cron() {
// 	if s.task.CronFunSet == nil || len(s.task.CronFunSet) <= 0 {
// 		return
// 	}
//
// 	loc, _ := time.LoadLocation("Asia/Shanghai")
// 	cs := cron.New(cron.WithSeconds(), cron.WithLocation(loc))
// 	s.wg.Add(1)
// 	go func() {
// 		// 添加任务
// 		for _, fun := range s.task.CronFunSet {
// 			fun(cs)
// 		}
// 		cs.Start()
//
// 		defer s.wg.Done()
// 	}()
// 	defer cs.Stop() // 需要在协程结束时关闭
// }

// // 支付事件消费
// func (s *Service) PayDemo(key, value string) error {
// 	switch enum.MsgType(key) {
// 	case enum.MsgTypePayRecharge: // 充值
//
// 		msg := &producer.PayRecharge{}
// 		_ = json.Unmarshal([]byte(value), msg)
//
// 		fmt.Printf("KafkaSubscriber-Fetch:消费时间:%s:%s \n", utils.GetTimeStr(time.Now()), value)
// 		// 逻辑处理start...
// 		// TODO: do something
// 		// err := c.DemoCache.SetDemo(context.Background(), 111111, &cache.Demo{Id: 111111, Name: "asdfsadfasf"}, 0)
// 		// fmt.Println(err)
//
// 		return nil
// 	default:
// 		log.Fatalln("未知的支付事件类型", key)
// 	}
// 	return nil
// }
//
// // 支付事件消费
// func (s *Service) KQPayDemo(key, value string) error {
// 	msg := &producer.PayRecharge{}
// 	_ = json.Unmarshal([]byte(value), msg)
//
// 	fmt.Printf("KafkaSubscriber:key 消费时间:%s:%s \n", utils.GetTimeStr(time.Now()), value)
// 	// 逻辑处理start...
// 	// TODO: do something
//
// 	// err := c.DemoCache.SetDemo(context.Background(), 111111, &cache.Demo{Id: 111111, Name: "asdfsadfasf"}, 0)
// 	// fmt.Println(err)
//
// 	return nil
// }
//
// // aq消费者
// func (s *Service) AqSubscriberDemo(ctx context.Context, task *asynq.Task) error {
// 	fmt.Printf("AqSubscriber:消费时间:%s: %s %s  \n", utils.GetTimeStr(time.Now()), task.Type(), task.Payload())
// 	// 逻辑处理start...
// 	// TODO: do something
// 	return nil
// }
//
// // Cron 消费者
// func (s *Service) CronSubscriberDemo(corner *cron.Cron) {
// 	// 每个偶数秒执行
// 	spec := "*/2 * * * * *"
// 	var demoLock sync.Mutex
// 	entryID, err := corner.AddFunc(spec, func() {
// 		demoLock.Lock()
// 		defer demoLock.Unlock()
//
// 		fmt.Printf("CronDemo:消费时间:%s \n", utils.GetTimeStr(time.Now()))
//
// 		// 逻辑处理start...
// 		// TODO: do something
// 	})
// 	if err != nil {
// 		fmt.Printf("启动[demo]定时任务失败:%v %v \n", entryID, err)
// 	}
// }
