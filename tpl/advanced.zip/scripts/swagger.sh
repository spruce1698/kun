#!/bin/bash
cd ../
swag init -g ./cmd/server/main.go -o ./docs