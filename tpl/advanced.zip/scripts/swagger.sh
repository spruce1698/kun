#!/bin/bash
cd ../
swag init --g ./cmd/server/main.go --exclude config,deploy,docs,pkg,scripts,test,internal/event,internal/global,internal/middleware,internal/repository,internal/router,internal/service --o ./docs/swagger