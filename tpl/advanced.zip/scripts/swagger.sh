#!/bin/bash
cd ../
swag init ─g ./cmd/server/main.go ──exclude config,deploy,docs,pkg,scripts,test,internal/global,internal/logic,internal/middleware,internal/pubsub,internal/repository,internal/router ─o ./docs/swagger