//go:build wireinject
// +build wireinject

package wire

import (
	"advanced/internal/pubsub/publisher"
	"advanced/internal/repository/db"
	"advanced/pkg/server"
	"advanced/pkg/server/http"

	"advanced/internal/controller"
	"advanced/internal/repository"
	"advanced/internal/router"
	"advanced/internal/service"

	"advanced/pkg/token"
	"advanced/pkg/xconfig"
	"advanced/pkg/xdb"
	"advanced/pkg/xlog"
	"advanced/pkg/xredis"

	"github.com/google/wire"
)

// 基础层,数据库链接等
var baseSet = wire.NewSet(
	xconfig.New,
	xlog.New,
	xdb.New,
	xredis.New,

	db.NewConn,
	db.NewConnTx,
	token.New,

	publisher.New,

	repository.WireSet,
)

func CreateApp(env string) (*server.Svr, error) {
	panic(wire.Build(
		baseSet,
		service.WireServerSet,
		controller.WireServerSet,
		wire.Struct(new(controller.ServerCtl), "*"),
		router.WireServerSet,
		http.New,
		server.New,
	))
}
