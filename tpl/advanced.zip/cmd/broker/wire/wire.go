//go:build wireinject
// +build wireinject

package wire

import (
	"advanced/internal/msgbus"
	"advanced/internal/msgbus/publisher"
	"advanced/internal/repository"
	"advanced/internal/repository/db"
	"advanced/internal/service"

	"advanced/pkg/server"
	"advanced/pkg/server/broker"

	"advanced/pkg/token"
	"advanced/pkg/xconfig"
	"advanced/pkg/xdb"
	"advanced/pkg/xlog"
	"advanced/pkg/xredis"

	"github.com/google/wire"
)

// 基础层,数据库链接等
var baseSet = wire.NewSet(
	xconfig.New,
	xlog.New,
	xdb.New,
	xredis.New,
	token.New,

	db.NewConn,
	db.NewConnTx,

	publisher.New,
)

func CreateApp(env string) (*server.Svr, error) {
	panic(wire.Build(
		baseSet,
		repository.InjectSet,
		service.InjectSet,
		wire.Struct(new(service.SvcSet), "*"),
		msgbus.InjectSet,
		broker.New,
		server.New,
	))
}
