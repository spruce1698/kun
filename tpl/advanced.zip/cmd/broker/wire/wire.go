//go:build wireinject
// +build wireinject

package wire

import (
	"advanced/internal/global"
	"advanced/internal/logic"
	"advanced/internal/pubsub"
	"advanced/internal/repository/cache"
	"advanced/internal/repository/mysql"
	"advanced/pkg/xconfig"
	"advanced/pkg/xdb"
	"advanced/pkg/xlog"
	"advanced/pkg/xredis"
	"advanced/pkg/xserver"
	"advanced/pkg/xserver/broker"

	"github.com/google/wire"
)

// 订阅服务
func Broker(brokerLogic logic.BrokerLogic) *pubsub.Task {
	return &pubsub.Task{
		KafkaSet: []*pubsub.Kafka{
			{
				Topic:   global.MsgTopicPay,
				Group:   global.MsgGroupPay,
				Handler: brokerLogic.SubPayRecharge,
			},
			{
				Topic:   global.MsgTopicPay,
				Group:   global.MsgGroupPay1,
				Handler: brokerLogic.KQPayDemo,
			},
		},
		AsynqSet: []*pubsub.Asynq{
			{
				Topic:   global.MsgTopicPay,
				Handler: brokerLogic.SubAqPay,
			},
			{
				Topic:   global.MsgTopicPay1,
				Handler: brokerLogic.SubAqPay1,
			},
		},
	}
}

func WireApp(env string) (*xserver.Server, error) {
	panic(wire.Build(
		// ====base,配置,日志,数据库链接等====
		xconfig.New,
		xlog.New,
		xdb.New,

		xredis.New,
		mysql.NewConn,
		mysql.NewConnTx,
		broker.New,

		// ====repository-start====
		mysql.NewDemoRepo,
		cache.NewDemoRepo,
		// ====repository-end====

		// ====logic-start====
		logic.BaseLogic,

		logic.NewBrokerLogic,
		// ====logic-end====
		Broker,

		xserver.New,
	))
}
